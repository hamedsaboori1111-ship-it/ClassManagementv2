package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("دفتر مدیریت کلاسی", appName)
  }

  @Test
  fun testBackupSummaryParsing() {
    val sampleJson = """
      {
        "currentDateShamsi": "1403/07/15",
        "profile": {
          "teacherName": "محمد رضایی",
          "schoolName": "دبستان شهید بهشتی"
        },
        "students": [
          {
            "id": 1,
            "name": "علی حسینی",
            "evaluations": [
              {"subject": "ریاضی", "date": "1403/07/10", "type": "خیلی خوب", "note": "عالی"},
              {"subject": "علوم", "date": "1403/07/12", "type": "خوب", "note": "خوب"}
            ]
          },
          {
            "id": 2,
            "name": "رضا محمدی",
            "evaluations": [
              {"subject": "فارسی", "date": "1403/07/14", "type": "خیلی خوب", "note": ""}
            ]
          }
        ],
        "attendanceHistory": [
          {"date": "1403/07/10", "absentStudentIds": [2]}
        ],
        "subjects": [
          {"name": "ریاضی", "iconName": "calculate", "colorHex": "#00A86B", "enabled": true}
        ],
        "teacherNotes": [
          {"id": 1, "title": "جلسه شورا", "content": "برگزاری جلسه", "date": "1403/07/15"}
        ]
      }
    """.trimIndent()

    val root = org.json.JSONObject(sampleJson)
    val students = root.getJSONArray("students")
    assertEquals(2, students.length())

    var evalCount = 0
    for (i in 0 until students.length()) {
      evalCount += students.getJSONObject(i).getJSONArray("evaluations").length()
    }
    assertEquals(3, evalCount)

    val profile = root.getJSONObject("profile")
    assertEquals("محمد رضایی", profile.getString("teacherName"))
    assertEquals("دبستان شهید بهشتی", profile.getString("schoolName"))
  }
}

