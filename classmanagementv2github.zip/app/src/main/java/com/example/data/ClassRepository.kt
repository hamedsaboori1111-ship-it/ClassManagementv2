package com.example.data

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class ClassRepository(context: Context) {

    private val appContext = context.applicationContext
    val backupManager = BackupManager(appContext)

    private val prefs: SharedPreferences =
        appContext.getSharedPreferences("class_manager_prefs", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(loadInitialState())
    val state: StateFlow<AppState> = _state.asStateFlow()

    init {
        try {
            val savedJson = prefs.getString("app_state_json", null)
            if (!savedJson.isNullOrEmpty()) {
                backupManager.autoBackupIfDue(savedJson)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun loadInitialState(): AppState {
        val todayShamsi = com.example.util.DateUtils.getCurrentShamsiDate()
        val savedJson = prefs.getString("app_state_json", null)
        if (!savedJson.isNullOrEmpty()) {
            try {
                val parsed = parseJsonToState(savedJson)
                // اگر اطلاعات پیش‌فرض تستی قبلی (آقای صبوری) وجود داشت، نرم‌افزار را به حالت خام و تمیز بازگردان
                if (parsed.profile.teacherName == "آقای صبوری" && parsed.profile.schoolName == "دبستان شهید بهشتی") {
                    val freshState = getDefaultState().copy(currentDateShamsi = todayShamsi)
                    saveState(freshState)
                    return freshState
                }
                val todayRecord = parsed.attendanceHistory.find { it.date == todayShamsi }
                val updatedStudents = if (todayRecord != null) {
                    parsed.students.map { s ->
                        val rec = todayRecord.records.find { it.studentId == s.id }
                        if (rec != null) s.copy(status = rec.status) else s.copy(status = "حاضر")
                    }
                } else {
                    // با آغاز روز جدید، قبل از انجام حضور و غیاب همه دانش‌آموزان به حالت حاضر هستند
                    parsed.students.map { it.copy(status = "حاضر") }
                }
                return parsed.copy(currentDateShamsi = todayShamsi, students = updatedStudents)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        val defaultState = getDefaultState().copy(currentDateShamsi = todayShamsi)
        saveState(defaultState)
        return defaultState
    }

    private fun saveState(state: AppState) {
        try {
            val json = stateToJson(state)
            prefs.edit().putString("app_state_json", json).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun getDefaultState(): AppState {
        val defaultSubjects = listOf(
            SubjectItem(1, "ریاضی", true),
            SubjectItem(2, "فارسی", true),
            SubjectItem(3, "علوم تجربی", true),
            SubjectItem(4, "هدیه‌های آسمانی", true),
            SubjectItem(5, "مطالعات اجتماعی", true),
            SubjectItem(6, "هنر", true),
            SubjectItem(7, "قرآن", true),
            SubjectItem(8, "تربیت بدنی", true),
            SubjectItem(9, "املا و نگارش", true)
        )

        // برنامه هفتگی پیش‌فرض با روزهای مشخص و زنگ‌های خالی جهت پر کردن توسط معلم
        val defaultSchedule = listOf(
            DaySchedule(dayName = "شنبه", periods = emptyList()),
            DaySchedule(dayName = "یکشنبه", periods = emptyList()),
            DaySchedule(dayName = "دوشنبه", periods = emptyList()),
            DaySchedule(dayName = "سه‌شنبه", periods = emptyList()),
            DaySchedule(dayName = "چهارشنبه", periods = emptyList())
        )

        val today = com.example.util.DateUtils.getCurrentShamsiDate()
        return AppState(
            currentDateShamsi = today,
            dayType = "روز عادی",
            profile = ProfileSettings(
                teacherName = "",
                educationalTitle = "",
                schoolName = ""
            ),
            weeklySchedule = defaultSchedule,
            students = emptyList(),
            groups = emptyList(),
            subjects = defaultSubjects,
            teacherNotes = emptyList(),
            parentMeetings = emptyList(),
            attendanceHistory = emptyList()
        )
    }

    fun getDefaultAttendanceHistory(): List<DailyAttendance> {
        return emptyList()
    }

    // --- State mutations ---

    fun updateWeeklySchedule(schedule: List<DaySchedule>) {
        _state.update { it.copy(weeklySchedule = schedule) }
        saveState(_state.value)
    }

    fun updateDaySchedule(dayName: String, periods: List<String>) {
        _state.update { current ->
            val updated = current.weeklySchedule.map { day ->
                if (day.dayName == dayName) day.copy(periods = periods) else day
            }
            current.copy(weeklySchedule = updated)
        }
        saveState(_state.value)
    }

    fun updateProfileSettings(teacherName: String, educationalTitle: String, schoolName: String) {
        _state.update { current ->
            current.copy(
                profile = ProfileSettings(
                    teacherName = teacherName,
                    educationalTitle = educationalTitle,
                    schoolName = schoolName
                )
            )
        }
        saveState(_state.value)
    }

    fun setThemeMode(themeMode: String) {
        _state.update { it.copy(themeMode = themeMode) }
        saveState(_state.value)
    }

    fun setDate(date: String) {
        _state.update { current ->
            val dateRecord = current.attendanceHistory.find { it.date == date }
            val updatedStudents = if (dateRecord != null) {
                current.students.map { s ->
                    val rec = dateRecord.records.find { it.studentId == s.id }
                    if (rec != null) s.copy(status = rec.status) else s.copy(status = "حاضر")
                }
            } else {
                current.students.map { it.copy(status = "حاضر") }
            }
            current.copy(currentDateShamsi = date, students = updatedStudents)
        }
        saveState(_state.value)
    }

    fun syncWithDeviceDate(): String {
        val today = com.example.util.DateUtils.getCurrentShamsiDate()
        _state.update { current ->
            val todayRecord = current.attendanceHistory.find { it.date == today }
            val updatedStudents = if (todayRecord != null) {
                current.students.map { s ->
                    val rec = todayRecord.records.find { it.studentId == s.id }
                    if (rec != null) s.copy(status = rec.status) else s.copy(status = "حاضر")
                }
            } else {
                // با آغاز روز جدید، قبل از حضور غیاب همه به صورت اتومات حاضر هستند
                current.students.map { it.copy(status = "حاضر") }
            }
            current.copy(currentDateShamsi = today, students = updatedStudents)
        }
        saveState(_state.value)
        return today
    }

    fun setDayType(dayType: String) {
        _state.update { it.copy(dayType = dayType) }
        saveState(_state.value)
    }

    fun updateStudentAttendance(studentId: Long, newStatus: String) {
        // تغییر وضعیت بدون ذخیره در دفتر حضور و غیاب (تنها وضعیت جاری دانش‌آموز تغییر می‌کند)
        _state.update { current ->
            val updatedStudents = current.students.map { student ->
                if (student.id == studentId) student.copy(status = newStatus) else student
            }
            current.copy(students = updatedStudents)
        }
        saveState(_state.value)
    }

    fun submitDailyAttendance(date: String, records: List<StudentAttendanceRecord>): Boolean {
        _state.update { current ->
            val newRec = DailyAttendance(date = date, records = records)
            val history = current.attendanceHistory.toMutableList()
            val existingIndex = history.indexOfFirst { it.date == date }
            val newHistory = if (existingIndex >= 0) {
                history[existingIndex] = newRec
                history
            } else {
                listOf(newRec) + history
            }
            val updatedStudents = current.students.map { s ->
                val rec = records.find { it.studentId == s.id }
                if (rec != null) s.copy(status = rec.status) else s
            }
            current.copy(
                students = updatedStudents,
                attendanceHistory = newHistory
            )
        }
        saveState(_state.value)
        return true
    }

    fun saveHistoricalAttendance(date: String, records: List<StudentAttendanceRecord>) {
        _state.update { current ->
            val history = current.attendanceHistory.toMutableList()
            val existingIndex = history.indexOfFirst { it.date == date }
            val newHistory = if (existingIndex >= 0) {
                history[existingIndex] = history[existingIndex].copy(records = records)
                history
            } else {
                listOf(DailyAttendance(date, records)) + history
            }

            val updatedStudents = if (date == current.currentDateShamsi) {
                current.students.map { s ->
                    val rec = records.find { it.studentId == s.id }
                    if (rec != null) s.copy(status = rec.status) else s
                }
            } else {
                current.students
            }

            current.copy(
                students = updatedStudents,
                attendanceHistory = newHistory
            )
        }
        saveState(_state.value)
    }

    fun markAllStudentsPresent() {
        // تغییر وضعیت همه به حاضر قبل از لمس دکمه ذخیره (بدون ذخیره در دفتر)
        _state.update { current ->
            val updatedStudents = current.students.map { it.copy(status = "حاضر") }
            current.copy(students = updatedStudents)
        }
        saveState(_state.value)
    }

    fun updateHistoricalAttendance(date: String, studentId: Long, newStatus: String) {
        _state.update { current ->
            val history = current.attendanceHistory.toMutableList()
            val existingIndex = history.indexOfFirst { it.date == date }
            val newHistory = if (existingIndex >= 0) {
                val recs = history[existingIndex].records.toMutableList()
                val rIdx = recs.indexOfFirst { it.studentId == studentId }
                if (rIdx >= 0) {
                    recs[rIdx] = recs[rIdx].copy(status = newStatus)
                } else {
                    recs.add(StudentAttendanceRecord(studentId, newStatus))
                }
                history[existingIndex] = history[existingIndex].copy(records = recs)
                history
            } else {
                val initialRecs = current.students.map {
                    StudentAttendanceRecord(it.id, if (it.id == studentId) newStatus else "حاضر")
                }
                listOf(DailyAttendance(date, initialRecs)) + history
            }

            val updatedStudents = if (date == current.currentDateShamsi) {
                current.students.map {
                    if (it.id == studentId) it.copy(status = newStatus) else it
                }
            } else {
                current.students
            }

            current.copy(
                students = updatedStudents,
                attendanceHistory = newHistory
            )
        }
        saveState(_state.value)
    }

    fun markAllPresentForDate(date: String) {
        _state.update { current ->
            val history = current.attendanceHistory.toMutableList()
            val existingIndex = history.indexOfFirst { it.date == date }
            val allPresentRecs = current.students.map { StudentAttendanceRecord(it.id, "حاضر") }
            val newHistory = if (existingIndex >= 0) {
                history[existingIndex] = history[existingIndex].copy(records = allPresentRecs)
                history
            } else {
                listOf(DailyAttendance(date, allPresentRecs)) + history
            }

            val updatedStudents = if (date == current.currentDateShamsi) {
                current.students.map { it.copy(status = "حاضر") }
            } else {
                current.students
            }

            current.copy(
                students = updatedStudents,
                attendanceHistory = newHistory
            )
        }
        saveState(_state.value)
    }

    fun addHistoricalAttendanceDate(date: String) {
        _state.update { current ->
            if (current.attendanceHistory.any { it.date == date }) {
                current
            } else {
                val newRec = DailyAttendance(
                    date = date,
                    records = current.students.map { StudentAttendanceRecord(it.id, "حاضر") }
                )
                current.copy(attendanceHistory = listOf(newRec) + current.attendanceHistory)
            }
        }
        saveState(_state.value)
    }

    fun deleteHistoricalAttendanceDate(date: String) {
        _state.update { current ->
            current.copy(
                attendanceHistory = current.attendanceHistory.filterNot { it.date == date }
            )
        }
        saveState(_state.value)
    }

    fun addStudent(student: Student): Boolean {
        // [دستور دمو] بررسی سقف ۱۰ دانش‌آموز در صورت فعال بودن نسخه دمو
        if (com.example.util.DemoConfig.isDemoActive(appContext) && _state.value.students.size >= com.example.util.DemoConfig.MAX_STUDENTS_COUNT) {
            return false
        }

        val exists = _state.value.students.any {
            it.name.trim().equals(student.name.trim(), ignoreCase = true) ||
            (it.shad.isNotBlank() && it.shad.trim() == student.shad.trim())
        }
        if (exists) return false

        _state.update { current ->
            current.copy(students = current.students + student)
        }
        saveState(_state.value)
        return true
    }

    fun addStudent(name: String, shad: String, birthMonth: String): Boolean {
        val newStudent = Student(
            id = System.currentTimeMillis(),
            name = name,
            status = "حاضر",
            shad = shad,
            birthMonth = birthMonth,
            evaluations = emptyList()
        )
        return addStudent(newStudent)
    }

    fun updateStudent(student: Student): Boolean {
        val existsOther = _state.value.students.any {
            it.id != student.id && (
                it.name.trim().equals(student.name.trim(), ignoreCase = true) ||
                (it.shad.isNotBlank() && it.shad.trim() == student.shad.trim())
            )
        }
        if (existsOther) return false

        _state.update { current ->
            current.copy(
                students = current.students.map {
                    if (it.id == student.id) student else it
                }
            )
        }
        saveState(_state.value)
        return true
    }

    fun deleteStudent(studentId: Long) {
        _state.update { current ->
            current.copy(students = current.students.filterNot { it.id == studentId })
        }
        saveState(_state.value)
    }

    fun addEvaluation(studentId: Long, subject: String, type: String, score: String, date: String) {
        val newEval = Evaluation(
            subject = subject,
            type = type,
            score = score,
            date = date
        )
        _state.update { current ->
            current.copy(
                students = current.students.map { student ->
                    if (student.id == studentId) {
                        student.copy(evaluations = student.evaluations + newEval)
                    } else {
                        student
                    }
                }
            )
        }
        saveState(_state.value)
    }

    fun deleteEvaluation(studentId: Long, evalId: String) {
        _state.update { current ->
            current.copy(
                students = current.students.map { student ->
                    if (student.id == studentId) {
                        student.copy(evaluations = student.evaluations.filter { it.id != evalId })
                    } else {
                        student
                    }
                }
            )
        }
        saveState(_state.value)
    }

    fun toggleSubject(subjectId: Long, enabled: Boolean) {
        _state.update { current ->
            current.copy(
                subjects = current.subjects.map {
                    if (it.id == subjectId) it.copy(enabled = enabled) else it
                }
            )
        }
        saveState(_state.value)
    }

    fun updateSubjectName(subjectId: Long, newName: String) {
        _state.update { current ->
            current.copy(
                subjects = current.subjects.map {
                    if (it.id == subjectId) it.copy(name = newName) else it
                }
            )
        }
        saveState(_state.value)
    }

    fun addSubject(name: String) {
        val newSub = SubjectItem(
            id = System.currentTimeMillis(),
            name = name,
            enabled = true
        )
        _state.update { current ->
            current.copy(subjects = current.subjects + newSub)
        }
        saveState(_state.value)
    }

    fun deleteSubject(subjectId: Long) {
        _state.update { current ->
            current.copy(subjects = current.subjects.filterNot { it.id == subjectId })
        }
        saveState(_state.value)
    }

    fun updateGroupScore(groupIndex: Int, delta: Int) {
        _state.update { current ->
            if (groupIndex in current.groups.indices) {
                val updatedGroups = current.groups.toMutableList()
                val g = updatedGroups[groupIndex]
                updatedGroups[groupIndex] = g.copy(score = g.score + delta)
                current.copy(groups = updatedGroups)
            } else current
        }
        saveState(_state.value)
    }

    fun addGroup(name: String, members: List<String>) {
        val newGroup = GroupItem(
            id = System.currentTimeMillis(),
            name = name,
            score = 0,
            members = members
        )
        _state.update { current ->
            current.copy(groups = current.groups + newGroup)
        }
        saveState(_state.value)
    }

    fun updateGroup(groupIndex: Int, name: String, members: List<String>) {
        _state.update { current ->
            if (groupIndex in current.groups.indices) {
                val updated = current.groups.toMutableList()
                val old = updated[groupIndex]
                updated[groupIndex] = old.copy(name = name, members = members)
                current.copy(groups = updated)
            } else current
        }
        saveState(_state.value)
    }

    fun updateGroupById(groupId: Long, name: String, members: List<String>) {
        _state.update { current ->
            current.copy(
                groups = current.groups.map {
                    if (it.id == groupId) it.copy(name = name, members = members) else it
                }
            )
        }
        saveState(_state.value)
    }

    fun deleteGroup(groupIndex: Int) {
        _state.update { current ->
            if (groupIndex in current.groups.indices) {
                val updated = current.groups.toMutableList()
                updated.removeAt(groupIndex)
                current.copy(groups = updated)
            } else current
        }
        saveState(_state.value)
    }

    fun deleteGroupById(groupId: Long) {
        _state.update { current ->
            current.copy(groups = current.groups.filterNot { it.id == groupId })
        }
        saveState(_state.value)
    }

    fun addTeacherNote(title: String, content: String, date: String) {
        val newNote = TeacherNote(
            id = System.currentTimeMillis(),
            title = title,
            content = content,
            date = date
        )
        _state.update { current ->
            current.copy(teacherNotes = current.teacherNotes + newNote)
        }
        saveState(_state.value)
    }

    fun deleteTeacherNote(id: Long) {
        _state.update { current ->
            current.copy(teacherNotes = current.teacherNotes.filterNot { it.id == id })
        }
        saveState(_state.value)
    }

    fun addParentMeeting(title: String, date: String, summary: String) {
        val newMeeting = ParentMeeting(
            id = System.currentTimeMillis(),
            title = title,
            date = date,
            summary = summary
        )
        _state.update { current ->
            current.copy(parentMeetings = current.parentMeetings + newMeeting)
        }
        saveState(_state.value)
    }

    fun deleteParentMeeting(id: Long) {
        _state.update { current ->
            current.copy(parentMeetings = current.parentMeetings.filterNot { it.id == id })
        }
        saveState(_state.value)
    }

    // --- لیگ عدالت (Justice League) ---

    data class LeagueDrawResult(
        val selectedStudent: Student?,
        val isAllCompleted: Boolean,
        val message: String
    )

    fun drawJusticeLeagueStudent(): LeagueDrawResult {
        var result: LeagueDrawResult? = null
        _state.update { current ->
            // Filter to present students (status != "غایب" && status != "غیرموجه")
            val presentStudents = current.students.filter { it.status != "غایب" && it.status != "غیرموجه" }

            if (presentStudents.isEmpty()) {
                result = LeagueDrawResult(
                    selectedStudent = null,
                    isAllCompleted = false,
                    message = "هیچ دانش‌آموز حاضری در کلاس برای قرعه‌کشی یافت نشد."
                )
                return@update current
            }

            val currentLeague = current.justiceLeague
            // Find present students who have not been picked in this league yet
            val unpickedPresent = presentStudents.filter { it.id.toInt() !in currentLeague.selectedStudentIds }

            if (unpickedPresent.isNotEmpty()) {
                val picked = unpickedPresent.random()
                val updatedSelectedIds = currentLeague.selectedStudentIds + picked.id.toInt()

                // Check if all students in class (or all eligible) have now been picked
                val allClassIds = current.students.map { it.id.toInt() }.toSet()
                val isCompleted = updatedSelectedIds.toSet().containsAll(allClassIds)

                val updatedLeague = currentLeague.copy(
                    selectedStudentIds = updatedSelectedIds,
                    lastSelectedStudentId = picked.id.toInt(),
                    isLeagueFinished = isCompleted
                )
                result = LeagueDrawResult(
                    selectedStudent = picked,
                    isAllCompleted = isCompleted,
                    message = if (isCompleted) "تمامی دانش‌آموزان کلاس حداقل یک‌بار در این دور لیگ انتخاب شدند." else "دانش‌آموز منتخب قرعه‌کشی شد."
                )
                current.copy(justiceLeague = updatedLeague)
            } else {
                // All present students have already been picked in this league
                val allClassIds = current.students.map { it.id.toInt() }.toSet()
                val allCompleted = currentLeague.selectedStudentIds.toSet().containsAll(allClassIds)

                if (allCompleted || currentLeague.isLeagueFinished) {
                    result = LeagueDrawResult(
                        selectedStudent = null,
                        isAllCompleted = true,
                        message = "تمامی دانش‌آموزان کلاس در این دور از لیگ عدالت حداقل یک‌بار انتخاب شده‌اند. می‌توانید دور جدید را آغاز کنید."
                    )
                    current.copy(justiceLeague = currentLeague.copy(isLeagueFinished = true))
                } else {
                    // Some students in class were not picked yet, but they are absent today
                    val absentUnpicked = current.students.filter { it.id.toInt() !in currentLeague.selectedStudentIds }
                    val absentNames = absentUnpicked.joinToString("، ") { it.name }
                    result = LeagueDrawResult(
                        selectedStudent = null,
                        isAllCompleted = false,
                        message = "تمامی دانش‌آموزان حاضر امروز قبلاً انتخاب شده‌اند. دانش‌آموزان باقی‌مانده غایب هستند ($absentNames)."
                    )
                    current
                }
            }
        }
        saveState(_state.value)
        return result ?: LeagueDrawResult(null, false, "")
    }

    fun startNewJusticeLeague() {
        _state.update { current ->
            val nextRound = current.justiceLeague.roundNumber + 1
            current.copy(
                justiceLeague = JusticeLeagueData(
                    roundNumber = nextRound,
                    selectedStudentIds = emptyList(),
                    lastSelectedStudentId = null,
                    isLeagueFinished = false
                )
            )
        }
        saveState(_state.value)
    }

    fun resetJusticeLeagueCurrentRound() {
        _state.update { current ->
            current.copy(
                justiceLeague = current.justiceLeague.copy(
                    selectedStudentIds = emptyList(),
                    lastSelectedStudentId = null,
                    isLeagueFinished = false
                )
            )
        }
        saveState(_state.value)
    }

    // --- Backup & Restore (Local File Storage + JSON) ---

    fun exportDataJson(): String {
        return stateToJson(_state.value)
    }

    fun importDataJson(jsonString: String): Boolean {
        return try {
            val newState = parseJsonToState(jsonString)
            _state.value = newState
            saveState(newState)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun listLocalBackups(): List<LocalBackupFile> {
        return backupManager.listLocalBackups()
    }

    fun getBackupStoragePath(): String {
        return backupManager.getStoragePath()
    }

    fun isUsingCustomBackupPath(): Boolean = backupManager.isUsingCustomPath()

    fun setCustomBackupPath(path: String?, copyExisting: Boolean = true): Boolean {
        return backupManager.setCustomBackupPath(path, copyExisting)
    }

    fun resetToDefaultStoragePath() {
        backupManager.resetToDefaultStoragePath()
    }

    fun getSuggestedStorageLocations(): List<StorageLocationOption> {
        return backupManager.getSuggestedStorageLocations()
    }

    fun createLocalBackup(title: String? = null): LocalBackupFile? {
        return backupManager.createLocalBackup(exportDataJson(), title)
    }

    fun restoreFromLocalBackup(file: File): Boolean {
        return try {
            // Safety backup of current state before restoration
            backupManager.createLocalBackup(exportDataJson(), "پیش‌از_بازیابی", isAutoBackup = false)
            val json = backupManager.readBackupFile(file) ?: return false
            importDataJson(json)
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun deleteLocalBackup(file: File): Boolean {
        return backupManager.deleteBackup(file)
    }

    fun exportBackupToUri(uri: Uri): Boolean {
        return backupManager.writeToUri(uri, exportDataJson())
    }

    fun importBackupFromUri(uri: Uri): Boolean {
        return try {
            val json = backupManager.readFromUri(uri) ?: return false
            // Safety backup before restore
            backupManager.createLocalBackup(exportDataJson(), "پیش‌از_بازیابی", isAutoBackup = false)
            importDataJson(json)
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun parseBackupSummary(jsonString: String): BackupSummary {
        return backupManager.parseBackupSummary(jsonString)
    }

    fun readBackupFileText(file: File): String? {
        return backupManager.readBackupFile(file)
    }

    fun shareBackup(context: Context, file: File) {
        backupManager.shareBackupFile(context, file)
    }

    private fun stateToJson(state: AppState): String {
        val root = JSONObject()

        val studentsArray = JSONArray()
        state.students.forEach { studentsArray.put(it.toJsonObject()) }
        root.put("students", studentsArray)

        val groupsArray = JSONArray()
        state.groups.forEach { groupsArray.put(it.toJsonObject()) }
        root.put("groups", groupsArray)

        val subjectsArray = JSONArray()
        state.subjects.forEach { subjectsArray.put(it.toJsonObject()) }
        root.put("subjects", subjectsArray)

        val notesArray = JSONArray()
        state.teacherNotes.forEach { notesArray.put(it.toJsonObject()) }
        root.put("teacherNotes", notesArray)

        val meetingsArray = JSONArray()
        state.parentMeetings.forEach { meetingsArray.put(it.toJsonObject()) }
        root.put("parentMeetings", meetingsArray)

        val scheduleArray = JSONArray()
        state.weeklySchedule.forEach { scheduleArray.put(it.toJsonObject()) }
        root.put("weeklySchedule", scheduleArray)

        val attendanceHistoryArray = JSONArray()
        state.attendanceHistory.forEach { attendanceHistoryArray.put(it.toJsonObject()) }
        root.put("attendanceHistory", attendanceHistoryArray)

        root.put("profile", state.profile.toJsonObject())
        root.put("currentDateShamsi", state.currentDateShamsi)
        root.put("dayType", state.dayType)
        root.put("justiceLeague", state.justiceLeague.toJsonObject())
        root.put("themeMode", state.themeMode)

        return root.toString(2)
    }

    private fun parseJsonToState(jsonString: String): AppState {
        val root = JSONObject(jsonString)

        val profileObj = root.optJSONObject("profile")
        val profile = ProfileSettings.fromJsonObject(profileObj)

        val scheduleList = mutableListOf<DaySchedule>()
        val schedArr = root.optJSONArray("weeklySchedule")
        if (schedArr != null && schedArr.length() > 0) {
            for (i in 0 until schedArr.length()) {
                val obj = schedArr.optJSONObject(i)
                if (obj != null) {
                    scheduleList.add(DaySchedule.fromJsonObject(obj))
                }
            }
        } else {
            // برنامه با زنگ‌های خالی جهت پر کردن دلخواه توسط معلم
            listOf(
                DaySchedule("شنبه", emptyList()),
                DaySchedule("یکشنبه", emptyList()),
                DaySchedule("دوشنبه", emptyList()),
                DaySchedule("سه‌شنبه", emptyList()),
                DaySchedule("چهارشنبه", emptyList())
            ).forEach { scheduleList.add(it) }
        }

        val studentList = mutableListOf<Student>()
        val studentsArr = root.optJSONArray("students")
        if (studentsArr != null) {
            for (i in 0 until studentsArr.length()) {
                val obj = studentsArr.optJSONObject(i)
                if (obj != null) {
                    studentList.add(Student.fromJsonObject(obj))
                }
            }
        }

        val groupList = mutableListOf<GroupItem>()
        val groupsArr = root.optJSONArray("groups")
        if (groupsArr != null) {
            for (i in 0 until groupsArr.length()) {
                val obj = groupsArr.optJSONObject(i)
                if (obj != null) {
                    groupList.add(GroupItem.fromJsonObject(obj))
                }
            }
        }

        val subjectList = mutableListOf<SubjectItem>()
        val subsArr = root.optJSONArray("subjects")
        if (subsArr != null) {
            for (i in 0 until subsArr.length()) {
                val obj = subsArr.optJSONObject(i)
                if (obj != null) {
                    subjectList.add(SubjectItem.fromJsonObject(obj))
                }
            }
        }

        val notesList = mutableListOf<TeacherNote>()
        val notesArr = root.optJSONArray("teacherNotes")
        if (notesArr != null) {
            for (i in 0 until notesArr.length()) {
                val obj = notesArr.optJSONObject(i)
                if (obj != null) {
                    notesList.add(TeacherNote.fromJsonObject(obj))
                }
            }
        }

        val meetingsList = mutableListOf<ParentMeeting>()
        val meetArr = root.optJSONArray("parentMeetings")
        if (meetArr != null) {
            for (i in 0 until meetArr.length()) {
                val obj = meetArr.optJSONObject(i)
                if (obj != null) {
                    meetingsList.add(ParentMeeting.fromJsonObject(obj))
                }
            }
        }

        val attendanceHistoryList = mutableListOf<DailyAttendance>()
        val attArr = root.optJSONArray("attendanceHistory")
        if (attArr != null && attArr.length() > 0) {
            for (i in 0 until attArr.length()) {
                val obj = attArr.optJSONObject(i)
                if (obj != null) {
                    attendanceHistoryList.add(DailyAttendance.fromJsonObject(obj))
                }
            }
        }

        val todayShamsi = com.example.util.DateUtils.getCurrentShamsiDate()
        val date = root.optString("currentDateShamsi", todayShamsi)
        val dayType = root.optString("dayType", "روز عادی")
        val justiceLeague = JusticeLeagueData.fromJsonObject(root.optJSONObject("justiceLeague"))
        val themeMode = root.optString("themeMode", "DEFAULT")

        return AppState(
            currentDateShamsi = date,
            dayType = dayType,
            profile = profile,
            weeklySchedule = scheduleList,
            students = studentList,
            groups = groupList,
            subjects = subjectList,
            teacherNotes = notesList,
            parentMeetings = meetingsList,
            attendanceHistory = attendanceHistoryList,
            justiceLeague = justiceLeague,
            themeMode = themeMode
        )
    }
}
