package com.example.util

import android.content.Context
import android.content.SharedPreferences
import kotlin.math.floor
import kotlin.random.Random

/**
 * سیستم فعال‌سازی و صدور کلید اختصاصی نرم‌افزار (Activation System)
 * 
 * بر اساس درخواست:
 * - کد یوزر (u): یک عدد تصادفی ۶ رقمی در بدو نصب برنامه که تا حذف نرم‌افزار یا انقضای ۳۶۵ روز تغییر نمی‌کند.
 * - کلید فعال‌سازی (p): طبق فرمول دقیق:
 *   (((((((u × 65) - 230) ÷ 27) + 142) × 4) - 75) ÷ 3) + 39
 *   سپس حذف اعشار، انتخاب ۶ رقم اول یا افزودن صفر در صورت کمتر بودن از ۶ رقم.
 * - اعتبار نسخه پرو ۳۶۵ روز بوده و پس از آن خودکار به دمو بازمی‌گردد و کد یوزر جدید تولید می‌شود.
 */
object ActivationManager {

    private const val PREFS_NAME = "activation_license_prefs"
    private const val KEY_USER_CODE = "key_license_user_code"
    private const val KEY_ACTIVATION_KEY = "key_license_activation_key"
    private const val KEY_IS_PRO = "key_license_is_pro_active"
    private const val KEY_PRO_ACTIVATION_TIME = "key_license_activation_timestamp"

    // مدت اعتبار نسخه پرو: ۳۶۵ روز به میلی‌ثانیه
    const val PRO_DURATION_MILLIS = 365L * 24L * 60L * 60L * 1000L

    // آدرس صفحه و پشتیبانی روبیکا جهت خرید کلید
    const val RUBIKA_ACTIVATION_URL = "https://rubika.ir/ClassManagement"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    /**
     * محاسبه کلید فعال‌سازی طبق فرمول دقیق داده شده بر اساس کد یوزر (u):
     * (((((((u×65)-230)÷27)+142)×4)-75)÷3)+39
     */
    fun calculateActivationKey(userCode: Long): String {
        val step1 = (userCode.toDouble() * 65.0) - 230.0
        val step2 = step1 / 27.0
        val step3 = step2 + 142.0
        val step4 = step3 * 4.0
        val step5 = step4 - 75.0
        val step6 = step5 / 3.0
        val step7 = step6 + 39.0

        // حذف اعشار (قسمت صحیح)
        val intPart = floor(step7).toLong().toString()

        // عدد جدید اگر از ۶ رقم بیشتر است، ۶ رقم ابتدای آن را بردار و اگر کمتر است به آخر آن صفر اضافه کن
        return if (intPart.length > 6) {
            intPart.substring(0, 6)
        } else {
            intPart.padEnd(6, '0')
        }
    }

    /**
     * دریافت یا ساخت کد یوزر (u) برای دستگاه
     */
    @Synchronized
    fun getUserCode(context: Context): String {
        val prefs = getPrefs(context)
        var userCode = prefs.getString(KEY_USER_CODE, null)

        if (userCode.isNullOrBlank() || userCode.length != 6) {
            // تولید کد تصادفی ۶ رقمی
            val randomNum = Random.nextInt(100000, 1000000)
            userCode = randomNum.toString()
            val activationKey = calculateActivationKey(userCode.toLong())

            prefs.edit()
                .putString(KEY_USER_CODE, userCode)
                .putString(KEY_ACTIVATION_KEY, activationKey)
                .apply()
        }

        return userCode
    }

    /**
     * دریافت کلید فعال‌سازی (p) ذخیره شده یا محاسبه شده
     */
    @Synchronized
    fun getActivationKey(context: Context): String {
        val prefs = getPrefs(context)
        var key = prefs.getString(KEY_ACTIVATION_KEY, null)
        if (key.isNullOrBlank() || key.length != 6) {
            val userCode = getUserCode(context)
            key = calculateActivationKey(userCode.toLong())
            prefs.edit().putString(KEY_ACTIVATION_KEY, key).apply()
        }
        return key
    }

    /**
     * بررسی فعال بودن نسخه پرو و کنترل دوره ۳۶۵ روزه
     */
    @Synchronized
    fun isProActive(context: Context): Boolean {
        val prefs = getPrefs(context)
        val isPro = prefs.getBoolean(KEY_IS_PRO, false)
        if (!isPro) return false

        val activationTimestamp = prefs.getLong(KEY_PRO_ACTIVATION_TIME, 0L)
        val now = System.currentTimeMillis()

        // اگر ۳۶۵ روز گذشته باشد، بازگشت به نسخه دمو و ساخت کد یوزر جدید
        if (activationTimestamp > 0 && (now - activationTimestamp > PRO_DURATION_MILLIS)) {
            // انقضای اعتبار ۳۶۵ روزه
            prefs.edit()
                .putBoolean(KEY_IS_PRO, false)
                .putLong(KEY_PRO_ACTIVATION_TIME, 0L)
                .remove(KEY_USER_CODE)
                .remove(KEY_ACTIVATION_KEY)
                .apply()

            // تولید کد یوزر جدید بلافاصله
            getUserCode(context)
            return false
        }

        return true
    }

    /**
     * بررسی و ثبت کلید فعال‌سازی
     */
    @Synchronized
    fun verifyAndActivate(context: Context, enteredKey: String): Boolean {
        val cleanKey = DateUtils.toEnglishDigits(enteredKey.trim())
        val expectedKey = getActivationKey(context)

        if (cleanKey == expectedKey) {
            getPrefs(context).edit()
                .putBoolean(KEY_IS_PRO, true)
                .putLong(KEY_PRO_ACTIVATION_TIME, System.currentTimeMillis())
                .apply()
            return true
        }
        return false
    }

    /**
     * متن پیام درخواست خرید برای ارسال در روبیکا
     */
    fun createPurchaseMessage(userCode: String): String {
        return "سلام، وقت بخیر.\nکد یوزر نرم‌افزار من: $userCode\nدرخواست خرید کلید فعال‌سازی نسخه پرو نرم‌افزار مدیریت کلاس را دارم."
    }
}
