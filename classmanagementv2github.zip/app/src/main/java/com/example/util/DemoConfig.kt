package com.example.util

import android.content.Context

/**
 * تنظیمات و وضعیت نسخه دمو / پرو نرم‌افزار
 */
object DemoConfig {

    /**
     * وضعیت کلی پشتیبانی از حالت دمو
     */
    const val IS_DEMO_ENABLED = true

    /**
     * حداکثر تعداد دانش‌آموزان مجاز در نسخه دمو (۱۰ نفر)
     */
    const val MAX_STUDENTS_COUNT = 10

    /**
     * آدرس صفحه پشتیبانی و خرید کلید در روبیکا
     */
    const val RUBIKA_CHANNEL_URL = "https://rubika.ir/ClassManagement"
    const val RUBIKA_CHANNEL_DISPLAY = "Rubika.ir/ClassManagement"

    /**
     * متن پیام خطای نسخه دمو پس از ثبت ۱۰ دانش‌آموز
     */
    const val DEMO_LIMIT_ERROR_MESSAGE =
        "در نسخه دمو فقط امکان ذخیره ده نفر دانش‌آموز وجود دارد. برای ثبت تعداد بیشتر، باید نسخه پرو را فعال کنید."

    /**
     * متن پیام قفل بودن بازیابی فایل‌های پشتیبان در نسخه دمو
     */
    const val DEMO_RESTORE_LOCKED_MESSAGE =
        "قابلیت بازیابی فایل‌های پشتیبان در نسخه دمو قفل می‌باشد. برای بازگردانی اطلاعات و استفاده از تمامی قابلیت‌های نرم‌افزار، باید نسخه پرو را فعال کنید."

    /**
     * آیا در حال حاضر برنامه در وضعیت دمو است؟ (اگر پرو فعال باشد false بازمی‌گرداند)
     */
    fun isDemoActive(context: Context? = null): Boolean {
        if (!IS_DEMO_ENABLED) return false
        if (context == null) return true
        return !ActivationManager.isProActive(context)
    }

    /**
     * متن نگارش برنامه در پایین منوی همبرگری
     * - در حالت دمو: «طراح حامد صبوری ، نسخه دمو»
     * - در حالت پرو: «طراح حامد صبوری ، نسخه پرو»
     */
    fun getDrawerVersionText(context: Context? = null): String {
        val isPro = context?.let { ActivationManager.isProActive(it) } ?: false
        return if (isPro) {
            "طراح حامد صبوری ، نسخه پرو"
        } else {
            "طراح حامد صبوری ، نسخه دمو"
        }
    }
}
