package com.example.model

import org.json.JSONArray
import org.json.JSONObject

data class Evaluation(
    val id: String = java.util.UUID.randomUUID().toString(),
    val subject: String,
    val type: String, // کلاسی، ماهانه، سالانه
    val score: String, // خیلی خوب، خوب، قابل قبول، نیاز به تلاش
    val date: String
) {
    fun toJsonObject(): JSONObject {
        return JSONObject().apply {
            put("id", id)
            put("subject", subject)
            put("type", type)
            put("score", score)
            put("date", date)
        }
    }

    companion object {
        fun fromJsonObject(obj: JSONObject): Evaluation {
            return Evaluation(
                id = obj.optString("id", java.util.UUID.randomUUID().toString()),
                subject = obj.optString("subject", ""),
                type = obj.optString("type", "کلاسی"),
                score = obj.optString("score", "خیلی خوب"),
                date = obj.optString("date", "")
            )
        }
    }
}

data class Student(
    val id: Long,
    val name: String,
    val status: String = "حاضر", // حاضر، غایب، غیرموجه، موجه
    val shad: String = "",
    val birthDate: String = "",
    val birthPlace: String = "",
    val fatherName: String = "",
    val fatherBirthDate: String = "",
    val fatherJob: String = "",
    val fatherEducation: String = "",
    val motherName: String = "",
    val motherBirthDate: String = "",
    val motherJob: String = "",
    val motherEducation: String = "",
    val photoUri: String = "",
    val birthMonth: String = "مهر",
    val notes: String = "",
    val evaluations: List<Evaluation> = emptyList()
) {
    fun toJsonObject(): JSONObject {
        val evalsArray = JSONArray()
        evaluations.forEach { evalsArray.put(it.toJsonObject()) }
        return JSONObject().apply {
            put("id", id)
            put("name", name)
            put("status", status)
            put("shad", shad)
            put("birthDate", birthDate)
            put("birthPlace", birthPlace)
            put("fatherName", fatherName)
            put("fatherBirthDate", fatherBirthDate)
            put("fatherJob", fatherJob)
            put("fatherEducation", fatherEducation)
            put("motherName", motherName)
            put("motherBirthDate", motherBirthDate)
            put("motherJob", motherJob)
            put("motherEducation", motherEducation)
            put("photoUri", photoUri)
            put("birthMonth", birthMonth)
            put("notes", notes)
            put("evaluations", evalsArray)
        }
    }

    companion object {
        fun fromJsonObject(obj: JSONObject): Student {
            val evals = mutableListOf<Evaluation>()
            val arr = obj.optJSONArray("evaluations")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val evObj = arr.optJSONObject(i)
                    if (evObj != null) {
                        evals.add(Evaluation.fromJsonObject(evObj))
                    }
                }
            }
            return Student(
                id = obj.optLong("id", System.currentTimeMillis()),
                name = obj.optString("name", ""),
                status = obj.optString("status", "حاضر"),
                shad = obj.optString("shad", ""),
                birthDate = obj.optString("birthDate", ""),
                birthPlace = obj.optString("birthPlace", ""),
                fatherName = obj.optString("fatherName", ""),
                fatherBirthDate = obj.optString("fatherBirthDate", ""),
                fatherJob = obj.optString("fatherJob", ""),
                fatherEducation = obj.optString("fatherEducation", ""),
                motherName = obj.optString("motherName", ""),
                motherBirthDate = obj.optString("motherBirthDate", ""),
                motherJob = obj.optString("motherJob", ""),
                motherEducation = obj.optString("motherEducation", ""),
                photoUri = obj.optString("photoUri", ""),
                birthMonth = obj.optString("birthMonth", "مهر"),
                notes = obj.optString("notes", ""),
                evaluations = evals
            )
        }
    }
}

data class SubjectItem(
    val id: Long,
    val name: String,
    val enabled: Boolean = true
) {
    fun toJsonObject(): JSONObject {
        return JSONObject().apply {
            put("id", id)
            put("name", name)
            put("enabled", enabled)
        }
    }

    companion object {
        fun fromJsonObject(obj: JSONObject): SubjectItem {
            return SubjectItem(
                id = obj.optLong("id", System.currentTimeMillis()),
                name = obj.optString("name", ""),
                enabled = obj.optBoolean("enabled", true)
            )
        }
    }
}

data class GroupItem(
    val id: Long = System.currentTimeMillis(),
    val name: String,
    val score: Int = 0,
    val members: List<String> = emptyList()
) {
    fun toJsonObject(): JSONObject {
        val memArray = JSONArray()
        members.forEach { memArray.put(it) }
        return JSONObject().apply {
            put("id", id)
            put("name", name)
            put("score", score)
            put("members", memArray)
        }
    }

    companion object {
        fun fromJsonObject(obj: JSONObject): GroupItem {
            val memList = mutableListOf<String>()
            val arr = obj.optJSONArray("members")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    memList.add(arr.optString(i))
                }
            }
            return GroupItem(
                id = obj.optLong("id", System.currentTimeMillis()),
                name = obj.optString("name", ""),
                score = obj.optInt("score", 0),
                members = memList
            )
        }
    }
}

data class TeacherNote(
    val id: Long = System.currentTimeMillis(),
    val title: String,
    val content: String,
    val date: String
) {
    fun toJsonObject(): JSONObject {
        return JSONObject().apply {
            put("title", title)
            put("content", content)
            put("date", date)
        }
    }

    companion object {
        fun fromJsonObject(obj: JSONObject): TeacherNote {
            return TeacherNote(
                title = obj.optString("title", ""),
                content = obj.optString("content", ""),
                date = obj.optString("date", "")
            )
        }
    }
}

data class ParentMeeting(
    val id: Long = System.currentTimeMillis(),
    val title: String,
    val date: String,
    val summary: String
) {
    fun toJsonObject(): JSONObject {
        return JSONObject().apply {
            put("title", title)
            put("date", date)
            put("summary", summary)
        }
    }

    companion object {
        fun fromJsonObject(obj: JSONObject): ParentMeeting {
            return ParentMeeting(
                title = obj.optString("title", ""),
                date = obj.optString("date", ""),
                summary = obj.optString("summary", "")
            )
        }
    }
}

data class ProfileSettings(
    val teacherName: String = "آقای صبوری",
    val educationalTitle: String = "آموزگار پایه ابتدایی",
    val schoolName: String = "دبستان شهید بهشتی"
) {
    fun toJsonObject(): JSONObject {
        return JSONObject().apply {
            put("teacherName", teacherName)
            put("educationalTitle", educationalTitle)
            put("schoolName", schoolName)
        }
    }

    companion object {
        fun fromJsonObject(obj: JSONObject?): ProfileSettings {
            if (obj == null) return ProfileSettings()
            return ProfileSettings(
                teacherName = obj.optString("teacherName", "آقای صبوری"),
                educationalTitle = obj.optString("educationalTitle", "آموزگار پایه ابتدایی"),
                schoolName = obj.optString("schoolName", "دبستان شهید بهشتی")
            )
        }
    }
}

data class DaySchedule(
    val dayName: String, // شنبه, یکشنبه, دوشنبه, سه‌شنبه, چهارشنبه
    val periods: List<String> = emptyList() // زنگ ۱, زنگ ۲, ...
) {
    fun toJsonObject(): JSONObject {
        val periodsArray = JSONArray()
        periods.forEach { periodsArray.put(it) }
        return JSONObject().apply {
            put("dayName", dayName)
            put("periods", periodsArray)
        }
    }

    companion object {
        fun fromJsonObject(obj: JSONObject): DaySchedule {
            val pList = mutableListOf<String>()
            val arr = obj.optJSONArray("periods")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    pList.add(arr.optString(i, ""))
                }
            }
            return DaySchedule(
                dayName = obj.optString("dayName", ""),
                periods = pList
            )
        }
    }
}

data class StudentAttendanceRecord(
    val studentId: Long,
    val status: String = "حاضر" // حاضر، غایب، غیرموجه، موجه
) {
    fun toJsonObject(): JSONObject {
        return JSONObject().apply {
            put("studentId", studentId)
            put("status", status)
        }
    }

    companion object {
        fun fromJsonObject(obj: JSONObject): StudentAttendanceRecord {
            return StudentAttendanceRecord(
                studentId = obj.optLong("studentId"),
                status = obj.optString("status", "حاضر")
            )
        }
    }
}

data class DailyAttendance(
    val date: String, // e.g. "۱۴۰۳/۰۷/۱۵"
    val records: List<StudentAttendanceRecord> = emptyList()
) {
    fun toJsonObject(): JSONObject {
        val arr = JSONArray()
        records.forEach { arr.put(it.toJsonObject()) }
        return JSONObject().apply {
            put("date", date)
            put("records", arr)
        }
    }

    companion object {
        fun fromJsonObject(obj: JSONObject): DailyAttendance {
            val recs = mutableListOf<StudentAttendanceRecord>()
            val arr = obj.optJSONArray("records")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val recObj = arr.optJSONObject(i)
                    if (recObj != null) {
                        recs.add(StudentAttendanceRecord.fromJsonObject(recObj))
                    }
                }
            }
            return DailyAttendance(
                date = obj.optString("date", ""),
                records = recs
            )
        }
    }
}

data class JusticeLeagueData(
    val roundNumber: Int = 1,
    val selectedStudentIds: List<Int> = emptyList(),
    val lastSelectedStudentId: Int? = null,
    val isLeagueFinished: Boolean = false
) {
    fun toJsonObject(): JSONObject = JSONObject().apply {
        put("roundNumber", roundNumber)
        val arr = JSONArray()
        selectedStudentIds.forEach { arr.put(it) }
        put("selectedStudentIds", arr)
        if (lastSelectedStudentId != null) {
            put("lastSelectedStudentId", lastSelectedStudentId)
        }
        put("isLeagueFinished", isLeagueFinished)
    }

    companion object {
        fun fromJsonObject(obj: JSONObject?): JusticeLeagueData {
            if (obj == null) return JusticeLeagueData()
            val ids = mutableListOf<Int>()
            val arr = obj.optJSONArray("selectedStudentIds")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    ids.add(arr.optInt(i))
                }
            }
            val lastId = if (obj.has("lastSelectedStudentId") && !obj.isNull("lastSelectedStudentId")) {
                obj.optInt("lastSelectedStudentId")
            } else null

            return JusticeLeagueData(
                roundNumber = obj.optInt("roundNumber", 1),
                selectedStudentIds = ids,
                lastSelectedStudentId = lastId,
                isLeagueFinished = obj.optBoolean("isLeagueFinished", false)
            )
        }
    }
}

data class AppState(
    val currentDateShamsi: String = com.example.util.DateUtils.getCurrentShamsiDate(),
    val dayType: String = "روز عادی", // روز عادی، روز تعطیل، آموزش مجازی
    val profile: ProfileSettings = ProfileSettings(),
    val weeklySchedule: List<DaySchedule> = emptyList(),
    val students: List<Student> = emptyList(),
    val groups: List<GroupItem> = emptyList(),
    val subjects: List<SubjectItem> = emptyList(),
    val teacherNotes: List<TeacherNote> = emptyList(),
    val parentMeetings: List<ParentMeeting> = emptyList(),
    val attendanceHistory: List<DailyAttendance> = emptyList(),
    val justiceLeague: JusticeLeagueData = JusticeLeagueData(),
    val themeMode: String = "DEFAULT" // "DEFAULT", "GREEN", "RED"
)
