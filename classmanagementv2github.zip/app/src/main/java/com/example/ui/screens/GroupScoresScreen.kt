package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random
import com.example.data.ClassRepository
import com.example.model.GroupItem
import com.example.model.JusticeLeagueData
import com.example.model.Student
import com.example.ui.theme.*
import com.example.util.DateUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroupScoresScreen(
    groups: List<GroupItem>,
    students: List<Student> = emptyList(),
    justiceLeague: JusticeLeagueData = JusticeLeagueData(),
    onBack: () -> Unit,
    onScoreChange: (Int, Int) -> Unit,
    onAddGroup: (String, List<String>) -> Unit,
    onUpdateGroup: (Int, String, List<String>) -> Unit = { _, _, _ -> },
    onDeleteGroup: (Int) -> Unit,
    onDrawJusticeLeague: () -> ClassRepository.LeagueDrawResult = { ClassRepository.LeagueDrawResult(null, false, "") },
    onStartNewLeague: () -> Unit = {},
    onResetLeague: () -> Unit = {}
) {
    val context = LocalContext.current

    // دیالوگ لیگ عدالت
    var showJusticeLeagueDialog by remember { mutableStateOf(false) }

    // دیالوگ افزودن گروه جدید
    var showAddDialog by remember { mutableStateOf(false) }

    // گروه در حال ویرایش اعضا و نام
    var editingGroupIndex by remember { mutableStateOf<Int?>(null) }

    // گروه در حال حذف (برای نمایش پیام تأیید بله/خیر)
    var groupToDeleteIndex by remember { mutableStateOf<Int?>(null) }

    // مجموعه کل دانش‌آموزانی که در هر گروهی عضو شده‌اند
    val allAssignedMembers = remember(groups) {
        groups.flatMap { it.members }.toSet()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text("امتیازات و مدیریت گروه‌ها", fontWeight = FontWeight.Bold, color = Color(0xFF2C1E00))
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "بازگشت",
                            tint = Color(0xFF2C1E00)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AmberSecondary)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    showAddDialog = true
                },
                icon = { Icon(Icons.Default.GroupAdd, contentDescription = null) },
                text = { Text("افزودن گروه جدید", fontWeight = FontWeight.Bold) },
                containerColor = AmberSecondary,
                contentColor = Color(0xFF2C1E00),
                modifier = Modifier.testTag("add_group_fab")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BackgroundLight)
        ) {
            // نوار آماری بالای صفحه: تعداد گروه‌ها و وضعیت تخصیص دانش‌آموزان
            Surface(
                color = Color.White,
                shadowElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "تعداد گروه‌ها: ${groups.size} گروه",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "گروه‌بندی: ${allAssignedMembers.size} از ${students.size} نفر",
                        fontSize = 12.sp,
                        color = if (allAssignedMembers.size == students.size && students.isNotEmpty()) PrimaryGreenDark else TextSecondary,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // نوار بالای صفحه: کلید و وضعیت لیگ عدالت
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("justice_league_card"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB)),
                border = BorderStroke(1.5.dp, Color(0xFFF59E0B)),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFEF3C7)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.EmojiEvents,
                                contentDescription = "لیگ عدالت",
                                tint = Color(0xFFD97706),
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "لیگ عدالت (گردونه شانس)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color(0xFF78350F)
                                )
                            }
                            val pickedCount = justiceLeague.selectedStudentIds.size
                            val totalCount = students.size
                            Text(
                                text = "انتخاب شده: ${DateUtils.toPersianDigits(pickedCount)} از ${DateUtils.toPersianDigits(totalCount)} دانش‌آموز",
                                fontSize = 11.sp,
                                color = Color(0xFF92400E)
                            )
                        }
                    }

                    Button(
                        onClick = { showJusticeLeagueDialog = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFD97706),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("btn_justice_league")
                    ) {
                        Icon(Icons.Default.Casino, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("گردونه شانس", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }

            if (groups.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Groups,
                            contentDescription = null,
                            tint = AmberSecondary,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("هیچ گروهی تشکیل نشده است.", color = TextSecondary, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "با زدن دکمه «افزودن گروه جدید»، دانش‌آموزان را در گروه‌ها دسته‌بندی کنید.",
                            fontSize = 12.sp,
                            color = TextSecondary,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    itemsIndexed(groups) { index, group ->
                        GroupCard(
                            group = group,
                            onIncrement = { onScoreChange(index, 1) },
                            onDecrement = { onScoreChange(index, -1) },
                            onEdit = { editingGroupIndex = index },
                            onDeleteClick = { groupToDeleteIndex = index }
                        )
                    }
                    item {
                        Spacer(modifier = Modifier.height(76.dp))
                    }
                }
            }
        }
    }

    // ۱. دیالوگ افزودن گروه جدید
    if (showAddDialog) {
        // دانش‌آموزانی که در هیچ گروهی عضو نیستند
        val availableStudents = remember(students, allAssignedMembers) {
            students.filter { it.name !in allAssignedMembers }
        }

        AddGroupDialog(
            defaultName = "گروه ${groups.size + 1}",
            availableStudents = availableStudents,
            onDismiss = { showAddDialog = false },
            onConfirm = { groupName, selectedMembers ->
                val finalName = if (groupName.isBlank()) "گروه ${groups.size + 1}" else groupName.trim()
                onAddGroup(finalName, selectedMembers)
                showAddDialog = false
                Toast.makeText(context, "گروه «$finalName» با ${selectedMembers.size} عضو ایجاد شد.", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // ۲. دیالوگ ویرایش اعضا و نام گروه
    editingGroupIndex?.let { index ->
        if (index in groups.indices) {
            val group = groups[index]
            // دانش‌آموزان مجاز برای این گروه: اعضای فعلی همین گروه + دانش‌آموزانی که در هیچ گروهی عضو نیستند
            val selectableStudents = remember(students, allAssignedMembers, group) {
                students.filter { student ->
                    student.name in group.members || student.name !in allAssignedMembers
                }
            }

            EditGroupDialog(
                currentGroup = group,
                selectableStudents = selectableStudents,
                onDismiss = { editingGroupIndex = null },
                onConfirm = { updatedName, updatedMembers ->
                    val finalName = if (updatedName.isBlank()) group.name else updatedName.trim()
                    onUpdateGroup(index, finalName, updatedMembers)
                    editingGroupIndex = null
                    Toast.makeText(context, "تغییرات گروه «$finalName» با موفقیت ذخیره شد.", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }

    // ۳. دیالوگ تأیید حذف گروه (با دکمه‌های بله / خیر)
    groupToDeleteIndex?.let { index ->
        if (index in groups.indices) {
            val group = groups[index]
            AlertDialog(
                onDismissRequest = { groupToDeleteIndex = null },
                icon = {
                    Icon(
                        imageVector = Icons.Default.DeleteForever,
                        contentDescription = null,
                        tint = Color(0xFFDC2626),
                        modifier = Modifier.size(36.dp)
                    )
                },
                title = {
                    Text(
                        text = "تأیید حذف گروه",
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                },
                text = {
                    Text(
                        text = "آیا از حذف کامل گروه «${group.name}» مطمئن هستید؟ با حذف گروه، اعضای آن آزاد شده و می‌توانند در گروه‌های دیگر عضو شوند.",
                        fontSize = 14.sp,
                        lineHeight = 22.sp,
                        color = TextPrimary
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            onDeleteGroup(index)
                            Toast.makeText(context, "گروه «${group.name}» با موفقیت حذف شد.", Toast.LENGTH_SHORT).show()
                            groupToDeleteIndex = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                    ) {
                        Text("بله", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                },
                dismissButton = {
                    OutlinedButton(
                        onClick = {
                            groupToDeleteIndex = null
                        }
                    ) {
                        Text("خیر", fontWeight = FontWeight.Medium)
                    }
                }
            )
        }
    }

    // ۴. دیالوگ لیگ عدالت
    if (showJusticeLeagueDialog) {
        JusticeLeagueDialog(
            justiceLeague = justiceLeague,
            students = students,
            groups = groups,
            onDismiss = { showJusticeLeagueDialog = false },
            onDraw = onDrawJusticeLeague,
            onStartNewLeague = onStartNewLeague,
            onResetLeague = onResetLeague
        )
    }
}

/**
 * کارت نمایش هر گروه شامل نام، امتیاز، اعضا و دکمه‌های ویرایش و سطل آشغال
 */
@Composable
fun GroupCard(
    group: GroupItem,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit,
    onEdit: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(AmberSecondaryLight),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Groups,
                            contentDescription = null,
                            tint = Color(0xFFB45309),
                            modifier = Modifier.size(26.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = group.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "امتیاز: ${group.score}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFFB45309)
                        )
                    }
                }

                // دکمه‌های امتیازدهی و ویرایش و حذف
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onDecrement,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFF3F4F6))
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "کاهش امتیاز", tint = Color.DarkGray)
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    IconButton(
                        onClick = onIncrement,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(AmberSecondary)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "افزایش امتیاز", tint = Color(0xFF2C1E00))
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // دکمه ویرایش اعضا و مشخصات گروه
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "ویرایش اعضای گروه",
                            tint = Color(0xFF0284C7),
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // دکمه سطل آشغال برای حذف گروه
                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "حذف گروه",
                            tint = Color(0xFFEF4444),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = BorderLight, thickness = 0.5.dp)
            Spacer(modifier = Modifier.height(8.dp))

            // نمایش لیست اعضای گروه با چیپ‌های زیبا
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "اعضا (${group.members.size} نفر):",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.width(8.dp))

                if (group.members.isEmpty()) {
                    Text(
                        text = "عضوی انتخاب نشده است (جهت افزودن عضو دکمه ویرایش را بزنید)",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                } else {
                    Text(
                        text = group.members.joinToString(" • "),
                        fontSize = 12.sp,
                        color = TextPrimary,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

/**
 * دیالوگ افزودن گروه جدید با نام اختیاری و انتخاب اعضا منحصراً از بین دانش‌آموزان آزاد
 */
@Composable
fun AddGroupDialog(
    defaultName: String,
    availableStudents: List<Student>,
    onDismiss: () -> Unit,
    onConfirm: (name: String, members: List<String>) -> Unit
) {
    var groupNameInput by remember { mutableStateOf("") }
    val selectedMembers = remember { mutableStateListOf<String>() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("ایجاد گروه جدید", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = groupNameInput,
                    onValueChange = { groupNameInput = it },
                    label = { Text("نام گروه (اختیاری)") },
                    placeholder = { Text("پیش‌فرض: $defaultName") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "انتخاب اعضای گروه از بین دانش‌آموزان:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = TextPrimary
                )
                Text(
                    text = "تنها دانش‌آموزانی که در گروه دیگری عضو نیستند قابل انتخاب می‌باشند.",
                    fontSize = 11.sp,
                    color = TextSecondary
                )

                if (availableStudents.isEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFFEF3C7),
                        border = BorderStroke(1.dp, Color(0xFFFDE68A)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "هیچ دانش‌آموز آزادی وجود ندارد. همه دانش‌آموزان در سایر گروه‌ها عضو هستند.",
                                fontSize = 12.sp,
                                color = Color(0xFF92400E)
                            )
                        }
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, BorderLight),
                        color = Color(0xFFF8FAFC),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            availableStudents.forEach { student ->
                                val isSelected = student.name in selectedMembers
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            if (isSelected) {
                                                selectedMembers.remove(student.name)
                                            } else {
                                                selectedMembers.add(student.name)
                                            }
                                        }
                                        .padding(vertical = 4.dp, horizontal = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(
                                        checked = isSelected,
                                        onCheckedChange = { checked ->
                                            if (checked) {
                                                selectedMembers.add(student.name)
                                            } else {
                                                selectedMembers.remove(student.name)
                                            }
                                        },
                                        colors = CheckboxDefaults.colors(checkedColor = Color(0xFFB45309))
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = student.name,
                                        fontSize = 13.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = TextPrimary
                                    )
                                }
                            }
                        }
                    }
                }

                if (selectedMembers.isNotEmpty()) {
                    Text(
                        text = "اعضای انتخاب‌شده (${selectedMembers.size} نفر): ${selectedMembers.joinToString("، ")}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = PrimaryGreenDark
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalName = if (groupNameInput.isBlank()) defaultName else groupNameInput.trim()
                    onConfirm(finalName, selectedMembers.toList())
                },
                colors = ButtonDefaults.buttonColors(containerColor = AmberSecondary, contentColor = Color(0xFF2C1E00))
            ) {
                Text("ایجاد گروه", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("انصراف")
            }
        }
    )
}

/**
 * دیالوگ ویرایش اعضای گروه (امکان افزودن یا حذف دانش‌آموز از گروه و تغییر نام)
 */
@Composable
fun EditGroupDialog(
    currentGroup: GroupItem,
    selectableStudents: List<Student>,
    onDismiss: () -> Unit,
    onConfirm: (name: String, members: List<String>) -> Unit
) {
    var groupNameInput by remember { mutableStateOf(currentGroup.name) }
    val selectedMembers = remember {
        mutableStateListOf<String>().apply { addAll(currentGroup.members) }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("ویرایش گروه «${currentGroup.name}»", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = groupNameInput,
                    onValueChange = { groupNameInput = it },
                    label = { Text("نام گروه") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "مدیریت اعضای گروه:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = TextPrimary
                )
                Text(
                    text = "با علامت زدن یا برداشتن تیک، دانش‌آموز را به این گروه اضافه یا از آن حذف نمایید:",
                    fontSize = 11.sp,
                    color = TextSecondary
                )

                if (selectableStudents.isEmpty()) {
                    Text("هیچ دانش‌آموزی در دسترس نیست.", fontSize = 12.sp, color = TextSecondary)
                } else {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, BorderLight),
                        color = Color(0xFFF8FAFC),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            selectableStudents.forEach { student ->
                                val isMember = student.name in selectedMembers
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            if (isMember) {
                                                selectedMembers.remove(student.name)
                                            } else {
                                                selectedMembers.add(student.name)
                                            }
                                        }
                                        .padding(vertical = 4.dp, horizontal = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(
                                            checked = isMember,
                                            onCheckedChange = { checked ->
                                                if (checked) {
                                                    selectedMembers.add(student.name)
                                                } else {
                                                    selectedMembers.remove(student.name)
                                                }
                                            },
                                            colors = CheckboxDefaults.colors(checkedColor = Color(0xFFB45309))
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = student.name,
                                            fontSize = 13.sp,
                                            fontWeight = if (isMember) FontWeight.Bold else FontWeight.Normal,
                                            color = TextPrimary
                                        )
                                    }

                                    if (isMember) {
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = Color(0xFFDCFCE7),
                                            modifier = Modifier.padding(horizontal = 4.dp)
                                        ) {
                                            Text(
                                                text = "عضو گروه",
                                                fontSize = 10.sp,
                                                color = PrimaryGreenDark,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (selectedMembers.isNotEmpty()) {
                    Text(
                        text = "اعضای نهایی (${selectedMembers.size} نفر): ${selectedMembers.joinToString("، ")}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF0369A1)
                    )
                } else {
                    Text(
                        text = "توجه: هیچ عضوی برای این گروه انتخاب نشده است.",
                        fontSize = 11.sp,
                        color = Color(0xFFDC2626)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalName = if (groupNameInput.isBlank()) currentGroup.name else groupNameInput.trim()
                    onConfirm(finalName, selectedMembers.toList())
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
            ) {
                Text("ثبت تغییرات", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("انصراف")
            }
        }
    )
}

private data class ConfettiParticle(
    val angle: Float,
    val speed: Float,
    val color: Color,
    val size: Float,
    val isCircle: Boolean
)

/**
 * گردونه رولت چرخان برای قرعه‌کشی هیجان‌انگیز دانش‌آموزان در کلاس
 */
@Composable
fun RouletteWheel(
    rotationDegrees: Float,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.size(145.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .rotate(rotationDegrees)
        ) {
            val radius = size.minDimension / 2f
            val center = Offset(size.width / 2f, size.height / 2f)
            val sliceCount = 8
            val sweep = 360f / sliceCount
            val colors = listOf(
                Color(0xFFF59E0B), // کهربایی
                Color(0xFF10B981), // زمردی
                Color(0xFF0EA5E9), // آسمانی
                Color(0xFFEC4899), // صورتی
                Color(0xFF8B5CF6), // بنفش
                Color(0xFFEF4444), // قرمز
                Color(0xFF14B8A6), // فیروزه‌ای
                Color(0xFFF97316)  // نارنجی
            )

            for (i in 0 until sliceCount) {
                drawArc(
                    color = colors[i % colors.size],
                    startAngle = i * sweep,
                    sweepAngle = sweep,
                    useCenter = true,
                    size = Size(radius * 2, radius * 2),
                    topLeft = Offset(center.x - radius, center.y - radius)
                )
            }

            // لبه طلایی گردونه
            drawCircle(
                color = Color(0xFF78350F),
                radius = radius - 1.dp.toPx(),
                center = center,
                style = Stroke(width = 4.dp.toPx())
            )

            // نقاط نوری دور گردونه
            val dotCount = 16
            val dotRadius = radius - 6.dp.toPx()
            for (i in 0 until dotCount) {
                val rad = Math.toRadians(i * (360.0 / dotCount))
                val dx = center.x + (dotRadius * cos(rad)).toFloat()
                val dy = center.y + (dotRadius * sin(rad)).toFloat()
                drawCircle(
                    color = Color.White,
                    radius = 2.5.dp.toPx(),
                    center = Offset(dx, dy)
                )
            }

            // توپی مرکزی گردونه
            drawCircle(
                color = Color(0xFFD97706),
                radius = 22.dp.toPx(),
                center = center
            )
            drawCircle(
                color = Color(0xFFFEF3C7),
                radius = 16.dp.toPx(),
                center = center
            )
        }

        // ستاره وسط گردونه
        Icon(
            imageVector = Icons.Default.Stars,
            contentDescription = null,
            tint = Color(0xFFB45309),
            modifier = Modifier.size(20.dp)
        )

        // عقربه / شاخص گردونه در بالای چرخ (ساعت ۱۲ به سمت پایین)
        Canvas(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .size(22.dp, 20.dp)
                .offset(y = (-4).dp)
        ) {
            val path = Path().apply {
                moveTo(size.width / 2f, size.height)
                lineTo(0f, 0f)
                lineTo(size.width, 0f)
                close()
            }
            drawPath(path, color = Color(0xFFDC2626))
            drawPath(path, color = Color.White, style = Stroke(width = 1.5.dp.toPx()))
        }
    }
}

/**
 * دیالوگ لیگ عدالت و گردونه شانس برای قرعه‌کشی عادلانه و پرهیجان بین دانش‌آموزان حاضر کلاس
 */
@Composable
fun JusticeLeagueDialog(
    justiceLeague: JusticeLeagueData,
    students: List<Student>,
    groups: List<GroupItem>,
    onDismiss: () -> Unit,
    onDraw: () -> ClassRepository.LeagueDrawResult,
    onStartNewLeague: () -> Unit,
    onResetLeague: () -> Unit
) {
    var lastDrawResult by remember { mutableStateOf<ClassRepository.LeagueDrawResult?>(null) }
    var isSpinning by remember { mutableStateOf(false) }
    var currentSpinningName by remember { mutableStateOf("") }
    var showResetConfirm by remember { mutableStateOf(false) }
    var activeTab by remember { mutableIntStateOf(0) } // 0: باقی‌مانده‌ها، 1: انتخاب شده‌ها

    val coroutineScope = rememberCoroutineScope()
    val wheelRotation = remember { Animatable(0f) }
    val confettiAnim = remember { Animatable(0f) }

    val particles = remember {
        val colors = listOf(
            Color(0xFFF59E0B), Color(0xFF10B981), Color(0xFF3B82F6),
            Color(0xFFEF4444), Color(0xFF8B5CF6), Color(0xFFEC4899),
            Color(0xFFF97316), Color(0xFFEAB308)
        )
        List(36) {
            ConfettiParticle(
                angle = Random.nextFloat() * 360f,
                speed = 0.5f + Random.nextFloat() * 1.0f,
                color = colors.random(),
                size = 5f + Random.nextFloat() * 7f,
                isCircle = Random.nextBoolean()
            )
        }
    }

    // تفکیک دانش‌آموزان
    val pickedStudents = remember(students, justiceLeague.selectedStudentIds) {
        students.filter { it.id.toInt() in justiceLeague.selectedStudentIds }
    }
    val remainingStudents = remember(students, justiceLeague.selectedStudentIds) {
        students.filter { it.id.toInt() !in justiceLeague.selectedStudentIds }
    }
    val remainingPresent = remember(remainingStudents) {
        remainingStudents.filter { it.status != "غایب" && it.status != "غیرموجه" }
    }
    val remainingAbsent = remember(remainingStudents) {
        remainingStudents.filter { it.status == "غایب" || it.status == "غیرموجه" }
    }

    // دانش‌آموزی که باید به عنوان برگزیده نمایش داده شود
    val displayStudent = remember(lastDrawResult, justiceLeague.lastSelectedStudentId, students) {
        lastDrawResult?.selectedStudent ?: students.find { it.id.toInt() == justiceLeague.lastSelectedStudentId }
    }

    // یافتن نام گروه دانش‌آموز
    fun getStudentGroupName(studentName: String): String? {
        return groups.find { studentName in it.members }?.name
    }

    // تابع چرخش انیمیشنی گردونه با افت سرعت تدریجی
    fun startSpin() {
        if (isSpinning || remainingPresent.isEmpty()) return
        isSpinning = true
        val drawResult = onDraw()
        val chosenStudent = drawResult.selectedStudent
        if (chosenStudent == null) {
            isSpinning = false
            lastDrawResult = drawResult
            return
        }

        coroutineScope.launch {
            // ۱. چرخش گردونه فیزیکی
            launch {
                val startAngle = wheelRotation.value
                val targetAngle = startAngle + 1800f + ((chosenStudent.id.toInt() * 47) % 360)
                wheelRotation.animateTo(
                    targetValue = targetAngle,
                    animationSpec = tween(
                        durationMillis = 2600,
                        easing = FastOutSlowInEasing
                    )
                )
            }

            // ۲. گردش پیوسته و سریع نام‌ها با شتاب معکوس (Deceleration)
            val poolNames = (remainingPresent.map { it.name } + listOf(chosenStudent.name)).distinct().shuffled()
            val totalSteps = 26
            for (step in 0 until totalSteps) {
                if (step == totalSteps - 1) {
                    currentSpinningName = chosenStudent.name
                } else {
                    currentSpinningName = poolNames[step % poolNames.size]
                }
                val progress = step.toFloat() / totalSteps
                val delayMs = (40 + (progress * progress * 320)).toLong()
                delay(delayMs)
            }

            // ۳. فرود روی نام برنده و اتمام چرخش
            lastDrawResult = drawResult
            isSpinning = false

            // ۴. انفجار ذرات شادباش و کانفتی
            confettiAnim.snapTo(0f)
            confettiAnim.animateTo(
                targetValue = 1f,
                animationSpec = tween(1600, easing = LinearEasing)
            )
        }
    }

    AlertDialog(
        onDismissRequest = {
            if (!isSpinning) onDismiss()
        },
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFEF3C7)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Casino,
                            contentDescription = null,
                            tint = Color(0xFFD97706),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "گردونه شانس و لیگ عدالت",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = Color(0xFF78350F)
                    )
                }
                IconButton(
                    onClick = onDismiss,
                    enabled = !isSpinning,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(Icons.Default.Close, contentDescription = "بستن", tint = TextSecondary)
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // کارت وضعیت و پیشرفت دور جاری لیگ
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB)),
                    border = BorderStroke(1.dp, Color(0xFFFDE68A))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "پیشرفت لیگ عدالت:",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF92400E)
                            )
                            Text(
                                text = "${DateUtils.toPersianDigits(pickedStudents.size)} از ${DateUtils.toPersianDigits(students.size)} دانش‌آموز",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFB45309)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        val progress = if (students.isNotEmpty()) pickedStudents.size.toFloat() / students.size.toFloat() else 0f
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = Color(0xFFD97706),
                            trackColor = Color(0xFFFEF3C7)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "حاضرین باقی‌مانده: ${DateUtils.toPersianDigits(remainingPresent.size)} نفر",
                                fontSize = 11.sp,
                                color = PrimaryGreenDark,
                                fontWeight = FontWeight.Medium
                            )
                            if (remainingAbsent.isNotEmpty()) {
                                Text(
                                    text = "غایبین باقی‌مانده: ${DateUtils.toPersianDigits(remainingAbsent.size)} نفر",
                                    fontSize = 11.sp,
                                    color = Color(0xFFDC2626),
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // وضعیت‌های مختلف قرعه‌کشی
                if (justiceLeague.isLeagueFinished || (remainingStudents.isEmpty() && students.isNotEmpty())) {
                    // دور کامل شده است
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                        border = BorderStroke(1.5.dp, PrimaryGreen)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Celebration,
                                contentDescription = null,
                                tint = PrimaryGreenDark,
                                modifier = Modifier.size(44.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "تبریک! تمام دانش‌آموزان انتخاب شدند",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = PrimaryGreenDark
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "تمام ${DateUtils.toPersianDigits(students.size)} دانش‌آموز کلاس در این دور انتخاب شدند و لیگ با موفقیت به پایان رسید.",
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = {
                                    onStartNewLeague()
                                    lastDrawResult = null
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("شروع مجدد لیگ عدالت", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                } else if (remainingPresent.isEmpty() && students.isNotEmpty()) {
                    // تمام دانش‌آموزان حاضر امروز انتخاب شده‌اند و باقی‌ماندگان غایب هستند
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF7ED)),
                        border = BorderStroke(1.5.dp, Color(0xFFF97316))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.WarningAmber,
                                contentDescription = null,
                                tint = Color(0xFFEA580C),
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "تمام حاضرین امروز انتخاب شده‌اند",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color(0xFF9A3412)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            val absentNames = remainingAbsent.joinToString("، ") { it.name }
                            Text(
                                text = "دانش‌آموزان باقی‌مانده همگی غایب هستند:\n($absentNames)\n\nمی‌توانید تا حضور آن‌ها در روزهای آینده صبر کنید یا لیگ را مجدداً آغاز نمایید.",
                                fontSize = 12.sp,
                                lineHeight = 18.sp,
                                textAlign = TextAlign.Center,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = {
                                    onStartNewLeague()
                                    lastDrawResult = null
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEA580C)),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("شروع مجدد لیگ عدالت", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                } else {
                    // گردونه چرخان فیزیکی و ویترین پویای اسامی
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // گردونه رولت فیزیکی
                        RouletteWheel(
                            rotationDegrees = wheelRotation.value,
                            modifier = Modifier.padding(bottom = 10.dp)
                        )

                        // ویترین نمایش انیمیشنی نام‌ها
                        if (isSpinning) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB)),
                                border = BorderStroke(2.dp, Color(0xFFF59E0B)),
                                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Casino,
                                            contentDescription = null,
                                            tint = Color(0xFFD97706),
                                            modifier = Modifier
                                                .size(18.dp)
                                                .rotate(wheelRotation.value * 2)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "گردونه در حال چرخش...",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF92400E)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = Color(0xFFFEF3C7),
                                        border = BorderStroke(1.dp, Color(0xFFFDE68A)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = currentSpinningName.ifBlank { "..." },
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 24.sp,
                                            textAlign = TextAlign.Center,
                                            color = Color(0xFF78350F),
                                            modifier = Modifier.padding(vertical = 12.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "انتخاب عادلانه از بین حاضرین...",
                                        fontSize = 11.sp,
                                        color = TextSecondary
                                    )
                                }
                            }
                        } else if (displayStudent != null) {
                            // کارت برنده قرعه‌کشی با افکت شادباش و کانفتی
                            Box(
                                modifier = Modifier.fillMaxWidth(),
                                contentAlignment = Alignment.Center
                            ) {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                                    border = BorderStroke(2.dp, Color(0xFFF59E0B)),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(14.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = Color(0xFFD97706)
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.EmojiEvents,
                                                    contentDescription = null,
                                                    tint = Color.White,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(
                                                    text = "🎉 برنده قرعه‌کشی گردونه شانس 🎉",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = "⭐ ${displayStudent.name} ⭐",
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 24.sp,
                                            color = Color(0xFF78350F),
                                            textAlign = TextAlign.Center
                                        )
                                        val groupName = getStudentGroupName(displayStudent.name)
                                        if (groupName != null) {
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "عضو «$groupName»",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = Color(0xFFB45309)
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = null,
                                                tint = PrimaryGreenDark,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "حاضر در کلاس • ثبت شده در لیگ عدالت",
                                                fontSize = 11.sp,
                                                color = PrimaryGreenDark,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                    }
                                }

                                // ذرات شادباش و کانفتی شناور روی کارت
                                if (confettiAnim.value > 0f && confettiAnim.value < 1f) {
                                    Canvas(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(150.dp)
                                    ) {
                                        val progress = confettiAnim.value
                                        val centerX = size.width / 2f
                                        val centerY = size.height / 2f
                                        val alpha = (1f - progress).coerceIn(0f, 1f)

                                        particles.forEach { p ->
                                            val rad = Math.toRadians(p.angle.toDouble())
                                            val distance = p.speed * progress * 240f
                                            val gravity = progress * progress * 120f
                                            val px = centerX + (distance * cos(rad)).toFloat()
                                            val py = centerY + (distance * sin(rad)).toFloat() + gravity

                                            if (p.isCircle) {
                                                drawCircle(
                                                    color = p.color.copy(alpha = alpha),
                                                    radius = p.size,
                                                    center = Offset(px, py)
                                                )
                                            } else {
                                                drawRect(
                                                    color = p.color.copy(alpha = alpha),
                                                    topLeft = Offset(px - p.size, py - p.size),
                                                    size = Size(p.size * 2f, p.size * 1.5f)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color(0xFFF9FAFB),
                                border = BorderStroke(1.dp, Color(0xFFE5E7EB)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "برای شروع انتخاب پرهیجان دانش‌آموز، دکمه چرخش گردونه را لمس کنید.",
                                    fontSize = 12.sp,
                                    textAlign = TextAlign.Center,
                                    color = TextSecondary,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // دکمه چرخش گردونه شانس
                        Button(
                            onClick = { startSpin() },
                            enabled = !isSpinning,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("draw_next_student_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFD97706),
                                contentColor = Color.White,
                                disabledContainerColor = Color(0xFFFDE68A),
                                disabledContentColor = Color(0xFF92400E)
                            ),
                            elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
                        ) {
                            if (isSpinning) {
                                Icon(
                                    imageVector = Icons.Default.Casino,
                                    contentDescription = null,
                                    modifier = Modifier
                                        .size(22.dp)
                                        .rotate(wheelRotation.value * 3)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "گردونه در حال چرخش... 🎡",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Casino,
                                    contentDescription = null,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (displayStudent != null)
                                        "چرخش مجدد گردونه (${DateUtils.toPersianDigits(remainingPresent.size)} حاضر باقی‌مانده)"
                                    else
                                        "چرخش گردونه شانس (${DateUtils.toPersianDigits(remainingPresent.size)} حاضر)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // زبانه‌های نمایش فهرست
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = activeTab == 0,
                        onClick = { activeTab = 0 },
                        label = { Text("در انتظار (${DateUtils.toPersianDigits(remainingStudents.size)})", fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFFEF3C7),
                            selectedLabelColor = Color(0xFF78350F)
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = activeTab == 1,
                        onClick = { activeTab = 1 },
                        label = { Text("انتخاب شده (${DateUtils.toPersianDigits(pickedStudents.size)})", fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFDCFCE7),
                            selectedLabelColor = PrimaryGreenDark
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                if (activeTab == 0) {
                    // فهرست دانش‌آموزان باقی‌مانده در صف قرعه‌کشی
                    if (remainingStudents.isEmpty()) {
                        Text(
                            text = "همه دانش‌آموزان انتخاب شده‌اند!",
                            fontSize = 12.sp,
                            color = PrimaryGreenDark,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(12.dp)
                        )
                    } else {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 180.dp)
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            remainingStudents.forEach { student ->
                                val isPresent = student.status != "غایب" && student.status != "غیرموجه"
                                val groupName = getStudentGroupName(student.name)
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isPresent) Color.White else Color(0xFFFEE2E2),
                                    border = BorderStroke(0.5.dp, BorderLight),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 10.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = if (isPresent) Icons.Default.HourglassEmpty else Icons.Default.Cancel,
                                                contentDescription = null,
                                                tint = if (isPresent) Color(0xFFD97706) else Color(0xFFDC2626),
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(student.name, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                            if (groupName != null) {
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("($groupName)", fontSize = 11.sp, color = TextSecondary)
                                            }
                                        }
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = if (isPresent) Color(0xFFDCFCE7) else Color(0xFFFEE2E2)
                                        ) {
                                            Text(
                                                text = if (isPresent) "حاضر" else "غایب",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isPresent) PrimaryGreenDark else Color(0xFFDC2626),
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // فهرست دانش‌آموزان انتخاب شده در این دور
                    if (pickedStudents.isEmpty()) {
                        Text(
                            text = "هنوز هیچ دانش‌آموزی در این دور انتخاب نشده است.",
                            fontSize = 12.sp,
                            color = TextSecondary,
                            modifier = Modifier.padding(12.dp)
                        )
                    } else {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 180.dp)
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            pickedStudents.forEachIndexed { idx, student ->
                                val groupName = getStudentGroupName(student.name)
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFFF0FDF4),
                                    border = BorderStroke(0.5.dp, Color(0xFFBBF7D0)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 10.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = null,
                                                tint = PrimaryGreenDark,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("${DateUtils.toPersianDigits(idx + 1)}. ${student.name}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PrimaryGreenDark)
                                            if (groupName != null) {
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("($groupName)", fontSize = 11.sp, color = TextSecondary)
                                            }
                                        }
                                        Text("انتخاب شده ✓", fontSize = 10.sp, color = PrimaryGreenDark, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706))
            ) {
                Text("بستن")
            }
        },
        dismissButton = {
            TextButton(
                onClick = { showResetConfirm = true }
            ) {
                Text("ریست لیگ", color = Color(0xFFDC2626), fontSize = 12.sp)
            }
        }
    )

    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { showResetConfirm = false },
            title = { Text("ریست لیگ عدالت") },
            text = { Text("آیا از شروع مجدد لیگ عدالت مطمئن هستید؟ همه اسامی مجدداً در صف قرعه‌کشی قرار خواهند گرفت.") },
            confirmButton = {
                Button(
                    onClick = {
                        onResetLeague()
                        lastDrawResult = null
                        showResetConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("بله، ریست شود", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirm = false }) {
                    Text("انصراف")
                }
            }
        )
    }
}
