package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.DailyAttendance
import com.example.model.Student
import com.example.model.StudentAttendanceRecord
import com.example.ui.components.PersianDateField
import com.example.ui.components.PersianDatePickerDialog
import com.example.ui.theme.*
import com.example.util.DemoConfig

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AttendanceScreen(
    students: List<Student>,
    currentDate: String = "۱۴۰۳/۰۷/۱۵",
    attendanceHistory: List<DailyAttendance> = emptyList(),
    onBack: () -> Unit,
    onStatusChange: (Long, String) -> Unit,
    onMarkAllPresent: () -> Unit,
    onAddStudent: (String, String, String) -> Unit = { _, _, _ -> },
    onSaveStudent: (Student) -> Boolean = { true },
    onUpdateStudent: (Student) -> Boolean = { true },
    onDeleteStudent: (Long) -> Unit,
    onUpdateHistoricalAttendance: (String, Long, String) -> Unit = { _, _, _ -> },
    onMarkAllPresentForDate: (String) -> Unit = {},
    onAddHistoricalDate: (String) -> Unit = {},
    onDeleteHistoricalDate: (String) -> Unit = {},
    onSubmitAttendance: (String, List<StudentAttendanceRecord>) -> Boolean = { _, _ -> true },
    onSaveHistoricalAttendance: (String, List<StudentAttendanceRecord>) -> Unit = { _, _ -> },
    onNavigateToPro: (() -> Unit)? = null
) {
    val context = LocalContext.current

    // تب‌ها: ۰ = حضور و غیاب امروز، ۱ = دفتر حضور و غیاب
    var activeTab by remember { mutableIntStateOf(0) }

    // وضعیت‌های مدیریت اطلاعات دانش‌آموز (افزودن / ویرایش / مشاهده)
    var showStudentFormDialog by remember { mutableStateOf(false) }
    var editingStudent by remember { mutableStateOf<Student?>(null) }
    var viewingStudent by remember { mutableStateOf<Student?>(null) }

    // وضعیت‌های دیالوگ تأیید حذف و تأیید ویرایش با نام دانش‌آموز
    var studentToDelete by remember { mutableStateOf<Student?>(null) }
    var studentToConfirmEdit by remember { mutableStateOf<Student?>(null) }

    // [دستور دمو] وضعیت نمایش دیالوگ خطای محدودیت تعداد دانش‌آموزان در نسخه دمو
    var showDemoLimitDialog by remember { mutableStateOf(false) }

    // ۳ حالت اختصاصی حضور و غیاب طبق دستور معلم: ۱- حاضر ۲- غایب ۳- غیرموجه
    val statusOptions = listOf("حاضر", "غایب", "غیرموجه")

    // بررسی ثبت شدن یا نشدن حضور و غیاب امروز در دفتر
    val isTodaySubmitted = remember(attendanceHistory, currentDate) {
        attendanceHistory.any { it.date == currentDate }
    }

    // --- حالت‌های تب دفتر حضور و غیاب ---
    val availableDates = remember(attendanceHistory, currentDate) {
        val dates = attendanceHistory.map { it.date }.toMutableSet()
        if (currentDate.isNotBlank()) dates.add(currentDate)
        dates.toList().sortedDescending()
    }

    // تاریخ پیش‌فرض دفتر حضور و غیاب همیشه جدیدترین تاریخ و آخرین لیست ثبت‌شده باشد
    var selectedPastDate by remember(attendanceHistory) {
        mutableStateOf(
            attendanceHistory.firstOrNull()?.date ?: currentDate
        )
    }

    LaunchedEffect(activeTab) {
        if (activeTab == 1) {
            // هنگام ورود به سربرگ دفتر حضور غیاب، جدیدترین تاریخ ثبت‌شده همیشه پیش‌فرض باشد
            val latestDate = attendanceHistory.firstOrNull()?.date ?: currentDate
            selectedPastDate = latestDate
        }
    }

    // وضعیت قفل ویرایش برای روزهای قبل (اطمینان از تغییر)
    var isChangeConfirmed by remember { mutableStateOf(false) }
    var showConfirmChangeDialog by remember { mutableStateOf(false) }

    // دیالوگ تقویم انتخاب تاریخ
    var showAddDateDialog by remember { mutableStateOf(false) }

    // دیالوگ تأیید حذف رکورد تاریخ
    var showDeleteDateDialog by remember { mutableStateOf(false) }

    // آمار امروز
    val todayPresentCount = students.count { it.status == "حاضر" }
    val todayAbsentCount = students.count { it.status == "غایب" }
    val todayUnjustifiedCount = students.count { it.status == "غیرموجه" }

    // رکورد تاریخ انتخابی روزهای قبل
    val selectedDateRecord = remember(attendanceHistory, selectedPastDate) {
        attendanceHistory.find { it.date == selectedPastDate }
    }

    val studentStatusMapForSelectedDate = remember(students, selectedDateRecord, selectedPastDate, currentDate) {
        students.associate { student ->
            val statusInRecord = selectedDateRecord?.records?.find { it.studentId == student.id }?.status
            val finalStatus = if (statusInRecord != null) {
                statusInRecord
            } else if (selectedPastDate == currentDate) {
                student.status
            } else {
                "حاضر"
            }
            student.id to finalStatus
        }
    }

    val pastPresentCount = studentStatusMapForSelectedDate.values.count { it == "حاضر" }
    val pastAbsentCount = studentStatusMapForSelectedDate.values.count { it == "غایب" }
    val pastUnjustifiedCount = studentStatusMapForSelectedDate.values.count { it == "غیرموجه" }

    val pastAbsentStudents = remember(students, studentStatusMapForSelectedDate) {
        students.filter { student ->
            val st = studentStatusMapForSelectedDate[student.id]
            st == "غایب" || st == "غیرموجه"
        }
    }

    LaunchedEffect(selectedPastDate) {
        isChangeConfirmed = false
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text("دفتر حضور و غیاب کلاس", fontWeight = FontWeight.Bold, color = Color.White)
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "بازگشت",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    if (activeTab == 0) {
                        TextButton(
                            onClick = {
                                if (!isTodaySubmitted) {
                                    onMarkAllPresent()
                                    Toast.makeText(context, "همه دانش‌آموزان حاضر شدند. برای ثبت نهایی دکمه ذخیره را لمس کنید.", Toast.LENGTH_SHORT).show()
                                }
                            },
                            enabled = !isTodaySubmitted,
                            colors = ButtonDefaults.textButtonColors(
                                contentColor = Color.White,
                                disabledContentColor = Color.White.copy(alpha = 0.45f)
                            )
                        ) {
                            Icon(Icons.Default.DoneAll, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("حاضر کردن همه", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PrimaryGreen)
            )
        },
        floatingActionButton = {
            if (activeTab == 0) {
                ExtendedFloatingActionButton(
                    onClick = {
                        // [دستور دمو] بررسی سقف ۱۰ دانش‌آموز در صورت فعال بودن نسخه دمو
                        if (DemoConfig.isDemoActive(context) && students.size >= DemoConfig.MAX_STUDENTS_COUNT) {
                            showDemoLimitDialog = true
                        } else {
                            editingStudent = null
                            showStudentFormDialog = true
                        }
                    },
                    icon = { Icon(Icons.Default.PersonAdd, contentDescription = null) },
                    text = { Text("افزودن دانش‌آموز", fontWeight = FontWeight.Bold) },
                    containerColor = PrimaryGreen,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("add_student_fab")
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BackgroundLight)
        ) {
            // ۱. تب‌های بالایی
            TabRow(
                selectedTabIndex = activeTab,
                containerColor = Color.White,
                contentColor = PrimaryGreen,
                divider = { HorizontalDivider(color = BorderLight) }
            ) {
                Tab(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Today,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ثبت حضور و غیاب امروز",
                                fontWeight = if (activeTab == 0) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        }
                    }
                )
                Tab(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.MenuBook,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "دفتر حضور و غیاب",
                                fontWeight = if (activeTab == 1) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        }
                    }
                )
            }

            // ۲. محتوای هر تب
            if (activeTab == 0) {
                // ==================== تب ۱: ثبت حضور و غیاب امروز ====================
                Surface(
                    color = Color.White,
                    shadowElevation = 1.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StatPill(title = "کل دانش‌آموزان", count = "${students.size} نفر", color = TextPrimary)
                        StatPill(title = "حاضرین", count = "$todayPresentCount نفر", color = PrimaryGreenDark)
                        StatPill(title = "غایبین", count = "$todayAbsentCount نفر", color = Color(0xFFD32F2F))
                        if (todayUnjustifiedCount > 0) {
                            StatPill(title = "غیرموجه", count = "$todayUnjustifiedCount نفر", color = Color(0xFFEA580C))
                        }
                    }
                }

                if (students.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.School,
                                contentDescription = null,
                                tint = Color.Gray,
                                modifier = Modifier.size(64.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("دانش‌آموزی در کلاس ثبت نشده است.", color = TextSecondary)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("برای ثبت مشخصات کامل دانش‌آموز جدید روی دکمه زیر کلیک کنید.", fontSize = 12.sp, color = TextSecondary)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // در صورتی که حضور و غیاب امروز قبلاً ثبت شده باشد، پیام هشدار نمایش داده می‌شود
                        if (isTodaySubmitted) {
                            item {
                                Card(
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                                    border = BorderStroke(1.5.dp, Color(0xFF3B82F6)),
                                    modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = null,
                                                tint = Color(0xFF2563EB),
                                                modifier = Modifier.size(22.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "حضور و غیاب امروز ($currentDate) قبلاً ثبت شده است",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = Color(0xFF1E40AF)
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = "امکان ثبت دو نتیجه حضور غیاب برای یک روز وجود ندارد. برای مشاهده، بررسی یا ویرایش نتایج، از بخش «دفتر حضور و غیاب» استفاده فرمایید.",
                                            fontSize = 12.sp,
                                            color = TextSecondary,
                                            textAlign = TextAlign.Center,
                                            lineHeight = 18.sp
                                        )
                                        Spacer(modifier = Modifier.height(10.dp))
                                        Button(
                                            onClick = {
                                                selectedPastDate = currentDate
                                                activeTab = 1
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Icon(Icons.Default.MenuBook, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("انتقال به دفتر حضور و غیاب", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }

                        items(students, key = { it.id }) { student ->
                            StudentAttendanceCard(
                                student = student,
                                status = student.status,
                                isEditable = !isTodaySubmitted,
                                statusOptions = statusOptions,
                                onStatusSelected = {
                                    onStatusChange(student.id, it)
                                    Toast.makeText(context, "وضعیت ${student.name} به «$it» تغییر کرد (جهت انتقال به دفتر، دکمه ذخیره را بزنید).", Toast.LENGTH_SHORT).show()
                                },
                                onClickCard = { viewingStudent = student },
                                onEdit = {
                                    editingStudent = student
                                    showStudentFormDialog = true
                                },
                                onDelete = {
                                    studentToDelete = student
                                },
                                onLockedClick = {
                                    selectedPastDate = currentDate
                                    activeTab = 1
                                    showConfirmChangeDialog = true
                                }
                            )
                        }

                        if (!isTodaySubmitted) {
                            item {
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = {
                                        val records = students.map { StudentAttendanceRecord(it.id, it.status) }
                                        val success = onSubmitAttendance(currentDate, records)
                                        if (success) {
                                            Toast.makeText(context, "حضور و غیاب امروز با موفقیت ذخیره و به دفتر حضور و غیاب منتقل شد.", Toast.LENGTH_SHORT).show()
                                            selectedPastDate = currentDate
                                            activeTab = 1
                                        } else {
                                            Toast.makeText(context, "خطا در ثبت اطلاعات در دفتر حضور و غیاب!", Toast.LENGTH_LONG).show()
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("submit_attendance_btn"),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                                ) {
                                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("ذخیره و انتقال به دفتر حضور و غیاب", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }
                            }
                        } else {
                            item {
                                Surface(
                                    color = Color(0xFFF0FDF4),
                                    border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = PrimaryGreenDark,
                                            modifier = Modifier.size(24.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = "حضور و غیاب امروز در دفتر حضور و غیاب ذخیره شده است.",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = PrimaryGreenDark
                                            )
                                            Text(
                                                text = "دکمه «حاضر کردن همه» غیرفعال می‌باشد. جهت مشاهده یا ویرایش سوابق به سربرگ «دفتر حضور و غیاب» مراجعه فرمایید.",
                                                fontSize = 11.sp,
                                                color = TextSecondary,
                                                lineHeight = 16.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        item {
                            Spacer(modifier = Modifier.height(76.dp))
                        }
                    }
                }

            } else {
                // ==================== تب ۲: بررسی و ویرایش روزهای قبل ====================
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // ۱. بخش انتخاب تاریخ‌های گذشته
                    item {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.CalendarMonth,
                                            contentDescription = null,
                                            tint = PrimaryGreen,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "انتخاب تاریخ جهت بررسی آمار:",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = TextPrimary
                                        )
                                    }

                                    OutlinedButton(
                                        onClick = { showAddDateDialog = true },
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = PrimaryGreen)
                                    ) {
                                        Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("انتخاب از تقویم", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    availableDates.forEach { dateStr ->
                                        val isSelected = dateStr == selectedPastDate
                                        val rec = attendanceHistory.find { it.date == dateStr }
                                        val absCount = rec?.records?.count { it.status == "غایب" || it.status == "غیرموجه" }
                                            ?: if (dateStr == currentDate) todayAbsentCount else 0

                                        FilterChip(
                                            selected = isSelected,
                                            onClick = { selectedPastDate = dateStr },
                                            label = {
                                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                    Text(
                                                        text = if (dateStr == currentDate) "$dateStr (امروز)" else dateStr,
                                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                        fontSize = 12.sp
                                                    )
                                                    Text(
                                                        text = if (absCount > 0) "$absCount غایب" else "کامل حاضر",
                                                        fontSize = 10.sp,
                                                        color = if (isSelected) Color.White.copy(alpha = 0.9f)
                                                        else if (absCount > 0) Color(0xFFDC2626) else PrimaryGreenDark
                                                    )
                                                }
                                            },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = PrimaryGreen,
                                                selectedLabelColor = Color.White
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // ۲. کارت آمار تحلیلی روز انتخابی
                    item {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "آمار حضور و غیاب روز «$selectedPastDate»",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = TextPrimary
                                    )

                                    if (selectedPastDate != currentDate) {
                                        IconButton(
                                            onClick = { showDeleteDateDialog = true },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.DeleteOutline,
                                                contentDescription = "حذف رکورد تاریخ",
                                                tint = Color.Gray,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    ScoreStatChip(
                                        title = "کل دانش‌آموزان",
                                        count = students.size,
                                        color = TextPrimary,
                                        bgColor = Color(0xFFF3F4F6),
                                        modifier = Modifier.weight(1f)
                                    )
                                    ScoreStatChip(
                                        title = "حاضرین",
                                        count = pastPresentCount,
                                        color = Color(0xFF166534),
                                        bgColor = Color(0xFFDCFCE7),
                                        modifier = Modifier.weight(1f)
                                    )
                                    ScoreStatChip(
                                        title = "غایبین",
                                        count = pastAbsentCount,
                                        color = Color(0xFFB91C1C),
                                        bgColor = Color(0xFFFEE2E2),
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (pastUnjustifiedCount > 0) {
                                        ScoreStatChip(
                                            title = "غیرموجه",
                                            count = pastUnjustifiedCount,
                                            color = Color(0xFFC2410C),
                                            bgColor = Color(0xFFFFEDD5),
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // باکس نمایش غایبین روز
                                if (pastAbsentStudents.isNotEmpty()) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color(0xFFFEF2F2),
                                        border = BorderStroke(1.dp, Color(0xFFFECACA)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    imageVector = Icons.Default.PersonOff,
                                                    contentDescription = null,
                                                    tint = Color(0xFFDC2626),
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = "اسامی غایبین در این روز (${pastAbsentStudents.size} نفر):",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp,
                                                    color = Color(0xFF991B1B)
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                pastAbsentStudents.forEach { st ->
                                                    val stStatus = studentStatusMapForSelectedDate[st.id] ?: "غایب"
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = "• ${st.name}",
                                                            fontSize = 12.sp,
                                                            color = Color(0xFF7F1D1D)
                                                        )
                                                        Text(
                                                            text = "($stStatus)",
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = when (stStatus) {
                                                                "غیرموجه" -> Color(0xFFC2410C)
                                                                else -> Color(0xFFB91C1C)
                                                            }
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color(0xFFF0FDF4),
                                        border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = null,
                                                tint = PrimaryGreenDark,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "در این تاریخ کلیه دانش‌آموزان حاضر بوده‌اند.",
                                                fontSize = 12.sp,
                                                color = Color(0xFF166534),
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // ۳. نوار کنترل امنیتی «اطمینان از تغییر» برای ویرایش روزهای قبل
                    item {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isChangeConfirmed) Color(0xFFFFFBEB) else Color(0xFFF8FAFC)
                            ),
                            border = BorderStroke(
                                1.5.dp,
                                if (isChangeConfirmed) Color(0xFFF59E0B) else Color(0xFFCBD5E1)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = if (isChangeConfirmed) Icons.Default.LockOpen else Icons.Default.Lock,
                                            contentDescription = null,
                                            tint = if (isChangeConfirmed) Color(0xFFD97706) else Color(0xFF64748B),
                                            modifier = Modifier.size(24.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = if (isChangeConfirmed) "حالت ویرایش فعال است" else "قفل ویرایش فعال است (حالت امن)",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = if (isChangeConfirmed) Color(0xFF92400E) else TextPrimary
                                            )
                                            Text(
                                                text = if (isChangeConfirmed)
                                                    "می‌توانید وضعیت هر دانش‌آموز را تغییر دهید؛ آمار روز فوراً به‌روز خواهد شد."
                                                else
                                                    "جهت جلوگیری از تغییر ناخواسته آمار روزهای قبل، ویرایش قفل است.",
                                                fontSize = 11.sp,
                                                color = TextSecondary
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                HorizontalDivider(color = if (isChangeConfirmed) Color(0xFFFDE68A) else BorderLight, thickness = 0.5.dp)
                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            if (!isChangeConfirmed) {
                                                showConfirmChangeDialog = true
                                            } else {
                                                isChangeConfirmed = false
                                                Toast.makeText(context, "حالت ویرایش غیرفعال و قفل شد.", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Checkbox(
                                            checked = isChangeConfirmed,
                                            onCheckedChange = { checked ->
                                                if (checked) {
                                                    showConfirmChangeDialog = true
                                                } else {
                                                    isChangeConfirmed = false
                                                    Toast.makeText(context, "حالت ویرایش قفل شد.", Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            colors = CheckboxDefaults.colors(
                                                checkedColor = Color(0xFFD97706)
                                            )
                                        )
                                        Text(
                                            text = "اطمینان از تغییر و ویرایش آمار این تاریخ دارم",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = if (isChangeConfirmed) Color(0xFF92400E) else TextPrimary
                                        )
                                    }

                                    if (isChangeConfirmed) {
                                        TextButton(
                                            onClick = {
                                                onMarkAllPresentForDate(selectedPastDate)
                                                Toast.makeText(context, "همه دانش‌آموزان در تاریخ «$selectedPastDate» حاضر شدند.", Toast.LENGTH_SHORT).show()
                                            },
                                            colors = ButtonDefaults.textButtonColors(contentColor = PrimaryGreenDark)
                                        ) {
                                            Icon(Icons.Default.DoneAll, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("حاضر کردن همه", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // ۴. فهرست دانش‌آموزان در این تاریخ
                    item {
                        Text(
                            text = "لیست دانش‌آموزان و وضعیت حضور در «$selectedPastDate»:",
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }

                    items(students, key = { it.id }) { student ->
                        val currentRecordedStatus = studentStatusMapForSelectedDate[student.id] ?: "حاضر"

                        StudentAttendanceCard(
                            student = student,
                            status = currentRecordedStatus,
                            isEditable = isChangeConfirmed,
                            statusOptions = statusOptions,
                            onStatusSelected = { newStatus ->
                                onUpdateHistoricalAttendance(selectedPastDate, student.id, newStatus)
                                Toast.makeText(
                                    context,
                                    "وضعیت ${student.name} در تاریخ «$selectedPastDate» به «$newStatus» تغییر یافت و آمار ذخیره شد.",
                                    Toast.LENGTH_SHORT
                                ).show()
                            },
                            onClickCard = { viewingStudent = student },
                            onEdit = {
                                editingStudent = student
                                showStudentFormDialog = true
                            },
                            onDelete = {},
                            onLockedClick = {
                                showConfirmChangeDialog = true
                            }
                        )
                    }

                    item {
                        Spacer(modifier = Modifier.height(30.dp))
                    }
                }
            }
        }
    }

    // ==================== دیالوگ‌های تأیید و فرم‌ها ====================

    // ۱. دیالوگ تأیید حذف دانش‌آموز با نام
    studentToDelete?.let { student ->
        AlertDialog(
            onDismissRequest = { studentToDelete = null },
            icon = {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = Color(0xFFDC2626),
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "تأیید حذف دانش‌آموز",
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "آیا از حذف دانش‌آموز با نام «${student.name}» مطمئن هستید؟ با حذف دانش‌آموز، کلیه سوابق ارزشیابی و حضور و غیاب وی پاک خواهد شد.",
                    fontSize = 14.sp,
                    lineHeight = 22.sp,
                    color = TextPrimary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteStudent(student.id)
                        Toast.makeText(context, "دانش‌آموز «${student.name}» با موفقیت حذف شد.", Toast.LENGTH_SHORT).show()
                        studentToDelete = null
                        if (viewingStudent?.id == student.id) viewingStudent = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("بله، حذف شود", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { studentToDelete = null }) {
                    Text("انصراف")
                }
            }
        )
    }

    // ۲. دیالوگ تأیید ویرایش دانش‌آموز با نام
    studentToConfirmEdit?.let { student ->
        AlertDialog(
            onDismissRequest = { studentToConfirmEdit = null },
            icon = {
                Icon(
                    imageVector = Icons.Default.CheckCircleOutline,
                    contentDescription = null,
                    tint = PrimaryGreen,
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "تأیید ویرایش اطلاعات",
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "آیا از ذخیره ویرایش اطلاعات دانش‌آموز با نام «${student.name}» مطمئن هستید؟",
                    fontSize = 14.sp,
                    lineHeight = 22.sp,
                    color = TextPrimary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val success = onUpdateStudent(student)
                        if (success) {
                            Toast.makeText(context, "اطلاعات دانش‌آموز «${student.name}» با موفقیت ویرایش شد.", Toast.LENGTH_SHORT).show()
                            showStudentFormDialog = false
                            editingStudent = null
                            studentToConfirmEdit = null
                            if (viewingStudent?.id == student.id) viewingStudent = student
                        } else {
                            Toast.makeText(context, "خطا: نام یا شماره شاد تکراری است و نمی‌تواند با دانش‌آموز دیگری یکسان باشد!", Toast.LENGTH_LONG).show()
                            studentToConfirmEdit = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                ) {
                    Text("بله، ذخیره شود", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { studentToConfirmEdit = null }) {
                    Text("انصراف")
                }
            }
        )
    }

    // ۳. فرم جامع افزودن / ویرایش دانش‌آموز با تمام فیلدها و عکس
    if (showStudentFormDialog) {
        StudentFormDialog(
            initialStudent = editingStudent,
            existingStudents = students,
            onDismiss = {
                showStudentFormDialog = false
                editingStudent = null
            },
            onRequestSave = { newStudentData ->
                if (editingStudent != null) {
                    // قبل از ویرایش، دیالوگ تأیید نام را نشان بده
                    studentToConfirmEdit = newStudentData
                } else if (DemoConfig.isDemoActive(context) && students.size >= DemoConfig.MAX_STUDENTS_COUNT) {
                    // [دستور دمو] جلوگیری از ثبت بیش از ۱۰ دانش‌آموز در صورت فعال بودن نسخه دمو
                    showStudentFormDialog = false
                    showDemoLimitDialog = true
                } else {
                    // افزودن دانش‌آموز جدید
                    val success = onSaveStudent(newStudentData)
                    if (success) {
                        Toast.makeText(context, "دانش‌آموز «${newStudentData.name}» با موفقیت ثبت شد.", Toast.LENGTH_SHORT).show()
                        showStudentFormDialog = false
                        editingStudent = null
                    } else {
                        Toast.makeText(context, "خطا: دانش‌آموزی با این نام یا شماره شاد قبلاً ثبت شده است و امکان ثبت تکراری وجود ندارد!", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }

    // ۴. دیالوگ شناسنامه و پرونده کامل دانش‌آموز
    viewingStudent?.let { student ->
        StudentProfileDetailDialog(
            student = student,
            onDismiss = { viewingStudent = null },
            onEdit = {
                viewingStudent = null
                editingStudent = student
                showStudentFormDialog = true
            },
            onDelete = {
                studentToDelete = student
            }
        )
    }

    // ۵. دیالوگ هشدار تأیید تغییرات در وضعیت حضور غیاب گذشته
    if (showConfirmChangeDialog) {
        AlertDialog(
            onDismissRequest = { showConfirmChangeDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.WarningAmber,
                    contentDescription = null,
                    tint = Color(0xFFD97706),
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "هشدار ویرایش حضور و غیاب",
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "آیا از ثبت تغییرات در وضعیت حضور غیاب روز $selectedPastDate مطمئن هستید؟",
                    fontSize = 14.sp,
                    lineHeight = 22.sp,
                    color = TextPrimary,
                    textAlign = TextAlign.Center
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        isChangeConfirmed = true
                        showConfirmChangeDialog = false
                        Toast.makeText(context, "حالت ویرایش فعال شد. تغییرات مورد نظر خود را اعمال کنید.", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706))
                ) {
                    Text("بله، مطمئن هستم", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmChangeDialog = false }) {
                    Text("انصراف")
                }
            }
        )
    }

    // ۶. انتخاب تاریخ با تقویم شمسی در دفتر حضور و غیاب
    if (showAddDateDialog) {
        PersianDatePickerDialog(
            initialDate = selectedPastDate.ifBlank { currentDate },
            title = "انتخاب تاریخ در دفتر حضور و غیاب",
            onDismiss = { showAddDateDialog = false },
            onConfirm = { pickedDate ->
                onAddHistoricalDate(pickedDate)
                selectedPastDate = pickedDate
                showAddDateDialog = false
                Toast.makeText(context, "تاریخ «$pickedDate» انتخاب شد.", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // ۷. دیالوگ تأیید حذف رکورد تاریخ انتخابی
    if (showDeleteDateDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDateDialog = false },
            title = { Text("حذف رکورد تاریخ", fontWeight = FontWeight.Bold) },
            text = {
                Text("آیا از حذف کامل سوابق حضور و غیاب تاریخ «$selectedPastDate» اطمینان دارید؟")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteHistoricalDate(selectedPastDate)
                        Toast.makeText(context, "رکورد تاریخ «$selectedPastDate» حذف شد.", Toast.LENGTH_SHORT).show()
                        showDeleteDateDialog = false
                        selectedPastDate = availableDates.firstOrNull { it != selectedPastDate } ?: currentDate
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("حذف شود", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDateDialog = false }) {
                    Text("انصراف")
                }
            }
        )
    }

    // [دستور دمو] پیغام خطای محدودیت ثبت بیش از ۱۰ دانش‌آموز به همراه لینک کانال روبیکا
    if (showDemoLimitDialog) {
        val openRubika = {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(DemoConfig.RUBIKA_CHANNEL_URL))
                context.startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(context, "خطا در باز کردن مرورگر یا برنامه روبیکا", Toast.LENGTH_SHORT).show()
            }
        }

        AlertDialog(
            onDismissRequest = { showDemoLimitDialog = false },
            icon = {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFEE2E2)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "قفل نسخه دمو",
                        tint = Color(0xFFDC2626),
                        modifier = Modifier.size(28.dp)
                    )
                }
            },
            title = {
                Text(
                    text = "نسخه دمو (آزمایشی)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = DemoConfig.DEMO_LIMIT_ERROR_MESSAGE,
                        fontSize = 14.sp,
                        lineHeight = 22.sp,
                        textAlign = TextAlign.Center,
                        color = TextPrimary
                    )

                    Surface(
                        onClick = openRubika,
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFEFF6FF),
                        border = BorderStroke(1.2.dp, Color(0xFF3B82F6)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("demo_rubika_link")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.OpenInNew,
                                contentDescription = null,
                                tint = Color(0xFF2563EB),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = DemoConfig.RUBIKA_CHANNEL_DISPLAY,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF2563EB),
                                style = TextStyle(textDecoration = TextDecoration.Underline)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (onNavigateToPro != null) {
                        Button(
                            onClick = {
                                showDemoLimitDialog = false
                                onNavigateToPro()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("demo_go_to_pro_button")
                        ) {
                            Icon(Icons.Default.WorkspacePremium, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("فعال‌سازی نسخه پرو", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    } else {
                        Button(
                            onClick = openRubika,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("demo_open_channel_button")
                        ) {
                            Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ورود به روبیکا", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showDemoLimitDialog = false },
                    modifier = Modifier.testTag("demo_dialog_close_button")
                ) {
                    Text("انصراف", color = TextSecondary, fontWeight = FontWeight.Bold)
                }
            },
            modifier = Modifier.testTag("demo_limit_dialog")
        )
    }
}

/**
 * کارت دانش‌آموز با نمایش آواتار / عکس، نام، مشخصات و وضعیت حضور
 */
@Composable
fun StudentAttendanceCard(
    student: Student,
    status: String,
    isEditable: Boolean,
    statusOptions: List<String>,
    onStatusSelected: (String) -> Unit,
    onClickCard: () -> Unit = {},
    onEdit: () -> Unit = {},
    onDelete: () -> Unit = {},
    onLockedClick: () -> Unit = {}
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClickCard() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // نمایش عکس دانش‌آموز یا آیکون با اولین حرف نام
                if (student.photoUri.isNotBlank()) {
                    AsyncImage(
                        model = student.photoUri,
                        contentDescription = "عکس ${student.name}",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE5E7EB))
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(PrimaryGreen.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = student.name.take(1),
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = PrimaryGreen
                        )
                    }
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Text(
                        text = student.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = TextPrimary
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "شاد: ${student.shad.ifBlank { "—" }}",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                        if (student.fatherName.isNotBlank()) {
                            Text(
                                text = " • پدر: ${student.fatherName}",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }

            // بخش وضعیت حضور و دکمه‌های عملیات
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isEditable) {
                    Box {
                        Surface(
                            onClick = { expanded = true },
                            shape = RoundedCornerShape(8.dp),
                            color = when (status) {
                                "حاضر" -> Color(0xFFDCFCE7)
                                "غایب" -> Color(0xFFFEE2E2)
                                "غیرموجه" -> Color(0xFFFFEDD5)
                                else -> Color(0xFFE0F2FE)
                            },
                            border = BorderStroke(
                                1.dp,
                                when (status) {
                                    "حاضر" -> Color(0xFF86EFAC)
                                    "غایب" -> Color(0xFFFCA5A5)
                                    "غیرموجه" -> Color(0xFFFDBA74)
                                    else -> Color(0xFFBAE6FD)
                                }
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = status,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = when (status) {
                                        "حاضر" -> Color(0xFF166534)
                                        "غایب" -> Color(0xFFB91C1C)
                                        "غیرموجه" -> Color(0xFFC2410C)
                                        else -> Color(0xFF0369A1)
                                    }
                                )
                                Spacer(modifier = Modifier.width(2.dp))
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = null,
                                    tint = Color.DarkGray,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            statusOptions.forEach { st ->
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(st, fontWeight = if (st == status) FontWeight.Bold else FontWeight.Normal)
                                            if (st == status) {
                                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp), tint = PrimaryGreen)
                                            }
                                        }
                                    },
                                    onClick = {
                                        onStatusSelected(st)
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }
                } else {
                    Surface(
                        onClick = onLockedClick,
                        shape = RoundedCornerShape(8.dp),
                        color = when (status) {
                            "حاضر" -> Color(0xFFDCFCE7)
                            "غایب" -> Color(0xFFFEE2E2)
                            "غیرموجه" -> Color(0xFFFFEDD5)
                            else -> Color(0xFFE0F2FE)
                        }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "قفل ویرایش",
                                modifier = Modifier.size(12.dp),
                                tint = when (status) {
                                    "حاضر" -> Color(0xFF166534)
                                    "غایب" -> Color(0xFFB91C1C)
                                    "غیرموجه" -> Color(0xFFC2410C)
                                    else -> Color(0xFF0369A1)
                                }
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = status,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = when (status) {
                                    "حاضر" -> Color(0xFF166534)
                                    "غایب" -> Color(0xFFB91C1C)
                                    "غیرموجه" -> Color(0xFFC2410C)
                                    else -> Color(0xFF0369A1)
                                }
                            )
                        }
                    }
                }

                // دکمه ویرایش مشخصات دانش‌آموز
                IconButton(
                    onClick = onEdit,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "ویرایش مشخصات",
                        tint = Color(0xFF0284C7),
                        modifier = Modifier.size(18.dp)
                    )
                }

                // دکمه حذف
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "حذف دانش‌آموز",
                        tint = Color(0xFFEF4444),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

/**
 * فرم جامع ثبت و ویرایش دانش‌آموز با تمام فیلدهای درخواستی کاربر
 */
@Composable
fun StudentFormDialog(
    initialStudent: Student?,
    existingStudents: List<Student>,
    onDismiss: () -> Unit,
    onRequestSave: (Student) -> Unit
) {
    var name by remember { mutableStateOf(initialStudent?.name ?: "") }
    var shad by remember { mutableStateOf(initialStudent?.shad ?: "") }
    var birthDate by remember { mutableStateOf(initialStudent?.birthDate ?: "") }
    var birthPlace by remember { mutableStateOf(initialStudent?.birthPlace ?: "") }

    var fatherName by remember { mutableStateOf(initialStudent?.fatherName ?: "") }
    var fatherBirthDate by remember { mutableStateOf(initialStudent?.fatherBirthDate ?: "") }
    var fatherJob by remember { mutableStateOf(initialStudent?.fatherJob ?: "") }
    var fatherEducation by remember { mutableStateOf(initialStudent?.fatherEducation ?: "") }

    var motherName by remember { mutableStateOf(initialStudent?.motherName ?: "") }
    var motherBirthDate by remember { mutableStateOf(initialStudent?.motherBirthDate ?: "") }
    var motherJob by remember { mutableStateOf(initialStudent?.motherJob ?: "") }
    var motherEducation by remember { mutableStateOf(initialStudent?.motherEducation ?: "") }

    var photoUri by remember { mutableStateOf(initialStudent?.photoUri ?: "") }
    var notes by remember { mutableStateOf(initialStudent?.notes ?: "") }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    // راه‌اندازی انتخابگر عکس با Photo Picker ایمن بدون نیاز به مجوز
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            photoUri = uri.toString()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialStudent != null) "ویرایش اطلاعات دانش‌آموز" else "ثبت اطلاعات دانش‌آموز جدید",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // نمایش پیام خطای اعتبارسنجی
                errorMessage?.let { msg ->
                    Surface(
                        color = Color(0xFFFEE2E2),
                        border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(msg, color = Color(0xFFB91C1C), fontSize = 12.sp)
                        }
                    }
                }

                // بخش ۱: تصویر دانش‌آموز
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (photoUri.isNotBlank()) {
                            AsyncImage(
                                model = photoUri,
                                contentDescription = "عکس دانش‌آموز",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(60.dp)
                                    .clip(CircleShape)
                                    .background(Color.LightGray)
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(60.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFE2E8F0)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(32.dp))
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Button(
                                onClick = {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (photoUri.isNotBlank()) "تغییر عکس" else "انتخاب عکس", fontSize = 12.sp)
                            }

                            if (photoUri.isNotBlank()) {
                                TextButton(
                                    onClick = { photoUri = "" },
                                    colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFFDC2626)),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                                ) {
                                    Text("حذف عکس", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }

                // بخش ۲: مشخصات فردی دانش‌آموز
                Text("مشخصات فردی دانش‌آموز:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PrimaryGreenDark)

                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        errorMessage = null
                    },
                    label = { Text("نام و نام خانوادگی * (اجباری)") },
                    singleLine = true,
                    isError = name.isBlank() && errorMessage != null,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = shad,
                    onValueChange = {
                        shad = it
                        errorMessage = null
                    },
                    label = { Text("شماره شاد * (اجباری)") },
                    singleLine = true,
                    isError = shad.isBlank() && errorMessage != null,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    PersianDateField(
                        value = birthDate,
                        onDateSelected = { birthDate = it },
                        label = "تاریخ تولد",
                        placeholder = "انتخاب از تقویم...",
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = birthPlace,
                        onValueChange = { birthPlace = it },
                        label = { Text("محل تولد") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                // بخش ۳: مشخصات پدر
                Spacer(modifier = Modifier.height(4.dp))
                Text("مشخصات پدر:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF0369A1))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = fatherName,
                        onValueChange = { fatherName = it },
                        label = { Text("نام پدر") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    PersianDateField(
                        value = fatherBirthDate,
                        onDateSelected = { fatherBirthDate = it },
                        label = "تاریخ تولد پدر",
                        placeholder = "انتخاب از تقویم...",
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = fatherJob,
                        onValueChange = { fatherJob = it },
                        label = { Text("شغل پدر") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = fatherEducation,
                        onValueChange = { fatherEducation = it },
                        label = { Text("تحصیلات پدر") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                // بخش ۴: مشخصات مادر
                Spacer(modifier = Modifier.height(4.dp))
                Text("مشخصات مادر:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF9333EA))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = motherName,
                        onValueChange = { motherName = it },
                        label = { Text("نام مادر") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    PersianDateField(
                        value = motherBirthDate,
                        onDateSelected = { motherBirthDate = it },
                        label = "تاریخ تولد مادر",
                        placeholder = "انتخاب از تقویم...",
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = motherJob,
                        onValueChange = { motherJob = it },
                        label = { Text("شغل مادر") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = motherEducation,
                        onValueChange = { motherEducation = it },
                        label = { Text("تحصیلات مادر") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                // بخش ۵: سایر توضیحات
                Spacer(modifier = Modifier.height(4.dp))
                Text("سایر توضیحات:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF0284C7))
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("سایر توضیحات (نکات مهم و اختصاصی)") },
                    placeholder = { Text("توضیحات و نکات مهم در خصوص وضعیت تحصیلی، پزشکی، رفتاری یا خانوادگی دانش‌آموز...") },
                    minLines = 2,
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val trimmedName = name.trim()
                    val trimmedShad = shad.trim()

                    // ۱. اعتبارسنجی فیلدهای اجباری
                    if (trimmedName.isBlank()) {
                        errorMessage = "نام و نام خانوادگی اجباری است."
                        return@Button
                    }
                    if (trimmedShad.isBlank()) {
                        errorMessage = "شماره شاد اجباری است."
                        return@Button
                    }

                    // ۲. بررسی عدم ثبت تکراری دانش‌آموز (نام یا شماره شاد)
                    val isDuplicate = existingStudents.any { other ->
                        val isSameStudent = initialStudent != null && other.id == initialStudent.id
                        !isSameStudent && (
                            other.name.trim().equals(trimmedName, ignoreCase = true) ||
                            (other.shad.isNotBlank() && other.shad.trim() == trimmedShad)
                        )
                    }

                    if (isDuplicate) {
                        errorMessage = "دانش‌آموزی با این نام یا شماره شاد قبلاً در کلاس ثبت شده است و امکان ثبت تکراری وجود ندارد!"
                        return@Button
                    }

                    val updatedOrNew = Student(
                        id = initialStudent?.id ?: System.currentTimeMillis(),
                        name = trimmedName,
                        status = initialStudent?.status ?: "حاضر",
                        shad = trimmedShad,
                        birthDate = birthDate.trim(),
                        birthPlace = birthPlace.trim(),
                        fatherName = fatherName.trim(),
                        fatherBirthDate = fatherBirthDate.trim(),
                        fatherJob = fatherJob.trim(),
                        fatherEducation = fatherEducation.trim(),
                        motherName = motherName.trim(),
                        motherBirthDate = motherBirthDate.trim(),
                        motherJob = motherJob.trim(),
                        motherEducation = motherEducation.trim(),
                        photoUri = photoUri,
                        birthMonth = initialStudent?.birthMonth ?: "مهر",
                        notes = notes.trim(),
                        evaluations = initialStudent?.evaluations ?: emptyList()
                    )

                    onRequestSave(updatedOrNew)
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
            ) {
                Text(if (initialStudent != null) "ثبت تغییرات" else "ثبت دانش‌آموز", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("انصراف")
            }
        }
    )
}

/**
 * دیالوگ شناسنامه کامل دانش‌آموز با نمایش عکس، مشخصات شناسنامه‌ای و اطلاعات والدین
 */
@Composable
fun StudentProfileDetailDialog(
    student: Student,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("شناسنامه دانش‌آموز", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "بستن")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // کارت سربرگ مشخصات دانش‌آموز با عکس
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (student.photoUri.isNotBlank()) {
                            AsyncImage(
                                model = student.photoUri,
                                contentDescription = "عکس ${student.name}",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(Color.LightGray)
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(PrimaryGreen.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = student.name.take(1),
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryGreenDark
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(
                                text = student.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "شماره شاد: ${student.shad.ifBlank { "ثبت نشده" }}",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                            Text(
                                text = "وضعیت جاری: ${student.status}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (student.status) {
                                    "حاضر" -> PrimaryGreenDark
                                    "غایب" -> Color(0xFFDC2626)
                                    "غیرموجه" -> Color(0xFFEA580C)
                                    else -> Color(0xFF0284C7)
                                }
                            )
                        }
                    }
                }

                // مشخصات فردی
                InfoSectionCard(title = "اطلاعات شناسنامه‌ای دانش‌آموز", icon = Icons.Default.Badge, tint = PrimaryGreenDark) {
                    InfoRow(label = "تاریخ تولد:", value = student.birthDate.ifBlank { "ثبت نشده" })
                    InfoRow(label = "محل تولد:", value = student.birthPlace.ifBlank { "ثبت نشده" })
                }

                // مشخصات پدر
                InfoSectionCard(title = "مشخصات پدر", icon = Icons.Default.Person, tint = Color(0xFF0369A1)) {
                    InfoRow(label = "نام پدر:", value = student.fatherName.ifBlank { "ثبت نشده" })
                    InfoRow(label = "تاریخ تولد پدر:", value = student.fatherBirthDate.ifBlank { "ثبت نشده" })
                    InfoRow(label = "شغل پدر:", value = student.fatherJob.ifBlank { "ثبت نشده" })
                    InfoRow(label = "تحصیلات پدر:", value = student.fatherEducation.ifBlank { "ثبت نشده" })
                }

                // مشخصات مادر
                InfoSectionCard(title = "مشخصات مادر", icon = Icons.Default.PersonOutline, tint = Color(0xFF9333EA)) {
                    InfoRow(label = "نام مادر:", value = student.motherName.ifBlank { "ثبت نشده" })
                    InfoRow(label = "تاریخ تولد مادر:", value = student.motherBirthDate.ifBlank { "ثبت نشده" })
                    InfoRow(label = "شغل مادر:", value = student.motherJob.ifBlank { "ثبت نشده" })
                    InfoRow(label = "تحصیلات مادر:", value = student.motherEducation.ifBlank { "ثبت نشده" })
                }

                // سایر توضیحات و نکات مهم
                if (student.notes.isNotBlank()) {
                    InfoSectionCard(title = "سایر توضیحات و نکات مهم", icon = Icons.Default.Description, tint = Color(0xFF0284C7)) {
                        Text(
                            text = student.notes,
                            fontSize = 13.sp,
                            lineHeight = 20.sp,
                            color = TextPrimary,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onEdit,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
            ) {
                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("ویرایش مشخصات")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDelete,
                colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFFDC2626))
            ) {
                Icon(Icons.Default.DeleteOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("حذف دانش‌آموز")
            }
        }
    )
}

@Composable
fun InfoSectionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
        border = BorderStroke(0.5.dp, BorderLight),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = tint)
            }
            Spacer(modifier = Modifier.height(6.dp))
            content()
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 12.sp, color = TextSecondary)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
    }
}

@Composable
fun StatPill(
    title: String,
    count: String,
    color: Color
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = title,
            fontSize = 11.sp,
            color = TextSecondary
        )
        Text(
            text = count,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}
