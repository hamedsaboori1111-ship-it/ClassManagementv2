package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
    darkColorScheme(
        primary = PrimaryGreen,
        onPrimary = Color.White,
        primaryContainer = PrimaryGreenDark,
        onPrimaryContainer = PrimaryGreenLight,
        secondary = AmberSecondary,
        background = Color(0xFF121413),
        surface = Color(0xFF1A1C1B),
        onBackground = Color(0xFFE2E3E0),
        onSurface = Color(0xFFE2E3E0),
    )

private val LightColorScheme =
    lightColorScheme(
        primary = PrimaryGreen,
        onPrimary = Color.White,
        primaryContainer = PrimaryGreenLight,
        onPrimaryContainer = PrimaryGreenDark,
        secondary = AmberSecondary,
        onSecondary = Color(0xFF2C1E00),
        secondaryContainer = AmberSecondaryLight,
        onSecondaryContainer = Color(0xFF5E4200),
        tertiary = SkyBlue,
        background = BackgroundLight,
        surface = SurfaceLight,
        onBackground = TextPrimary,
        onSurface = TextPrimary,
        outline = BorderLight,
        error = AbsentRed,
        onError = Color.White,
        errorContainer = AbsentRedLight,
        onErrorContainer = AbsentRed,
    )

private val GreenColorScheme =
    lightColorScheme(
        primary = ThemeGreenPrimary,
        onPrimary = Color.White,
        primaryContainer = ThemeGreenPrimaryLight,
        onPrimaryContainer = ThemeGreenPrimaryDark,
        secondary = Color(0xFFEAB308),
        onSecondary = Color(0xFF2C1E00),
        secondaryContainer = Color(0xFFFEF9C3),
        onSecondaryContainer = Color(0xFF713F12),
        tertiary = Color(0xFF0D9488),
        background = ThemeGreenBackground,
        surface = ThemeGreenSurface,
        onBackground = ThemeGreenTextPrimary,
        onSurface = ThemeGreenTextPrimary,
        outline = ThemeGreenCardBorder,
        error = AbsentRed,
        onError = Color.White,
        errorContainer = AbsentRedLight,
        onErrorContainer = AbsentRed,
    )

private val RedColorScheme =
    lightColorScheme(
        primary = ThemeRedPrimary,
        onPrimary = Color.White,
        primaryContainer = ThemeRedPrimaryLight,
        onPrimaryContainer = ThemeRedPrimaryDark,
        secondary = Color(0xFFEA580C),
        onSecondary = Color(0xFFFFFFFF),
        secondaryContainer = Color(0xFFFFEDD5),
        onSecondaryContainer = Color(0xFF9A3412),
        tertiary = Color(0xFFB45309),
        background = ThemeRedBackground,
        surface = ThemeRedSurface,
        onBackground = ThemeRedTextPrimary,
        onSurface = ThemeRedTextPrimary,
        outline = ThemeRedCardBorder,
        error = AbsentRed,
        onError = Color.White,
        errorContainer = AbsentRedLight,
        onErrorContainer = AbsentRed,
    )

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    themeMode: String = "DEFAULT",
    content: @Composable () -> Unit,
) {
    val colorScheme =
        when {
            themeMode.equals("RED", ignoreCase = true) -> RedColorScheme
            themeMode.equals("GREEN", ignoreCase = true) -> GreenColorScheme
            dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
                val context = LocalContext.current
                if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
            }
            darkTheme -> DarkColorScheme
            else -> LightColorScheme
        }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
