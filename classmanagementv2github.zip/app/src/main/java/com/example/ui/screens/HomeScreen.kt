package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.AppState
import com.example.model.DaySchedule
import com.example.ui.components.PersianDatePickerDialog
import com.example.ui.theme.*
import java.util.Calendar
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    state: AppState,
    onNavigate: (Screen) -> Unit,
    onDateChange: (String) -> Unit,
    onDayTypeChange: (String) -> Unit,
    onExportBackup: () -> String,
    onImportBackup: (String) -> Boolean,
    onSyncWithDeviceDate: () -> String = { "" },
    onThemeChange: (String) -> Unit = {}
) {
    val context = LocalContext.current
    var showMenu by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf(false) }
    var showImportDialog by remember { mutableStateOf(false) }
    var showDateDialog by remember { mutableStateOf(false) }
    var showThemeDialog by remember { mutableStateOf(false) }
    var showWeeklyScheduleViewer by remember { mutableStateOf(false) }
    var exportJsonText by remember { mutableStateOf("") }
    var importInputText by remember { mutableStateOf("") }
    var tempDateText by remember { mutableStateOf(state.currentDateShamsi) }

    var isRefreshing by remember { mutableStateOf(false) }
    val refreshRotationAngle by animateFloatAsState(
        targetValue = if (isRefreshing) 360f else 0f,
        animationSpec = tween(durationMillis = 500),
        finishedListener = { isRefreshing = false },
        label = "refreshRotation"
    )

    val absentCount = state.students.count { it.status == "غایب" || it.status == "غیرموجه" }

    var showTodayAbsenteesDialog by remember { mutableStateOf(false) }
    var showBirthdaysDialog by remember { mutableStateOf(false) }

    val allPersianMonths = remember {
        listOf(
            "فروردین", "اردیبهشت", "خرداد",
            "تیر", "مرداد", "شهریور",
            "مهر", "آبان", "آذر",
            "دی", "بهمن", "اسفند"
        )
    }

    val currentMonthName = remember(state.currentDateShamsi) {
        var month = com.example.util.DateUtils.getCurrentJalaliDate().monthName
        if (state.currentDateShamsi.isNotBlank()) {
            val eng = com.example.util.DateUtils.toEnglishDigits(state.currentDateShamsi)
            val parts = eng.split("/")
            if (parts.size >= 2) {
                val m = parts[1].toIntOrNull()
                if (m != null && m in 1..12) {
                    month = allPersianMonths[m - 1]
                }
            }
        }
        month
    }

    fun isStudentBornInTargetMonth(student: com.example.model.Student, targetMonth: String): Boolean {
        if (student.birthMonth.trim().equals(targetMonth.trim(), ignoreCase = true)) {
            return true
        }
        if (student.birthDate.isNotBlank()) {
            val eng = com.example.util.DateUtils.toEnglishDigits(student.birthDate)
            val parts = eng.split("/")
            if (parts.size >= 2) {
                val m = parts[1].toIntOrNull()
                if (m != null && m in 1..12) {
                    if (allPersianMonths[m - 1] == targetMonth) {
                        return true
                    }
                }
            }
            if (student.birthDate.contains(targetMonth)) {
                return true
            }
        }
        return false
    }

    val birthdayStudentsThisMonth = remember(state.students, currentMonthName) {
        state.students.filter { isStudentBornInTargetMonth(it, currentMonthName) }
    }

    val realTodayName = remember {
        com.example.util.DateUtils.getCurrentDayOfWeek()
    }
    val defaultSchoolDay = remember {
        if (realTodayName in listOf("شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه")) realTodayName else "شنبه"
    }
    var selectedDayForSchedule by remember { mutableStateOf(defaultSchoolDay) }

    val performSyncDateAndSchedule: () -> Unit = {
        isRefreshing = true
        val freshJalali = com.example.util.DateUtils.getCurrentJalaliDate()
        val freshDate = freshJalali.toFormattedString()
        val freshDay = com.example.util.DateUtils.getCurrentDayOfWeek()

        val targetDay = if (freshDay in listOf("شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه")) {
            freshDay
        } else {
            if (state.weeklySchedule.any { it.dayName == freshDay }) freshDay else "شنبه"
        }

        val wasDifferent = (state.currentDateShamsi != freshDate)
        onSyncWithDeviceDate()
        if (wasDifferent) {
            onDateChange(freshDate)
        }
        selectedDayForSchedule = targetDay

        val msg = if (wasDifferent) {
            "تاریخ به ${com.example.util.DateUtils.toPersianDigits(freshDate)} بروزرسانی شد و برنامه $targetDay نمایش داده شد."
        } else {
            "تاریخ و برنامه روزانه با زمان گوشی همگام است ($targetDay ${com.example.util.DateUtils.toPersianDigits(freshDate)})"
        }
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
    }

    fun getPeriodOrdinal(index: Int): String {
        return when (index) {
            0 -> "زنگ اول"
            1 -> "زنگ دوم"
            2 -> "زنگ سوم"
            3 -> "زنگ چهارم"
            4 -> "زنگ پنجم"
            5 -> "زنگ ششم"
            6 -> "زنگ هفتم"
            7 -> "زنگ هشتم"
            else -> "زنگ ${index + 1}"
        }
    }

    val isGreenTheme = state.themeMode.equals("GREEN", ignoreCase = true)
    val isRedTheme = state.themeMode.equals("RED", ignoreCase = true)
    val appPrimaryColor = when {
        isRedTheme -> ThemeRedPrimary
        isGreenTheme -> ThemeGreenPrimary
        else -> PrimaryGreen
    }
    val appPrimaryDarkColor = when {
        isRedTheme -> ThemeRedPrimaryDark
        isGreenTheme -> ThemeGreenPrimaryDark
        else -> PrimaryGreenDark
    }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier
                    .widthIn(max = 320.dp)
                    .fillMaxHeight(),
                drawerContainerColor = when {
                    isRedTheme -> Color(0xFFFFFDFC)
                    isGreenTheme -> Color(0xFFFAFDFA)
                    else -> Color.White
                }
            ) {
                // سربرگ اطلاعات پروفایل معلم و مشخصات کلاس در منوی همبرگری
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(appPrimaryColor)
                        .padding(20.dp)
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(Color.White),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.School,
                                    contentDescription = null,
                                    tint = appPrimaryColor,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = state.profile.teacherName.ifBlank { "معلم گرامی" },
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                if (state.profile.schoolName.isNotBlank()) {
                                    Text(
                                        text = state.profile.schoolName,
                                        color = Color.White.copy(alpha = 0.85f),
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color.White.copy(alpha = 0.18f)
                        ) {
                            Text(
                                text = state.profile.educationalTitle.ifBlank { "آموزگار محترم" },
                                color = Color.White,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "منوی اصلی و ابزارها",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = TextSecondary,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
                )

                // ۱. تنظیمات پروفایل
                NavigationDrawerItem(
                    icon = {
                        Icon(
                            imageVector = Icons.Default.ManageAccounts,
                            contentDescription = null,
                            tint = TeacherTeal
                        )
                    },
                    label = {
                        Column {
                            Text("تنظیمات پروفایل", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("نام معلم، مدرسه و سال تحصیلی", fontSize = 11.sp, color = TextSecondary)
                        }
                    },
                    selected = false,
                    onClick = {
                        coroutineScope.launch { drawerState.close() }
                        onNavigate(Screen.PROFILE_SETTINGS)
                    },
                    modifier = Modifier
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                        .testTag("drawer_item_profile")
                )

                // ۲. مدیریت دروس
                NavigationDrawerItem(
                    icon = {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = null,
                            tint = SkyBlue
                        )
                    },
                    label = {
                        Column {
                            Text("مدیریت دروس", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("فعال‌سازی و ویرایش عناوین دروس", fontSize = 11.sp, color = TextSecondary)
                        }
                    },
                    badge = {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = SkyBlue.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "${state.subjects.size} درس",
                                fontSize = 11.sp,
                                color = SkyBlue,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    },
                    selected = false,
                    onClick = {
                        coroutineScope.launch { drawerState.close() }
                        onNavigate(Screen.SUBJECTS)
                    },
                    modifier = Modifier
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                        .testTag("drawer_item_subjects")
                )

                // ۳. ویرایش برنامه هفتگی
                NavigationDrawerItem(
                    icon = {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = null,
                            tint = PrimaryGreen
                        )
                    },
                    label = {
                        Column {
                            Text("ویرایش برنامه هفتگی", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("تنظیم زنگ‌های درسی شنبه تا چهارشنبه", fontSize = 11.sp, color = TextSecondary)
                        }
                    },
                    badge = {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = PrimaryGreen.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "۵ روز",
                                fontSize = 11.sp,
                                color = PrimaryGreenDark,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    },
                    selected = false,
                    onClick = {
                        coroutineScope.launch { drawerState.close() }
                        onNavigate(Screen.SCHEDULE)
                    },
                    modifier = Modifier
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                        .testTag("drawer_item_schedule")
                )

                // ۴. ارزیابی عملکرد و تایم‌لاین دانش‌آموزان
                NavigationDrawerItem(
                    icon = {
                        Icon(
                            imageVector = Icons.Default.QueryStats,
                            contentDescription = null,
                            tint = SkyBlue
                        )
                    },
                    label = {
                        Column {
                            Text("ارزیابی عملکرد", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("تایم‌لاین، آمار غیبت‌ها و وضعیت دروس", fontSize = 11.sp, color = TextSecondary)
                        }
                    },
                    badge = {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = SkyBlue.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "${state.students.size} دانش‌آموز",
                                fontSize = 11.sp,
                                color = SkyBlue,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    },
                    selected = false,
                    onClick = {
                        coroutineScope.launch { drawerState.close() }
                        onNavigate(Screen.PERFORMANCE)
                    },
                    modifier = Modifier
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                        .testTag("drawer_item_performance")
                )

                // ۵. نمودارهای آماری کلاسی (حضور و غیاب و میانگین نمرات)
                NavigationDrawerItem(
                    icon = {
                        Icon(
                            imageVector = Icons.Default.BarChart,
                            contentDescription = null,
                            tint = PrimaryGreen
                        )
                    },
                    label = {
                        Column {
                            Text("نمودارهای آماری کلاس", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("نمودار حضور و غیاب و میانگین نمرات دروس", fontSize = 11.sp, color = TextSecondary)
                        }
                    },
                    badge = {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = PrimaryGreen.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "تحلیلی",
                                fontSize = 11.sp,
                                color = PrimaryGreenDark,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    },
                    selected = false,
                    onClick = {
                        coroutineScope.launch { drawerState.close() }
                        onNavigate(Screen.CHARTS)
                    },
                    modifier = Modifier
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                        .testTag("drawer_item_charts")
                )

                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = BorderLight, modifier = Modifier.padding(horizontal = 16.dp))
                Spacer(modifier = Modifier.height(8.dp))

                // ۴. پشتیبان‌گیری و بازگردانی
                NavigationDrawerItem(
                    icon = {
                        Icon(
                            imageVector = Icons.Default.SettingsBackupRestore,
                            contentDescription = null,
                            tint = Color(0xFF0284C7)
                        )
                    },
                    label = {
                        Column {
                            Text("پشتیبان‌گیری و بازگردانی", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("ذخیره در حافظه دستگاه و بازیابی اطلاعات کلاس", fontSize = 11.sp, color = TextSecondary)
                        }
                    },
                    selected = false,
                    onClick = {
                        coroutineScope.launch { drawerState.close() }
                        onNavigate(Screen.BACKUP_RESTORE)
                    },
                    modifier = Modifier
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                        .testTag("drawer_item_backup")
                )

                // ۵. تم و ظاهر برنامه (شخصی‌سازی)
                val currentThemeLabel = when {
                    isRedTheme -> "قرمز"
                    isGreenTheme -> "سبز"
                    else -> "اصلی"
                }
                NavigationDrawerItem(
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Palette,
                            contentDescription = null,
                            tint = appPrimaryColor
                        )
                    },
                    label = {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("تم و ظاهر برنامه", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = appPrimaryColor.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = currentThemeLabel,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = appPrimaryDarkColor,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                    },
                    selected = false,
                    onClick = {
                        coroutineScope.launch { drawerState.close() }
                        showThemeDialog = true
                    },
                    modifier = Modifier
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                        .testTag("drawer_item_theme")
                )

                // ۶. فعال‌سازی نسخه پرو
                val isProActive = com.example.util.ActivationManager.isProActive(context)
                NavigationDrawerItem(
                    icon = {
                        Icon(
                            imageVector = if (isProActive) Icons.Default.Verified else Icons.Default.WorkspacePremium,
                            contentDescription = null,
                            tint = if (isProActive) PrimaryGreen else SkyBlue
                        )
                    },
                    label = {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "فعال‌سازی نسخه پرو",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = if (isProActive) TextSecondary else TextPrimary
                                )
                                Text(
                                    text = if (isProActive) "نسخه پرو فعال است" else "ارتقای سالانه به نسخه کامل",
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )
                            }
                            if (isProActive) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = PrimaryGreen.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = "فعال",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = PrimaryGreenDark,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    },
                    selected = false,
                    onClick = {
                        if (!isProActive) {
                            coroutineScope.launch { drawerState.close() }
                            onNavigate(Screen.PRO_ACTIVATION)
                        } else {
                            android.widget.Toast.makeText(
                                context,
                                "نرم‌افزار شما قبلاً فعال شده و نسخه پرو می‌باشد.",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    modifier = Modifier
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                        .testTag("drawer_item_pro_activation")
                )

                Spacer(modifier = Modifier.weight(1f))
                HorizontalDivider(color = BorderLight, modifier = Modifier.padding(horizontal = 16.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 14.dp, bottom = 48.dp, start = 16.dp, end = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // [دستور دمو / پرو] نمایش نسخه در پایین منوی همبرگری
                    Text(
                        text = com.example.util.DemoConfig.getDrawerVersionText(context),
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = "دفتر مدیریت کلاسی",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color.White
                        )
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = {
                                coroutineScope.launch {
                                    if (drawerState.isClosed) drawerState.open() else drawerState.close()
                                }
                            },
                            modifier = Modifier.testTag("hamburger_menu_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Menu,
                                contentDescription = "منوی همبرگری",
                                tint = Color.White
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = appPrimaryColor,
                        actionIconContentColor = Color.White
                    ),
                    actions = {
                        // دکمه کوچک بروزرسانی و همگام‌سازی تاریخ و برنامه روزانه با گوشی
                        IconButton(
                            onClick = performSyncDateAndSchedule,
                            modifier = Modifier.testTag("top_bar_sync_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Sync,
                                contentDescription = "بروزرسانی تاریخ و برنامه روزانه",
                                tint = Color.White,
                                modifier = Modifier.graphicsLayer(rotationZ = refreshRotationAngle)
                            )
                        }
                        IconButton(
                            onClick = { onNavigate(Screen.BACKUP_RESTORE) },
                            modifier = Modifier.testTag("backup_menu_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.SettingsBackupRestore,
                                contentDescription = "پشتیبان‌گیری و بازگردانی",
                                tint = Color.White
                            )
                        }
                    }
                )
            }
        ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(
                    when {
                        isRedTheme -> ThemeRedBackground
                        isGreenTheme -> ThemeGreenBackground
                        else -> BackgroundLight
                    }
                )
        ) {
            // تصویر پس‌زمینه اختصاصی تم قرمز
            if (isRedTheme) {
                Image(
                    painter = painterResource(id = R.drawable.bg_school_red),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    alpha = 0.32f
                )
            } else if (isGreenTheme) {
                // تصویر پس‌زمینه اختصاصی تم سبز
                Image(
                    painter = painterResource(id = R.drawable.bg_school_green),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    alpha = 0.28f
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
            ) {
                // ۱. نوار وضعیت روز و تاریخ
                Surface(
                    color = appPrimaryColor.copy(alpha = 0.15f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        tempDateText = state.currentDateShamsi
                                        showDateDialog = true
                                    }
                                    .padding(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DateRange,
                                    contentDescription = "تغییر تاریخ",
                                    tint = appPrimaryDarkColor,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "تاریخ: ${com.example.util.DateUtils.toPersianDigits(state.currentDateShamsi)}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = appPrimaryDarkColor
                                )
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            // دکمه کوچک بروزرسانی سریع تاریخ
                            Surface(
                                onClick = performSyncDateAndSchedule,
                                shape = RoundedCornerShape(8.dp),
                                color = appPrimaryColor.copy(alpha = 0.20f),
                                modifier = Modifier.testTag("date_bar_sync_button")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Sync,
                                        contentDescription = "بروزرسانی با ساعت گوشی",
                                        tint = appPrimaryDarkColor,
                                        modifier = Modifier
                                            .size(15.dp)
                                            .graphicsLayer(rotationZ = refreshRotationAngle)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "بروزرسانی",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = appPrimaryDarkColor
                                    )
                                }
                            }
                        }

                    // انتخاب حالت روز
                    var dayTypeExpanded by remember { mutableStateOf(false) }
                    Box {
                        Surface(
                            onClick = { dayTypeExpanded = true },
                            color = Color.White,
                            shape = RoundedCornerShape(8.dp),
                            shadowElevation = 1.dp
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = state.dayType,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = PrimaryGreen
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = null,
                                    tint = PrimaryGreen
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = dayTypeExpanded,
                            onDismissRequest = { dayTypeExpanded = false }
                        ) {
                            listOf("روز عادی", "روز تعطیل", "آموزش مجازی").forEach { type ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = type,
                                            fontWeight = if (state.dayType == type) FontWeight.Bold else FontWeight.Normal,
                                            color = if (state.dayType == type) PrimaryGreen else Color.Unspecified
                                        )
                                    },
                                    onClick = {
                                        onDayTypeChange(type)
                                        dayTypeExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // ۲. خلاصه وضعیت روزانه (غایبین)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clickable { showTodayAbsenteesDialog = true }
                    .testTag("home_absentees_card"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.PersonOff,
                        contentDescription = null,
                        tint = Color(0xFFD32F2F),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "غایبین امروز: $absentCount نفر",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFD32F2F)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "(مشاهده لیست)",
                        fontSize = 12.sp,
                        color = Color(0xFFD32F2F).copy(alpha = 0.8f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // ۲.۲ متولدین این ماه
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clickable { showBirthdaysDialog = true }
                    .testTag("home_birthdays_card"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF7ED)),
                border = BorderStroke(1.dp, Color(0xFFFED7AA)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Cake,
                        contentDescription = "متولدین این ماه",
                        tint = Color(0xFFEA580C),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "متولدین این ماه ($currentMonthName): ${com.example.util.DateUtils.toPersianDigits(birthdayStudentsThisMonth.size)} نفر",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFEA580C)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "(مشاهده اسامی 🎂)",
                        fontSize = 12.sp,
                        color = Color(0xFFEA580C).copy(alpha = 0.85f),
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // ۲.۵ نوار برنامه هفتگی دروس همان روز
            val todaySchedule = state.weeklySchedule.find { it.dayName == selectedDayForSchedule }
            val todayPeriods = todaySchedule?.periods ?: emptyList()
            val schoolDays = listOf("شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه")

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .testTag("home_schedule_preview_card"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { showWeeklyScheduleViewer = true }
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CalendarMonth,
                                contentDescription = null,
                                tint = PrimaryGreen,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = selectedDayForSchedule,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = TextPrimary
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            // دکمه مشاهده برنامه کامل کل هفته (فقط مشاهده)
                            Surface(
                                onClick = { showWeeklyScheduleViewer = true },
                                shape = RoundedCornerShape(8.dp),
                                color = PrimaryGreen.copy(alpha = 0.08f),
                                border = BorderStroke(1.dp, PrimaryGreen.copy(alpha = 0.25f)),
                                modifier = Modifier.testTag("home_schedule_view_all_week_button")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CalendarMonth,
                                        contentDescription = "کل هفته",
                                        tint = PrimaryGreenDark,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "کل هفته",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = PrimaryGreenDark
                                    )
                                }
                            }

                            // دکمه همگام‌سازی برنامه با امروز
                            Surface(
                                onClick = performSyncDateAndSchedule,
                                shape = RoundedCornerShape(8.dp),
                                color = PrimaryGreen.copy(alpha = 0.12f),
                                modifier = Modifier.testTag("schedule_sync_today_button")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Sync,
                                        contentDescription = "همگام با امروز",
                                        tint = PrimaryGreenDark,
                                        modifier = Modifier
                                            .size(13.dp)
                                            .graphicsLayer(rotationZ = refreshRotationAngle)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "امروز",
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = PrimaryGreenDark
                                    )
                                }
                            }

                            // انتخاب روز دیگر برای مشاهده سریع برنامه سایر روزها
                            var dayMenuExpanded by remember { mutableStateOf(false) }
                            Box {
                                Surface(
                                    onClick = { dayMenuExpanded = true },
                                    shape = RoundedCornerShape(8.dp),
                                    color = PrimaryGreen.copy(alpha = 0.08f),
                                    border = BorderStroke(1.dp, PrimaryGreen.copy(alpha = 0.25f))
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "تغییر روز",
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = PrimaryGreenDark
                                        )
                                        Icon(
                                            imageVector = Icons.Default.ArrowDropDown,
                                            contentDescription = null,
                                            tint = PrimaryGreenDark,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                                DropdownMenu(
                                    expanded = dayMenuExpanded,
                                    onDismissRequest = { dayMenuExpanded = false }
                                ) {
                                    schoolDays.forEach { d ->
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    text = if (d == realTodayName) "$d (امروز)" else d,
                                                    fontWeight = if (d == selectedDayForSchedule) FontWeight.Bold else FontWeight.Normal,
                                                    color = if (d == selectedDayForSchedule) PrimaryGreen else TextPrimary
                                                )
                                            },
                                            onClick = {
                                                selectedDayForSchedule = d
                                                dayMenuExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // نمایش ۵ زنگ و درس هر زنگ در یک نگاه با اندازه و ابعاد کاملاً یکسان و یکنواخت
                    val periodsToDisplay = (0 until 5).map { index ->
                        todayPeriods.getOrNull(index)?.ifBlank { "—" } ?: "—"
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("home_schedule_five_periods_row"),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        periodsToDisplay.forEachIndexed { index, subjectName ->
                            val isAssigned = subjectName != "—" && subjectName.isNotBlank()
                            val periodColor = when (index) {
                                0 -> PrimaryGreen
                                1 -> SkyBlue
                                2 -> Color(0xFFD97706)
                                3 -> TeacherTeal
                                else -> MeetingPurple
                            }
                            val periodBg = when (index) {
                                0 -> PrimaryGreen.copy(alpha = 0.08f)
                                1 -> SkyBlue.copy(alpha = 0.08f)
                                2 -> AmberSecondary.copy(alpha = 0.12f)
                                3 -> TeacherTeal.copy(alpha = 0.08f)
                                else -> MeetingPurple.copy(alpha = 0.08f)
                            }

                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(102.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { showWeeklyScheduleViewer = true }
                                    .testTag("home_schedule_period_${index + 1}"),
                                shape = RoundedCornerShape(10.dp),
                                color = if (isAssigned) periodBg else Color(0xFFF8FAFC),
                                border = BorderStroke(
                                    1.dp,
                                    if (isAssigned) periodColor.copy(alpha = 0.35f) else BorderLight
                                )
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(horizontal = 2.dp, vertical = 6.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.SpaceBetween
                                ) {
                                    // نشانگر شماره زنگ (اندازه ثابت و یکسان در تمام ۵ زنگ)
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (isAssigned) periodColor else Color(0xFF94A3B8),
                                        modifier = Modifier.height(20.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier.padding(horizontal = 5.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = "زنگ ${com.example.util.DateUtils.toPersianDigits(index + 1)}",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                        }
                                    }

                                    // نام درس هر زنگ با فونت درشت‌تر و خواناتر
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .fillMaxWidth()
                                            .padding(horizontal = 2.dp, vertical = 4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = if (isAssigned) subjectName else "بدون درس",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = if (subjectName.length > 8) 12.5.sp else 14.sp,
                                            color = if (isAssigned) TextPrimary else TextSecondary.copy(alpha = 0.65f),
                                            textAlign = TextAlign.Center,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis,
                                            lineHeight = 16.sp,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // ۳. شبکه منوهای اصلی سیستم (دسترسی سریع)
            Text(
                text = "دسترسی سریع",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = TextSecondary,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                // سطر اول: حضور و غیاب / ارزشیابی و تکالیف
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        DashboardCard(
                            title = "حضور و غیاب",
                            icon = Icons.Default.HowToReg,
                            color = PrimaryGreen,
                            badge = "${state.students.size} دانش‌آموز",
                            onClick = { onNavigate(Screen.ATTENDANCE) }
                        )
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        DashboardCard(
                            title = "ارزشیابی و تکالیف",
                            icon = Icons.Default.AssignmentTurnedIn,
                            color = EvaluationOrange,
                            badge = "${state.subjects.count { it.enabled }} درس فعال",
                            onClick = { onNavigate(Screen.EVALUATION) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // سطر دوم: امتیازات گروهی / یادداشت‌های معلم
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        DashboardCard(
                            title = "امتیازات گروهی",
                            icon = Icons.Default.Star,
                            color = AmberSecondary,
                            badge = "${state.groups.size} گروه",
                            onClick = { onNavigate(Screen.GROUPS) }
                        )
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        DashboardCard(
                            title = "یادداشت‌های معلم",
                            icon = Icons.Default.NoteAlt,
                            color = TeacherTeal,
                            badge = "${state.teacherNotes.size} یادداشت",
                            onClick = { onNavigate(Screen.NOTES) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // سطر سوم: ارزیابی عملکرد / جلسات اولیا
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        DashboardCard(
                            title = "ارزیابی عملکرد",
                            icon = Icons.Default.QueryStats,
                            color = SkyBlue,
                            badge = "تایم‌لاین و وضعیت",
                            onClick = { onNavigate(Screen.PERFORMANCE) }
                        )
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        DashboardCard(
                            title = "جلسات اولیا و مربیان",
                            icon = Icons.Default.Groups,
                            color = MeetingPurple,
                            badge = "${state.parentMeetings.size} جلسه ثبت‌شده",
                            onClick = { onNavigate(Screen.MEETINGS) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
        }
    }
}

    // دیالوگ تغییر تاریخ شمسی با تقویم گرافیکی تعاملی
    if (showDateDialog) {
        PersianDatePickerDialog(
            initialDate = state.currentDateShamsi,
            title = "تنظیم تاریخ روزانه",
            onDismiss = { showDateDialog = false },
            onConfirm = { chosenDate ->
                onDateChange(chosenDate)
                showDateDialog = false
            }
        )
    }

    // دیالوگ پشتیبان‌گیری (خروجی گرفتن)
    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            title = { Text("کد پشتیبان‌گیری شما", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "این متن را کپی کرده و در گوشی جدید جهت بازگردانی وارد کنید:",
                        fontSize = 13.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = Color(0xFFECEFF1),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 200.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(8.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            Text(
                                text = exportJsonText,
                                fontSize = 11.sp,
                                color = Color(0xFF37474F)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("ClassManager Backup", exportJsonText)
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(context, "کد پشتیبان‌گیری در حافظه کپی شد", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("کپی کد")
                }
            },
            dismissButton = {
                TextButton(onClick = { showExportDialog = false }) {
                    Text("بستن")
                }
            }
        )
    }

    // دیالوگ بازگردانی اطلاعات (Import)
    if (showImportDialog) {
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            title = { Text("بازگردانی اطلاعات", fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "کد پشتیبان‌گیری صادر شده را در کادر زیر جای‌گذاری کنید:",
                        fontSize = 13.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = importInputText,
                        onValueChange = { importInputText = it },
                        placeholder = { Text("کد پشتیبان‌گیری را اینجا پیست کنید...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp),
                        maxLines = 6
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (importInputText.isNotBlank()) {
                            val success = onImportBackup(importInputText.trim())
                            if (success) {
                                Toast.makeText(context, "اطلاعات با موفقیت بازگردانی شد.", Toast.LENGTH_LONG).show()
                                showImportDialog = false
                            } else {
                                Toast.makeText(context, "کد وارد شده معتبر نیست!", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                ) {
                    Text("بازگردانی")
                }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false }) {
                    Text("انصراف")
                }
            }
        )
    }

    // دیالوگ نمایش فقط لیست اسامی دانش‌آموزان غایب همان روز
    if (showTodayAbsenteesDialog) {
        val absentees = remember(state.students) {
            state.students.filter { it.status == "غایب" || it.status == "غیرموجه" }
        }

        AlertDialog(
            onDismissRequest = { showTodayAbsenteesDialog = false },
            icon = {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFEE2E2)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PersonOff,
                        contentDescription = null,
                        tint = Color(0xFFDC2626),
                        modifier = Modifier.size(28.dp)
                    )
                }
            },
            title = {
                Text(
                    text = "لیست دانش‌آموزان غایب امروز",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (absentees.isEmpty()) {
                        Surface(
                            color = Color(0xFFF0FDF4),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = PrimaryGreenDark)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "امروز هیچ دانش‌آموزی غایب نیست و تمام دانش‌آموزان حاضر هستند.",
                                    color = PrimaryGreenDark,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    } else {
                        Text(
                            text = "اسامی دانش‌آموزان غایب (${absentees.size} نفر):",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFDC2626)
                        )
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 300.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(absentees, key = { it.id }) { student ->
                                Surface(
                                    color = Color(0xFFF8FAFC),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(34.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFFFEE2E2)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = student.name.take(1),
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFFDC2626)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = student.name,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp,
                                                color = TextPrimary
                                            )
                                            if (student.fatherName.isNotBlank()) {
                                                Text(
                                                    text = "نام پدر: ${student.fatherName}",
                                                    fontSize = 11.sp,
                                                    color = TextSecondary
                                                )
                                            }
                                        }
                                        Surface(
                                            color = Color(0xFFFEE2E2),
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Text(
                                                text = student.status,
                                                color = Color(0xFFDC2626),
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showTodayAbsenteesDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                ) {
                    Text("بستن", fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // دیالوگ نمایش لیست متولدین این ماه
    if (showBirthdaysDialog) {
        var selectedMonthForView by remember(currentMonthName) { mutableStateOf(currentMonthName) }
        val studentsInSelectedMonth = remember(state.students, selectedMonthForView) {
            state.students.filter { isStudentBornInTargetMonth(it, selectedMonthForView) }
        }
        var monthDropdownExpanded by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showBirthdaysDialog = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFED7AA)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Cake,
                                contentDescription = null,
                                tint = Color(0xFFEA580C),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "متولدین ماه $selectedMonthForView",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color(0xFF9A3412)
                            )
                            Text(
                                text = "${com.example.util.DateUtils.toPersianDigits(studentsInSelectedMonth.size)} دانش‌آموز",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }

                    // امکان مشاهده متولدین سایر ماه‌ها
                    Box {
                        Surface(
                            onClick = { monthDropdownExpanded = true },
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFFFF7ED),
                            border = BorderStroke(1.dp, Color(0xFFFED7AA))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "تغییر ماه",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFFEA580C)
                                )
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = null,
                                    tint = Color(0xFFEA580C),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        DropdownMenu(
                            expanded = monthDropdownExpanded,
                            onDismissRequest = { monthDropdownExpanded = false }
                        ) {
                            allPersianMonths.forEach { m ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = if (m == currentMonthName) "$m (این ماه)" else m,
                                            fontWeight = if (m == selectedMonthForView) FontWeight.Bold else FontWeight.Normal,
                                            color = if (m == selectedMonthForView) Color(0xFFEA580C) else TextPrimary
                                        )
                                    },
                                    onClick = {
                                        selectedMonthForView = m
                                        monthDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (studentsInSelectedMonth.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = "🎂", fontSize = 38.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "در ماه $selectedMonthForView دانش‌آموزی متولد نشده است.",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = TextSecondary,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "جهت تغییر ماه از دکمه بالای کادر استفاده کنید.",
                                    fontSize = 11.sp,
                                    color = TextSecondary.copy(alpha = 0.8f),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 320.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(studentsInSelectedMonth, key = { it.id }) { student ->
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color(0xFFFFF7ED),
                                    border = BorderStroke(1.dp, Color(0xFFFED7AA)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFFFFEDD5)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(text = "🎈", fontSize = 20.sp)
                                        }

                                        Spacer(modifier = Modifier.width(10.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = student.name,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp,
                                                color = TextPrimary
                                            )
                                            if (student.birthDate.isNotBlank()) {
                                                Text(
                                                    text = "تاریخ تولد: ${com.example.util.DateUtils.toPersianDigits(student.birthDate)}",
                                                    fontSize = 11.sp,
                                                    color = TextSecondary
                                                )
                                            } else {
                                                Text(
                                                    text = "متولد: $selectedMonthForView",
                                                    fontSize = 11.sp,
                                                    color = TextSecondary
                                                )
                                            }
                                        }

                                        // دکمه کپی پیام تبریک اختصاصی برای این دانش‌آموز
                                        IconButton(
                                            onClick = {
                                                val msg = "🎉 گل پسر/دختر گلم، ${student.name} عزیز، زادروزت در ماه $selectedMonthForView فرخنده و شاد باد! با آرزوی روزهایی پر از موفقیت و سربلندی. معلم مهربان شما 🎂🎈"
                                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                                val clip = ClipData.newPlainText("تبریک تولد", msg)
                                                clipboard.setPrimaryClip(clip)
                                                Toast.makeText(context, "پیام تبریک برای ${student.name} کپی شد.", Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier.size(34.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.ContentCopy,
                                                contentDescription = "کپی پیام تبریک",
                                                tint = Color(0xFFEA580C),
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // دکمه کپی پیام تبریک عمومی ماهانه
                        Button(
                            onClick = {
                                val studentNames = studentsInSelectedMonth.joinToString("، ") { it.name }
                                val groupMessage = "🌸 با افتخار و شادمانی، زادروز شکوفه‌های کلاسمان در ماه $selectedMonthForView ($studentNames) را صمیمانه شادباش می‌گوییم. از درگاه خداوند برای این عزیزان سلامتی، شادی و توفیق روزافزون آرزومندیم. 🎂🎈🎉"
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("تبریک کلاسی", groupMessage)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "متن تبریک گروهی کپی شد.", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEA580C)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "کپی متن تبریک کلاسی برای شاد",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showBirthdaysDialog = false }) {
                    Text("بستن", fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // دیالوگ نمایش برنامه هفتگی کل هفته (فقط مشاهده)
    if (showWeeklyScheduleViewer) {
        ReadOnlyWeeklyScheduleDialog(
            weeklySchedule = state.weeklySchedule,
            todayDayName = realTodayName,
            onDismiss = { showWeeklyScheduleViewer = false }
        )
    }

    // دیالوگ انتخاب تم و شخصی‌سازی ظاهر برنامه
    if (showThemeDialog) {
        AlertDialog(
            onDismissRequest = { showThemeDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Palette,
                        contentDescription = null,
                        tint = appPrimaryColor
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "انتخاب تم برنامه",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val isDefaultSelected = !isGreenTheme && !isRedTheme

                    // گزینه ۱: تم اصلی
                    Surface(
                        onClick = {
                            onThemeChange("DEFAULT")
                            showThemeDialog = false
                            Toast.makeText(context, "تم اصلی فعال شد.", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(12.dp),
                        color = if (isDefaultSelected) PrimaryGreen.copy(alpha = 0.12f) else Color.White,
                        border = BorderStroke(
                            width = if (isDefaultSelected) 2.dp else 1.dp,
                            color = if (isDefaultSelected) PrimaryGreen else BorderLight
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("theme_option_default")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(PrimaryGreen),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isDefaultSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "تم اصلی",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = if (isDefaultSelected) PrimaryGreenDark else TextPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            RadioButton(
                                selected = isDefaultSelected,
                                onClick = {
                                    onThemeChange("DEFAULT")
                                    showThemeDialog = false
                                    Toast.makeText(context, "تم اصلی فعال شد.", Toast.LENGTH_SHORT).show()
                                }
                            )
                        }
                    }

                    // گزینه ۲: تم سبز
                    Surface(
                        onClick = {
                            onThemeChange("GREEN")
                            showThemeDialog = false
                            Toast.makeText(context, "تم سبز فعال شد.", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(12.dp),
                        color = if (isGreenTheme) ThemeGreenPrimary.copy(alpha = 0.14f) else Color.White,
                        border = BorderStroke(
                            width = if (isGreenTheme) 2.dp else 1.dp,
                            color = if (isGreenTheme) ThemeGreenPrimary else BorderLight
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("theme_option_green")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(ThemeGreenPrimary),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isGreenTheme) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "تم سبز",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = if (isGreenTheme) ThemeGreenPrimaryDark else TextPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            RadioButton(
                                selected = isGreenTheme,
                                onClick = {
                                    onThemeChange("GREEN")
                                    showThemeDialog = false
                                    Toast.makeText(context, "تم سبز فعال شد.", Toast.LENGTH_SHORT).show()
                                }
                            )
                        }
                    }

                    // گزینه ۳: تم قرمز
                    Surface(
                        onClick = {
                            onThemeChange("RED")
                            showThemeDialog = false
                            Toast.makeText(context, "تم قرمز فعال شد.", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(12.dp),
                        color = if (isRedTheme) ThemeRedPrimary.copy(alpha = 0.14f) else Color.White,
                        border = BorderStroke(
                            width = if (isRedTheme) 2.dp else 1.dp,
                            color = if (isRedTheme) ThemeRedPrimary else BorderLight
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("theme_option_red")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(ThemeRedPrimary),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isRedTheme) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "تم قرمز",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = if (isRedTheme) ThemeRedPrimaryDark else TextPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            RadioButton(
                                selected = isRedTheme,
                                onClick = {
                                    onThemeChange("RED")
                                    showThemeDialog = false
                                    Toast.makeText(context, "تم قرمز فعال شد.", Toast.LENGTH_SHORT).show()
                                }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showThemeDialog = false }) {
                    Text("بستن", fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
fun DashboardCard(
    title: String,
    icon: ImageVector,
    color: Color,
    badge: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(148.dp)
            .clickable { onClick() }
            .testTag("dashboard_card_${title}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .background(color.copy(alpha = 0.15f), shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = TextPrimary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = badge,
                fontSize = 11.sp,
                color = TextSecondary
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReadOnlyWeeklyScheduleDialog(
    weeklySchedule: List<DaySchedule>,
    todayDayName: String,
    onDismiss: () -> Unit
) {
    val daysList = listOf("شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه")
    val scheduleMap = remember(weeklySchedule) {
        weeklySchedule.associateBy { it.dayName }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp)
            .testTag("read_only_weekly_schedule_dialog"),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(PrimaryGreen.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = null,
                            tint = PrimaryGreen,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "برنامه هفتگی کل هفته",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = "نمای کامل برنامه درسی (شنبه تا چهارشنبه)",
                            fontSize = 11.5.sp,
                            color = TextSecondary
                        )
                    }
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "بستن", tint = TextSecondary)
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp)
            ) {
                Column(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    daysList.forEach { dayName ->
                        val isToday = dayName == todayDayName
                        val daySchedule = scheduleMap[dayName]
                        val rawPeriods = daySchedule?.periods ?: emptyList()
                        val periodsToDisplay = (0 until 5).map { idx ->
                            rawPeriods.getOrNull(idx)?.ifBlank { "—" } ?: "—"
                        }
                        val hasAnyAssigned = periodsToDisplay.any { it != "—" }

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isToday) PrimaryGreen.copy(alpha = 0.05f) else Color(0xFFF8FAFC)
                            ),
                            border = BorderStroke(
                                1.dp,
                                if (isToday) PrimaryGreen.copy(alpha = 0.4f) else BorderLight
                            )
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp)
                            ) {
                                // سربرگ روز
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = dayName,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.5.sp,
                                            color = if (isToday) PrimaryGreenDark else TextPrimary
                                        )
                                        if (isToday) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = PrimaryGreen.copy(alpha = 0.15f)
                                            ) {
                                                Text(
                                                    text = "امروز",
                                                    color = PrimaryGreenDark,
                                                    fontSize = 9.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }

                                    if (!hasAnyAssigned) {
                                        Text(
                                            text = "بدون زنگ ثبت‌شده",
                                            fontSize = 11.sp,
                                            color = TextSecondary.copy(alpha = 0.7f)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                // ۵ زنگ به صورت ردیف کارت‌های رنگی
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    periodsToDisplay.forEachIndexed { pIdx, subject ->
                                        val isAssigned = subject != "—" && subject.isNotBlank()
                                        val pColor = when (pIdx) {
                                            0 -> PrimaryGreen
                                            1 -> SkyBlue
                                            2 -> Color(0xFFD97706)
                                            3 -> TeacherTeal
                                            else -> MeetingPurple
                                        }

                                        Surface(
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(70.dp),
                                            shape = RoundedCornerShape(8.dp),
                                            color = if (isAssigned) pColor.copy(alpha = 0.08f) else Color.White,
                                            border = BorderStroke(
                                                1.dp,
                                                if (isAssigned) pColor.copy(alpha = 0.3f) else Color(0xFFE2E8F0)
                                            )
                                        ) {
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .padding(2.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Surface(
                                                    shape = RoundedCornerShape(4.dp),
                                                    color = if (isAssigned) pColor else Color(0xFFCBD5E1),
                                                    modifier = Modifier.padding(top = 2.dp)
                                                ) {
                                                    Text(
                                                        text = "زنگ ${com.example.util.DateUtils.toPersianDigits(pIdx + 1)}",
                                                        fontSize = 9.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color.White,
                                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                    )
                                                }

                                                Box(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .fillMaxWidth()
                                                        .padding(horizontal = 1.dp),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = subject,
                                                        fontSize = if (subject.length > 8) 10.sp else 11.sp,
                                                        fontWeight = if (isAssigned) FontWeight.Bold else FontWeight.Normal,
                                                        color = if (isAssigned) TextPrimary else Color(0xFF94A3B8),
                                                        textAlign = TextAlign.Center,
                                                        maxLines = 2,
                                                        overflow = TextOverflow.Ellipsis,
                                                        lineHeight = 13.sp
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("بستن", fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    )
}
