package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryGreen = Color(0xFF00A86B)
val PrimaryGreenDark = Color(0xFF00794D)
val PrimaryGreenLight = Color(0xFFE0F5EB)

val AmberSecondary = Color(0xFFFFB703)
val AmberSecondaryLight = Color(0xFFFFF3D4)

val SkyBlue = Color(0xFF0284C7)
val SkyBlueLight = Color(0xFFE0F2FE)

val TeacherTeal = Color(0xFF0D9488)
val TeacherTealLight = Color(0xFFCCFBF1)

val MeetingPurple = Color(0xFF8B5CF6)
val MeetingPurpleLight = Color(0xFFF3E8FF)

val EvaluationOrange = Color(0xFFF97316)
val EvaluationOrangeLight = Color(0xFFFFEDD5)

val AbsentRed = Color(0xFFEF4444)
val AbsentRedLight = Color(0xFFFEE2E2)

val BackgroundLight = Color(0xFFF4F7F6)
val SurfaceLight = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF1E293B)
val TextSecondary = Color(0xFF64748B)
val BorderLight = Color(0xFFE2E8F0)

// رنگ‌های تم سبز انتخابی (Green Theme)
val ThemeGreenPrimary = Color(0xFF15803D)        // سبز غنی جنگلی و خوانا
val ThemeGreenPrimaryDark = Color(0xFF14532D)    // سبز تیره عمیق
val ThemeGreenPrimaryLight = Color(0xFFDCFCE7)   // سبز روشن و ملایم پس‌زمینه کارت‌ها
val ThemeGreenSurface = Color(0xFFF0FDF4)        // سبز بسیار ملایم برای کارت‌ها
val ThemeGreenBackground = Color(0xFFE8F5E9)     // سبز ملایم کانتینر
val ThemeGreenCardBorder = Color(0xFFBBF7D0)     // حاشیه لطیف سبز
val ThemeGreenTextPrimary = Color(0xFF0F291E)    // متن بسیار تیره با ته‌رنگ سبز برای خوانایی حداکثری
val ThemeGreenTextSecondary = Color(0xFF2E6349)  // متن ثانویه با کنتراست بالا

// رنگ‌های تم قرمز انتخابی (Red Theme)
val ThemeRedPrimary = Color(0xFFB91C1C)          // قرمز یاقوتی گرم و غنی با کنتراست عالی
val ThemeRedPrimaryDark = Color(0xFF7F1D1D)      // قرمز عنابی و تیره عمیق
val ThemeRedPrimaryLight = Color(0xFFFEE2E2)     // زمینه روشن با ته‌رنگ قرمز ملایم
val ThemeRedSurface = Color(0xFFFFF7F5)          // سطح بسیار ملایم برای کارت‌ها
val ThemeRedBackground = Color(0xFFFDF4F0)       // پس‌زمینه گرم متناسب با تصویر پوستی
val ThemeRedCardBorder = Color(0xFFFECDD3)       // حاشیه لطیف قرمز
val ThemeRedTextPrimary = Color(0xFF1E1012)      // متن با کنتراست فوق‌العاده
val ThemeRedTextSecondary = Color(0xFF6B2D32)    // متن ثانویه خوانا
