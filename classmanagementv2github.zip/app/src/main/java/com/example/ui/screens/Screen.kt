package com.example.ui.screens

enum class Screen {
    HOME,
    PROFILE_SETTINGS,
    SCHEDULE,
    ATTENDANCE,
    EVALUATION,
    GROUPS,
    SUBJECTS,
    NOTES,
    MEETINGS,
    PERFORMANCE,
    CHARTS,
    BACKUP_RESTORE,
    PRO_ACTIVATION
}
