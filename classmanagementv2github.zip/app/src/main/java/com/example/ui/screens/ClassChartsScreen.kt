package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DailyAttendance
import com.example.model.Student
import com.example.model.SubjectItem
import com.example.ui.theme.*
import com.example.util.DateUtils
import kotlin.math.roundToInt

/**
 * صفحه نمودارهای آماری کلاسی (حضور و غیاب و میانگین نمرات دروس)
 * با رابط کاربری شکیل و روان، کامپوز خالص و مطابق زبان طراحی برنامه
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClassChartsScreen(
    students: List<Student>,
    subjects: List<SubjectItem>,
    attendanceHistory: List<DailyAttendance>,
    currentDate: String,
    onBack: () -> Unit
) {
    // تب‌ها: ۰: وضعیت حضور و غیاب کلاسی، ۱: میانگین و توزیع نمرات دروس
    var selectedTab by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "نمودارهای آماری کلاس",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = Color.White
                        )
                        Text(
                            text = if (selectedTab == 0) "نمودار وضعیت حضور و غیاب کلاسی" else "نمودار میانگین و توزیع نمرات دروس",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("charts_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "بازگشت",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PrimaryGreen)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BackgroundLight)
        ) {
            // سربرگ تب‌ها
            Surface(
                color = Color.White,
                shadowElevation = 2.dp
            ) {
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color.White,
                    contentColor = PrimaryGreen
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.PieChart,
                                    contentDescription = null,
                                    modifier = Modifier.size(17.dp),
                                    tint = if (selectedTab == 0) PrimaryGreen else TextSecondary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "حضور و غیاب",
                                    fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 13.sp
                                )
                            }
                        },
                        modifier = Modifier.testTag("tab_attendance_chart")
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.BarChart,
                                    contentDescription = null,
                                    modifier = Modifier.size(17.dp),
                                    tint = if (selectedTab == 1) PrimaryGreen else TextSecondary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "میانگین نمرات",
                                    fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 13.sp
                                )
                            }
                        },
                        modifier = Modifier.testTag("tab_grades_chart")
                    )
                }
            }

            // محتوای تب انتخاب‌شده
            if (selectedTab == 0) {
                AttendanceChartsTab(
                    students = students,
                    attendanceHistory = attendanceHistory,
                    currentDate = currentDate
                )
            } else {
                GradesChartsTab(
                    students = students,
                    subjects = subjects
                )
            }
        }
    }
}

// -----------------------------------------------------------------------------------------
// بخش اول: نمودارهای وضعیت حضور و غیاب
// -----------------------------------------------------------------------------------------

@Composable
private fun AttendanceChartsTab(
    students: List<Student>,
    attendanceHistory: List<DailyAttendance>,
    currentDate: String
) {
    if (students.isEmpty()) {
        EmptyStateView(
            icon = Icons.Default.PeopleOutline,
            title = "هنوز دانش‌آموزی ثبت نشده است",
            description = "برای مشاهده نمودارهای آماری، ابتدا از بخش دانش‌آموزان افراد کلاس را اضافه کنید."
        )
        return
    }

    // تجمیع آمار حضور و غیاب کل تاریخچه
    var totalPresentRecords = 0
    var totalUnexcusedRecords = 0
    var totalExcusedRecords = 0

    attendanceHistory.forEach { daily ->
        daily.records.forEach { r ->
            when (r.status) {
                "حاضر" -> totalPresentRecords++
                "غیرموجه", "غایب" -> totalUnexcusedRecords++
                "موجه" -> totalExcusedRecords++
            }
        }
    }

    // اگر تاریخچه غیبت هنوز خالی باشد، از وضعیت فعلی دانش‌آموزان در صفحه امروز استفاده شود
    if (attendanceHistory.isEmpty()) {
        students.forEach { s ->
            when (s.status) {
                "حاضر" -> totalPresentRecords++
                "غیرموجه", "غایب" -> totalUnexcusedRecords++
                "موجه" -> totalExcusedRecords++
            }
        }
    }

    val totalRecords = (totalPresentRecords + totalUnexcusedRecords + totalExcusedRecords).coerceAtLeast(1)
    val presentPercent = (totalPresentRecords * 100f / totalRecords).roundToInt()
    val unexcusedPercent = (totalUnexcusedRecords * 100f / totalRecords).roundToInt()
    val excusedPercent = (totalExcusedRecords * 100f / totalRecords).roundToInt()

    // آمار روزهای اخیر برای نمودار میله‌ای روند حضور
    val recentDays = remember(attendanceHistory) {
        attendanceHistory.takeLast(7)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // ۱. کارت نمودار دایره‌ای وضعیت کلی حضور
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, BorderLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "درصد کلی حضور و غیاب کلاس",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.5.sp,
                            color = TextPrimary
                        )
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = PrimaryGreen.copy(alpha = 0.1f)
                        ) {
                            Text(
                                text = "${DateUtils.toPersianDigits(totalRecords)} ثبت",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryGreenDark,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // نمودار دونات دایره‌ای اختصاصی با انیمیشن
                    DonutPieChart(
                        presentPercent = presentPercent.toFloat(),
                        unexcusedPercent = unexcusedPercent.toFloat(),
                        excusedPercent = excusedPercent.toFloat()
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // راهنمای رنگ‌های نمودار
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        LegendItem(
                            color = PrimaryGreen,
                            label = "حاضر",
                            value = "${DateUtils.toPersianDigits(presentPercent)}٪ (${DateUtils.toPersianDigits(totalPresentRecords)})"
                        )
                        LegendItem(
                            color = AbsentRed,
                            label = "غیرموجه",
                            value = "${DateUtils.toPersianDigits(unexcusedPercent)}٪ (${DateUtils.toPersianDigits(totalUnexcusedRecords)})"
                        )
                        LegendItem(
                            color = AmberSecondary,
                            label = "موجه",
                            value = "${DateUtils.toPersianDigits(excusedPercent)}٪ (${DateUtils.toPersianDigits(totalExcusedRecords)})"
                        )
                    }
                }
            }
        }

        // ۲. نمودار میله‌ای روند حضور در روزهای ثبت‌شده
        if (recentDays.isNotEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "روند درصد حضور در روزهای اخیر",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.5.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = "نمایش درصد حضور دانش‌آموزان به تفکیک تاریخ‌های ثبت‌شده",
                            fontSize = 11.sp,
                            color = TextSecondary,
                            modifier = Modifier.padding(top = 2.dp, bottom = 14.dp)
                        )

                        // نمودار میله‌ای عمودی روزها
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .padding(horizontal = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            recentDays.forEach { daily ->
                                val dayPresents = daily.records.count { it.status == "حاضر" }
                                val dayTotal = daily.records.size.coerceAtLeast(1)
                                val dayRate = (dayPresents * 100f / dayTotal).coerceIn(0f, 100f)

                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    // درصد بالای میله
                                    Text(
                                        text = "${DateUtils.toPersianDigits(dayRate.roundToInt())}٪",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (dayRate >= 90) PrimaryGreenDark else if (dayRate >= 75) AmberSecondary else AbsentRed
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))

                                    // ستون میله
                                    Box(
                                        modifier = Modifier
                                            .width(20.dp)
                                            .height(100.dp)
                                            .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                                            .background(Color(0xFFF1F5F9)),
                                        contentAlignment = Alignment.BottomCenter
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .fillMaxHeight(dayRate / 100f)
                                                .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                                                .background(
                                                    Brush.verticalGradient(
                                                        listOf(
                                                            if (dayRate >= 90) PrimaryGreen else if (dayRate >= 75) AmberSecondary else AbsentRed,
                                                            if (dayRate >= 90) PrimaryGreenLight else AmberSecondaryLight
                                                        )
                                                    )
                                                )
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))

                                    // برچسب تاریخ
                                    val shortDate = if (daily.date.length >= 5) daily.date.takeLast(5) else daily.date
                                    Text(
                                        text = shortDate,
                                        fontSize = 10.sp,
                                        color = TextSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // ۳. کارت منظم‌ترین و کم‌غیبت‌ترین دانش‌آموزان
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, BorderLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "میزان حضور به تفکیک دانش‌آموزان",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.5.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = "نظم کلاسی",
                            fontSize = 11.5.sp,
                            color = PrimaryGreenDark,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // لیست درصد حضور هر دانش‌آموز با خط پیشرفت
                    students.take(15).forEach { student ->
                        // محاسبه تعداد غیبت‌های این دانش‌آموز در کل تاریخچه
                        val absences = attendanceHistory.sumOf { daily ->
                            daily.records.count { it.studentId == student.id && (it.status == "غایب" || it.status == "غیرموجه" || it.status == "موجه") }
                        }
                        val presents = attendanceHistory.sumOf { daily ->
                            daily.records.count { it.studentId == student.id && it.status == "حاضر" }
                        }
                        val total = (absences + presents).coerceAtLeast(1)
                        val rate = if (attendanceHistory.isNotEmpty()) (presents * 100f / total).roundToInt() else 100

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 5.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = student.name,
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = TextPrimary
                                )
                                Text(
                                    text = if (absences == 0) "بدون غیبت (۱۰۰٪)" else "${DateUtils.toPersianDigits(absences)} غیبت (${DateUtils.toPersianDigits(rate)}٪)",
                                    fontSize = 11.5.sp,
                                    color = if (absences == 0) PrimaryGreenDark else if (absences <= 2) AmberSecondary else AbsentRed,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            // نوار پیشرفت افقی
                            LinearProgressIndicator(
                                progress = { rate / 100f },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = if (rate >= 90) PrimaryGreen else if (rate >= 75) AmberSecondary else AbsentRed,
                                trackColor = Color(0xFFF1F5F9)
                            )
                        }
                    }
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------------------
// بخش دوم: نمودارهای میانگین نمرات و ارزیابی کلاسی
// -----------------------------------------------------------------------------------------

data class SubjectGradeStats(
    val subjectName: String,
    val veryGoodCount: Int,
    val goodCount: Int,
    val acceptableCount: Int,
    val needsWorkCount: Int,
    val totalCount: Int,
    val averageScoreOutOf4: Float // از ۴ نمره (خیلی‌خوب=۴، خوب=۳، قابل‌قبول=۲، نیازبه‌تلاش=۱)
)

@Composable
private fun GradesChartsTab(
    students: List<Student>,
    subjects: List<SubjectItem>
) {
    if (students.isEmpty()) {
        EmptyStateView(
            icon = Icons.Default.School,
            title = "هنوز دانش‌آموزی ثبت نشده است",
            description = "برای مشاهده نمودارهای نمرات، ابتدا دانش‌آموزان را اضافه کنید."
        )
        return
    }

    // محاسبه آمار ارزیابی‌ها در سطح کل کلاس
    val allEvaluations = remember(students) {
        students.flatMap { it.evaluations }
    }

    val totalVeryGood = allEvaluations.count { it.score == "خیلی خوب" }
    val totalGood = allEvaluations.count { it.score == "خوب" }
    val totalAcceptable = allEvaluations.count { it.score == "قابل قبول" }
    val totalNeedsWork = allEvaluations.count { it.score == "نیاز به تلاش" }
    val totalEvals = allEvaluations.size.coerceAtLeast(1)

    // محاسبه میانگین نمرات به تفکیک دروس
    val activeSubjects = remember(subjects, allEvaluations) {
        val names = if (subjects.isNotEmpty()) {
            subjects.filter { it.enabled }.map { it.name }
        } else {
            listOf("قرآن", "فارسی", "ریاضی", "علوم تجربی", "هدیه‌های آسمان", "مطالعات اجتماعی", "املا", "انشا")
        }
        names
    }

    val subjectStatsList = remember(activeSubjects, allEvaluations) {
        activeSubjects.map { subjName ->
            val evals = allEvaluations.filter { it.subject == subjName }
            val vg = evals.count { it.score == "خیلی خوب" }
            val g = evals.count { it.score == "خوب" }
            val a = evals.count { it.score == "قابل قبول" }
            val nw = evals.count { it.score == "نیاز به تلاش" }
            val tot = evals.size
            val avg = if (tot > 0) {
                (vg * 4f + g * 3f + a * 2f + nw * 1f) / tot
            } else {
                0f
            }
            SubjectGradeStats(
                subjectName = subjName,
                veryGoodCount = vg,
                goodCount = g,
                acceptableCount = a,
                needsWorkCount = nw,
                totalCount = tot,
                averageScoreOutOf4 = avg
            )
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // ۱. کارت توزیع کلی نمرات توصیفی کلاس (خیلی خوب، خوب، ...)
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, BorderLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "توزیع کلی نمرات کلاسی",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.5.sp,
                            color = TextPrimary
                        )
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = SkyBlue.copy(alpha = 0.1f)
                        ) {
                            Text(
                                text = "${DateUtils.toPersianDigits(allEvaluations.size)} ارزیابی",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = SkyBlue,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    if (allEvaluations.isEmpty()) {
                        Text(
                            text = "هنوز نمره‌ای در بخش ارزیابی ثبت نشده است. از بخش «ارزیابی عملکرد» می‌توانید برای دانش‌آموزان نمره ثبت کنید.",
                            fontSize = 12.sp,
                            color = TextSecondary,
                            lineHeight = 18.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp)
                        )
                    } else {
                        // ۴ نوار میله‌ای افقی برای سطوح مختلف
                        GradeLevelProgressBar(
                            label = "خیلی خوب",
                            count = totalVeryGood,
                            total = totalEvals,
                            color = PrimaryGreen
                        )
                        GradeLevelProgressBar(
                            label = "خوب",
                            count = totalGood,
                            total = totalEvals,
                            color = SkyBlue
                        )
                        GradeLevelProgressBar(
                            label = "قابل قبول",
                            count = totalAcceptable,
                            total = totalEvals,
                            color = AmberSecondary
                        )
                        GradeLevelProgressBar(
                            label = "نیاز به تلاش",
                            count = totalNeedsWork,
                            total = totalEvals,
                            color = AbsentRed
                        )
                    }
                }
            }
        }

        // ۲. کارت نمودار میله‌ای مقایسه میانگین دروس
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, BorderLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "میانگین نمرات به تفکیک دروس (از ۴)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.5.sp,
                        color = TextPrimary
                    )
                    Text(
                        text = "مقیاس استاندارد: ۴ = خیلی خوب • ۳ = خوب • ۲ = قابل قبول • ۱ = نیاز به تلاش",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        modifier = Modifier.padding(top = 2.dp, bottom = 14.dp)
                    )

                    // نمایش هر درس همراه با میانگین و بار افقی
                    subjectStatsList.forEach { stat ->
                        val avg = stat.averageScoreOutOf4
                        val percent = (avg / 4f).coerceIn(0f, 1f)
                        val barColor = when {
                            avg >= 3.5f -> PrimaryGreen
                            avg >= 2.8f -> SkyBlue
                            avg >= 2.0f -> AmberSecondary
                            avg > 0f -> AbsentRed
                            else -> Color(0xFFCBD5E1)
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 5.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(barColor)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = stat.subjectName,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = TextPrimary
                                    )
                                }
                                Text(
                                    text = if (stat.totalCount > 0)
                                        "${DateUtils.toPersianDigits(String.format(java.util.Locale.US, "%.1f", avg))} از ۴ (${DateUtils.toPersianDigits(stat.totalCount)} ثبت)"
                                    else
                                        "بدون نمره",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (stat.totalCount > 0) barColor else TextSecondary
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            // میله رنگی پیشرفت نمره
                            LinearProgressIndicator(
                                progress = { percent },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp)),
                                color = barColor,
                                trackColor = Color(0xFFF1F5F9)
                            )
                        }
                    }
                }
            }
        }

        // ۳. کارت توصیه‌های آموزشی بر اساس میانگین
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                border = BorderStroke(1.dp, PrimaryGreen.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.Lightbulb,
                        contentDescription = null,
                        tint = PrimaryGreen,
                        modifier = Modifier
                            .size(22.dp)
                            .padding(top = 2.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "تحلیل وضعیت یادگیری کلاس",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = PrimaryGreenDark
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        val weakestSubject = subjectStatsList.filter { it.totalCount > 0 }.minByOrNull { it.averageScoreOutOf4 }
                        val strongestSubject = subjectStatsList.filter { it.totalCount > 0 }.maxByOrNull { it.averageScoreOutOf4 }

                        val tipText = when {
                            allEvaluations.isEmpty() -> "هنوز نمره‌ای برای ارزیابی دروس وارد نشده است. با ثبت نمرات، تحلیل هوشمند نقاط قوت و ضعف کلاس اینجا نمایش داده می‌شود."
                            weakestSubject != null && strongestSubject != null && weakestSubject != strongestSubject ->
                                "کلاس در درس «${strongestSubject.subjectName}» دارای بالاترین میانگین و در درس «${weakestSubject.subjectName}» نیازمند تمرین و تثبیت بیشتر مفاهیم است."
                            strongestSubject != null ->
                                "میانگین نمرات کلاس در وضعیت مناسبی قرار دارد."
                            else -> "وضعیت کلی کلاس متعادل ارزیابی می‌شود."
                        }

                        Text(
                            text = tipText,
                            fontSize = 11.5.sp,
                            color = TextPrimary,
                            lineHeight = 17.sp
                        )
                    }
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------------------
// اجزای کمکی طراحی و رسم نمودارها
// -----------------------------------------------------------------------------------------

/**
 * رسم نمودار دایره‌ای دونات به کمک Canvas
 */
@Composable
private fun DonutPieChart(
    presentPercent: Float,
    unexcusedPercent: Float,
    excusedPercent: Float
) {
    val total = (presentPercent + unexcusedPercent + excusedPercent).coerceAtLeast(1f)
    val presentAngle = (presentPercent / total) * 360f
    val unexcusedAngle = (unexcusedPercent / total) * 360f
    val excusedAngle = (excusedPercent / total) * 360f

    val animPresentAngle by animateFloatAsState(
        targetValue = presentAngle,
        animationSpec = tween(durationMillis = 800),
        label = "animPresentAngle"
    )

    Box(
        modifier = Modifier.size(160.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 24.dp.toPx()
            val diameter = size.minDimension - strokeWidth
            val topLeft = Offset(strokeWidth / 2, strokeWidth / 2)
            val arcSize = Size(diameter, diameter)

            // دایره پس‌زمینه
            drawArc(
                color = Color(0xFFF1F5F9),
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth)
            )

            // کمان حاضر
            var currentStart = -90f
            if (animPresentAngle > 0f) {
                drawArc(
                    color = PrimaryGreen,
                    startAngle = currentStart,
                    sweepAngle = animPresentAngle,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )
                currentStart += animPresentAngle
            }

            // کمان غیرموجه
            if (unexcusedAngle > 0f) {
                drawArc(
                    color = AbsentRed,
                    startAngle = currentStart,
                    sweepAngle = unexcusedAngle,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )
                currentStart += unexcusedAngle
            }

            // کمان موجه
            if (excusedAngle > 0f) {
                drawArc(
                    color = AmberSecondary,
                    startAngle = currentStart,
                    sweepAngle = excusedAngle,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )
            }
        }

        // متن وسط دونات
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "${DateUtils.toPersianDigits(presentPercent.roundToInt())}٪",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = PrimaryGreenDark
            )
            Text(
                text = "حضور کلاس",
                fontSize = 10.5.sp,
                color = TextSecondary
            )
        }
    }
}

@Composable
private fun LegendItem(
    color: Color,
    label: String,
    value: String
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(5.dp))
        Column {
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = TextPrimary
            )
            Text(
                text = value,
                fontSize = 10.sp,
                color = TextSecondary
            )
        }
    }
}

@Composable
private fun GradeLevelProgressBar(
    label: String,
    count: Int,
    total: Int,
    color: Color
) {
    val percent = if (total > 0) (count * 100f / total).roundToInt() else 0
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Medium,
                color = TextPrimary
            )
            Text(
                text = "${DateUtils.toPersianDigits(percent)}٪ (${DateUtils.toPersianDigits(count)} نفر)",
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { percent / 100f },
            modifier = Modifier
                .fillMaxWidth()
                .height(7.dp)
                .clip(RoundedCornerShape(3.5.dp)),
            color = color,
            trackColor = Color(0xFFF1F5F9)
        )
    }
}

@Composable
private fun EmptyStateView(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(PrimaryGreen.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = PrimaryGreen,
                    modifier = Modifier.size(32.dp)
                )
            }
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = description,
                fontSize = 12.sp,
                color = TextSecondary,
                textAlign = TextAlign.Center,
                lineHeight = 18.sp
            )
        }
    }
}
