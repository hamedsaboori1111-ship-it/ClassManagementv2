package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.BorderLight
import com.example.ui.theme.PrimaryGreen
import com.example.ui.theme.PrimaryGreenDark
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.DateUtils

/**
 * تقویم شمسی زیبا، کوچک و دقیق برای انتخاب تعاملی تاریخ
 * بدون نیاز به ورود دستی اعداد توسط معلم
 */
@Composable
fun PersianDatePickerDialog(
    initialDate: String = "",
    title: String = "انتخاب تاریخ",
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    val todayJalali = remember { DateUtils.getCurrentJalaliDate() }

    // تجزیه تاریخ ورودی یا استفاده از تاریخ امروز گوشی
    val parsed = remember(initialDate) {
        DateUtils.parseJalali(initialDate) ?: todayJalali
    }

    var selectedYear by remember { mutableIntStateOf(parsed.year) }
    var selectedMonth by remember { mutableIntStateOf(parsed.month) }
    var selectedDay by remember { mutableIntStateOf(parsed.day) }

    // حالت انتخاب سریع سال از لیست
    var showYearPicker by remember { mutableStateOf(false) }

    // محاسبه حداکثر روزهای ماه انتخاب شده
    val maxDaysInSelectedMonth = remember(selectedYear, selectedMonth) {
        DateUtils.getDaysInMonth(selectedYear, selectedMonth)
    }

    // اصلاح روز در صورت تغییر ماه به ماه‌های ۳۰ یا ۲۹ روزه
    LaunchedEffect(maxDaysInSelectedMonth) {
        if (selectedDay > maxDaysInSelectedMonth) {
            selectedDay = maxDaysInSelectedMonth
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 12.dp)
                .testTag("persian_date_picker_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // ۱. هدر بالای تقویم با عنوان و دکمه تنظیم سریع به امروز
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = null,
                            tint = PrimaryGreen,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = TextPrimary
                        )
                    }

                    // دکمه تنظیم سریع به امروز
                    FilledTonalButton(
                        onClick = {
                            selectedYear = todayJalali.year
                            selectedMonth = todayJalali.month
                            selectedDay = todayJalali.day
                            showYearPicker = false
                        },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = PrimaryGreen.copy(alpha = 0.12f),
                            contentColor = PrimaryGreenDark
                        ),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Icon(Icons.Default.Today, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("امروز", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // ۲. نمایش کادر تاریخ انتخابی با فونت برجسته
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFF0FDF4),
                    border = BorderStroke(1.dp, PrimaryGreen.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp, horizontal = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "تاریخ انتخابی:",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                        Text(
                            text = "${DateUtils.toPersianDigits(selectedDay)} ${DateUtils.getMonthName(selectedMonth)} ${DateUtils.toPersianDigits(selectedYear)}",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryGreenDark
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // ۳. ناوبری سال و ماه
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // تغییر ماه قبلی
                    IconButton(
                        onClick = {
                            if (selectedMonth > 1) {
                                selectedMonth--
                            } else {
                                selectedMonth = 12
                                selectedYear--
                            }
                            showYearPicker = false
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "ماه قبل",
                            tint = PrimaryGreenDark
                        )
                    }

                    // نام ماه و سال جاری به عنوان دکمه تعاملی
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // چیپ نام ماه
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFF8FAFC),
                            border = BorderStroke(1.dp, BorderLight),
                            modifier = Modifier.clickable {
                                showYearPicker = false
                            }
                        ) {
                            Text(
                                text = DateUtils.getMonthName(selectedMonth),
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = TextPrimary,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }

                        // چیپ سال با قابلیت باز کردن لیست سال‌ها
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (showYearPicker) PrimaryGreen else Color(0xFFF8FAFC),
                            border = BorderStroke(1.dp, if (showYearPicker) PrimaryGreen else BorderLight),
                            modifier = Modifier.clickable {
                                showYearPicker = !showYearPicker
                            }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = DateUtils.toPersianDigits(selectedYear),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = if (showYearPicker) Color.White else TextPrimary
                                )
                                Spacer(modifier = Modifier.width(2.dp))
                                Icon(
                                    imageVector = if (showYearPicker) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                                    contentDescription = null,
                                    tint = if (showYearPicker) Color.White else TextSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    // تغییر ماه بعدی
                    IconButton(
                        onClick = {
                            if (selectedMonth < 12) {
                                selectedMonth++
                            } else {
                                selectedMonth = 1
                                selectedYear++
                            }
                            showYearPicker = false
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "ماه بعد",
                            tint = PrimaryGreenDark
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // ۴. ناحیه محتوا: یا شبکه روزهای ماه یا انتخابگر سال‌ها
                if (showYearPicker) {
                    // انتخاب سریع سال
                    val startYear = 1350
                    val endYear = 1415
                    val years = remember { (endYear downTo startYear).toList() }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(230.dp)
                    ) {
                        Text(
                            text = "انتخاب سال:",
                            fontSize = 12.sp,
                            color = TextSecondary,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(4),
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(years) { y ->
                                val isSelected = y == selectedYear
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) PrimaryGreen else Color(0xFFF8FAFC),
                                    border = BorderStroke(1.dp, if (isSelected) PrimaryGreen else BorderLight),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            selectedYear = y
                                            showYearPicker = false
                                        }
                                ) {
                                    Text(
                                        text = DateUtils.toPersianDigits(y),
                                        fontSize = 13.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) Color.White else TextPrimary,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(vertical = 8.dp)
                                    )
                                }
                            }
                        }
                    }
                } else {
                    // شبکه روزهای ماه (۱ تا ۲۹/۳۰/۳۱)
                    Column(modifier = Modifier.fillMaxWidth()) {
                        // انتخاب سریع ماه از لیست ۱۲ ماه
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // ۶ ماه اول یا ۶ ماه دوم بر اساس ماه جاری
                            val monthBatch = if (selectedMonth <= 6) (1..6) else (7..12)
                            monthBatch.forEach { m ->
                                val isCurMonth = m == selectedMonth
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (isCurMonth) PrimaryGreen.copy(alpha = 0.15f) else Color.Transparent,
                                    border = if (isCurMonth) BorderStroke(1.dp, PrimaryGreen) else null,
                                    modifier = Modifier.clickable { selectedMonth = m }
                                ) {
                                    Text(
                                        text = DateUtils.getMonthName(m).take(4),
                                        fontSize = 10.5.sp,
                                        fontWeight = if (isCurMonth) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isCurMonth) PrimaryGreenDark else TextSecondary,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        HorizontalDivider(color = BorderLight, thickness = 0.5.dp)
                        Spacer(modifier = Modifier.height(8.dp))

                        // گرید روزها (۷ ستون)
                        val days = remember(maxDaysInSelectedMonth) { (1..maxDaysInSelectedMonth).toList() }

                        LazyVerticalGrid(
                            columns = GridCells.Fixed(7),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(190.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            items(days) { dayNum ->
                                val isSelected = dayNum == selectedDay
                                val isToday = dayNum == todayJalali.day &&
                                        selectedMonth == todayJalali.month &&
                                        selectedYear == todayJalali.year

                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .aspectRatio(1f)
                                        .clip(CircleShape)
                                        .background(
                                            when {
                                                isSelected -> PrimaryGreen
                                                isToday -> Color(0xFFDCFCE7)
                                                else -> Color.Transparent
                                            }
                                        )
                                        .clickable {
                                            selectedDay = dayNum
                                        }
                                ) {
                                    Text(
                                        text = DateUtils.toPersianDigits(dayNum),
                                        fontSize = 13.sp,
                                        fontWeight = if (isSelected || isToday) FontWeight.Bold else FontWeight.Normal,
                                        color = when {
                                            isSelected -> Color.White
                                            isToday -> PrimaryGreenDark
                                            else -> TextPrimary
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = BorderLight)
                Spacer(modifier = Modifier.height(10.dp))

                // ۵. دکمه‌های تأیید و انصراف
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("date_picker_cancel_btn")
                    ) {
                        Text("انصراف", color = TextSecondary)
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = {
                            val formatted = DateUtils.formatJalali(selectedYear, selectedMonth, selectedDay, persianDigits = true)
                            onConfirm(formatted)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("date_picker_confirm_btn")
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تأیید تاریخ", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

/**
 * فیلد نمایش و انتخاب تاریخ به صورت گرافیکی و استاندارد
 * با استایل، ابعاد و ظاهر کاملاً هماهنگ با OutlinedTextFieldهای فرم
 */
@Composable
fun PersianDateField(
    value: String,
    onDateSelected: (String) -> Unit,
    label: String = "تاریخ",
    placeholder: String = "انتخاب از تقویم...",
    modifier: Modifier = Modifier
) {
    var showDialog by remember { mutableStateOf(false) }

    OutlinedTextField(
        value = if (value.isNotBlank()) DateUtils.toPersianDigits(value) else "",
        onValueChange = {},
        readOnly = true,
        label = { Text(label, fontSize = 13.sp) },
        placeholder = { Text(placeholder, fontSize = 12.sp, color = TextSecondary.copy(alpha = 0.7f)) },
        trailingIcon = {
            IconButton(
                onClick = { showDialog = true },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CalendarMonth,
                    contentDescription = "انتخاب تاریخ از تقویم",
                    tint = PrimaryGreen,
                    modifier = Modifier.size(20.dp)
                )
            }
        },
        singleLine = true,
        modifier = modifier
            .fillMaxWidth()
            .clickable { showDialog = true }
    )

    if (showDialog) {
        PersianDatePickerDialog(
            initialDate = value,
            title = "انتخاب $label",
            onDismiss = { showDialog = false },
            onConfirm = { chosenDate ->
                onDateSelected(chosenDate)
                showDialog = false
            }
        )
    }
}
