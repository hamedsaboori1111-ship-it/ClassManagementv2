package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BackupSummary
import com.example.data.LocalBackupFile
import com.example.data.StorageLocationOption
import com.example.ui.theme.*
import com.example.util.DateUtils
import com.example.util.DemoConfig
import com.example.viewmodel.ClassViewModel
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupRestoreScreen(
    viewModel: ClassViewModel,
    onBack: () -> Unit,
    onNavigateToPro: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val state by viewModel.state.collectAsState()
    val isDemoActive = DemoConfig.isDemoActive(context)

    var localBackups by remember { mutableStateOf(listOf<LocalBackupFile>()) }

    fun refreshBackupsList() {
        localBackups = viewModel.listLocalBackups()
    }

    LaunchedEffect(Unit) {
        refreshBackupsList()
    }

    // Dialog states
    var showCreateBackupDialog by remember { mutableStateOf(false) }
    var backupCustomTitle by remember { mutableStateOf("") }
    var showDemoRestoreDialog by remember { mutableStateOf(false) }

    var backupToRestore by remember { mutableStateOf<LocalBackupFile?>(null) }
    var backupToDelete by remember { mutableStateOf<LocalBackupFile?>(null) }

    var pendingRestoreUri by remember { mutableStateOf<Uri?>(null) }
    var pendingRestoreSummary by remember { mutableStateOf<BackupSummary?>(null) }

    var storagePath by remember { mutableStateOf(viewModel.getBackupStoragePath()) }
    var isCustomStoragePath by remember { mutableStateOf(viewModel.isUsingCustomBackupPath()) }
    var showChangePathDialog by remember { mutableStateOf(false) }

    // SAF Open Document launcher (بازیابی از فایل انتخابی در حافظه گوشی)
    val importFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (isDemoActive) {
            showDemoRestoreDialog = true
            return@rememberLauncherForActivityResult
        }
        if (uri != null) {
            try {
                val json = context.contentResolver.openInputStream(uri)?.use {
                    it.bufferedReader(Charsets.UTF_8).readText()
                }
                if (json != null) {
                    val summary = viewModel.parseBackupSummary(json)
                    if (summary.isValid) {
                        pendingRestoreUri = uri
                        pendingRestoreSummary = summary
                    } else {
                        Toast.makeText(
                            context,
                            "فایل انتخاب شده ساختار معتبر اطلاعات کلاس را ندارد!",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "خطا در خواندن فایل انتخاب‌شده!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Calculate live total stats
    val totalEvaluationsCount = remember(state.students) {
        state.students.sumOf { it.evaluations.size }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "ذخیره و بازیابی اطلاعات کلاس",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("backup_back_button")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "بازگشت"
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { refreshBackupsList() },
                        modifier = Modifier.testTag("backup_refresh_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "تازه‌سازی فهرست"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PrimaryGreen,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(BackgroundLight)
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ۱. بنر آرامش خاطر و وضعیت امنیت ارزیابی‌ها
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(
                                        PrimaryGreenDark.copy(alpha = 0.95f),
                                        PrimaryGreen
                                    )
                                )
                            )
                            .padding(16.dp)
                    ) {
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.VerifiedUser,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "امنیت کامل اطلاعات ارزیابی شما",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "ذخیره‌سازی مستقیم روی حافظه گوشی بدون نیاز به اینترنت",
                                        fontSize = 11.5.sp,
                                        color = Color.White.copy(alpha = 0.85f)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Text(
                                text = "تمام نمرات درسی، غیبت‌ها، تکالیف و مشخصات دانش‌آموزان به صورت محلی در دستگاه شما قرار دارند. با ایجاد نسخه‌های پشتیبان خیالتان از تعویض گوشی یا بروز هرگونه مشکل کاملاً آسوده خواهد بود.",
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.92f),
                                lineHeight = 19.sp
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // آمارهای زنده داده‌های فعلی کلاس
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color.Black.copy(alpha = 0.15f)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp, horizontal = 12.dp),
                                    horizontalArrangement = Arrangement.SpaceAround
                                ) {
                                    StatMiniBadge(
                                        label = "دانش‌آموز",
                                        value = "${DateUtils.toPersianDigits(state.students.size)}"
                                    )
                                    StatMiniBadge(
                                        label = "ارزیابی ثبت‌شده",
                                        value = "${DateUtils.toPersianDigits(totalEvaluationsCount)}"
                                    )
                                    StatMiniBadge(
                                        label = "جلسه حضورغیاب",
                                        value = "${DateUtils.toPersianDigits(state.attendanceHistory.size)}"
                                    )
                                    StatMiniBadge(
                                        label = "درس کلاسی",
                                        value = "${DateUtils.toPersianDigits(state.subjects.size)}"
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // ۲. دکمه‌های عملیات اصلی (ذخیره فوری، خروجی به حافظه، بازیابی فایل)
            item {
                Text(
                    text = "عملیات پشتیبان‌گیری و بازیابی",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = TextPrimary,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // دکمه ۱: پشتیبان‌گیری فوری در دستگاه
                    Button(
                        onClick = {
                            val className = state.profile.educationalTitle.ifBlank { "کلاس" }.replace(" ", "_")
                            val defaultName = "${DateUtils.getCurrentShamsiDate().replace('/', '-')}_${className}"
                            backupCustomTitle = defaultName
                            showCreateBackupDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("btn_create_backup_instant")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Save,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ذخیره در حافظه",
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // دکمه ۲: بازیابی از فایل گوشی
                    Button(
                        onClick = {
                            if (isDemoActive) {
                                showDemoRestoreDialog = true
                            } else {
                                importFileLauncher.launch(arrayOf("application/json", "*/*"))
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isDemoActive) Color(0xFFF1F5F9) else SkyBlue
                        ),
                        border = if (isDemoActive) BorderStroke(1.dp, Color(0xFFCBD5E1)) else null,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("btn_open_file_restore")
                    ) {
                        Icon(
                            imageVector = if (isDemoActive) Icons.Default.Lock else Icons.Default.FileUpload,
                            contentDescription = null,
                            tint = if (isDemoActive) Color(0xFF64748B) else Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isDemoActive) "بازیابی (قفل دمو)" else "بازیابی از فایل",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDemoActive) Color(0xFF475569) else Color.White
                        )
                    }
                }
            }

            // بنر هشدار قفل بودن بازیابی در نسخه دمو
            if (isDemoActive) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showDemoRestoreDialog = true }
                            .testTag("card_demo_restore_notice"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB)),
                        border = BorderStroke(1.dp, Color(0xFFFDE68A))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFFEF3C7)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = "قفل دمو",
                                    tint = Color(0xFFD97706),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "بخش بازیابی در نسخه دمو قفل می‌باشد",
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF92400E)
                                )
                                Text(
                                    text = "برای بازیابی فایل‌ها و استفاده نامحدود، نسخه پرو را فعال کنید.",
                                    fontSize = 11.sp,
                                    color = Color(0xFFB45309),
                                    lineHeight = 16.sp
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.ChevronLeft,
                                contentDescription = null,
                                tint = Color(0xFFD97706),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }

            // نمایش و تغییر محل ذخیره‌سازی فایل‌های پشتیبان
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Folder,
                                    contentDescription = null,
                                    tint = SkyBlue,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "محل ذخیره‌سازی فایل‌های پشتیبان:",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            }

                            // دکمه تغییر محل ذخیره‌سازی
                            TextButton(
                                onClick = { showChangePathDialog = true },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = null,
                                    tint = PrimaryGreen,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "تغییر محل",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryGreen
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.White, RoundedCornerShape(8.dp))
                                .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = storagePath,
                                fontSize = 11.sp,
                                color = Color(0xFF334155),
                                modifier = Modifier.weight(1f),
                                maxLines = 2
                            )
                            IconButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("مسیر پشتیبان", storagePath))
                                    Toast.makeText(context, "مسیر کپی شد.", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "کپی مسیر",
                                    tint = PrimaryGreen,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        if (isCustomStoragePath) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = SkyBlue.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = "مسیر اختصاصی فعال است",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0284C7),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                TextButton(
                                    onClick = {
                                        viewModel.resetToDefaultStoragePath()
                                        storagePath = viewModel.getBackupStoragePath()
                                        isCustomStoragePath = false
                                        refreshBackupsList()
                                        Toast.makeText(context, "به مسیر پیش‌فرض بازگردانی شد.", Toast.LENGTH_SHORT).show()
                                    },
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text(
                                        text = "بازگشت به پیش‌فرض",
                                        fontSize = 11.sp,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // ۳. سربرگ نسخه‌های ذخیره شده روی دستگاه
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Folder,
                            contentDescription = null,
                            tint = PrimaryGreen,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "نسخه‌های پشتیبان موجود در دستگاه",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = TextPrimary
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = PrimaryGreen.copy(alpha = 0.12f)
                    ) {
                        Text(
                            text = "${DateUtils.toPersianDigits(localBackups.size)} از ۴ نسخه",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryGreenDark,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            // راهنمای سقف ۴ نسخه و ترتیب نمایش
            item {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF1F5F9),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = Color(0xFF64748B),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "سقف نگهداری ۴ نسخه است (جدیدترین نسخه در بالا و قدیمی‌ترین در پایین قرار دارد). در صورت ایجاد نسخه جدید، قدیمی‌ترین نسخه به طور کاملاً اتوماتیک حذف خواهد شد.",
                            fontSize = 11.sp,
                            color = Color(0xFF475569),
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            // ۴. لیست نسخه‌های ذخیره شده
            if (localBackups.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, BorderLight)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(PrimaryGreen.copy(alpha = 0.1f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CloudSync,
                                    contentDescription = null,
                                    tint = PrimaryGreen,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "هنوز نسخه‌ای در حافظه دستگاه ایجاد نشده است",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "با زدن دکمه «ذخیره در حافظه»، نسخه کاملی از تمام ارزشیابی‌ها، حضور و غیاب و اطلاعات دانش‌آموزان روی گوشی شما ثبت می‌شود.",
                                fontSize = 12.sp,
                                color = TextSecondary,
                                textAlign = TextAlign.Center,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            } else {
                itemsIndexed(localBackups, key = { _, backup -> backup.file.absolutePath }) { index, backup ->
                    LocalBackupCard(
                        backup = backup,
                        isNewest = index == 0,
                        isOldest = index == localBackups.lastIndex && localBackups.size > 1,
                        isDemo = isDemoActive,
                        onRestore = {
                            if (isDemoActive) {
                                showDemoRestoreDialog = true
                            } else {
                                backupToRestore = backup
                            }
                        },
                        onShare = { viewModel.shareBackup(context, backup.file) },
                        onDelete = { backupToDelete = backup }
                    )
                }
            }

            // فضای خالی در انتهای لیست
            item {
                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }

    // دیالوگ ایجاد نسخه پشتیبان جدید در دستگاه
    if (showCreateBackupDialog) {
        AlertDialog(
            onDismissRequest = { showCreateBackupDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.Save,
                    contentDescription = null,
                    tint = PrimaryGreen,
                    modifier = Modifier.size(28.dp)
                )
            },
            title = {
                Text(
                    text = "ذخیره نسخه پشتیبان جدید",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "نام پیش‌فرض فایل پشتیبان بر اساس تاریخ و نام کلاس تنظیم شده است. در صورت نیاز می‌توانید آن را ویرایش نمایید:",
                        fontSize = 12.5.sp,
                        color = TextSecondary,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = backupCustomTitle,
                        onValueChange = { backupCustomTitle = it },
                        label = { Text("نام فایل پشتیبان") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_backup_title")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val created = viewModel.createLocalBackup(backupCustomTitle.ifBlank { null })
                        showCreateBackupDialog = false
                        if (created != null) {
                            refreshBackupsList()
                            Toast.makeText(
                                context,
                                "نسخه پشتیبان با موفقیت در دستگاه ذخیره شد.",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            Toast.makeText(
                                context,
                                "خطا در ذخیره‌سازی نسخه پشتیبان!",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                ) {
                    Text("ذخیره در دستگاه", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateBackupDialog = false }) {
                    Text("انصراف")
                }
            }
        )
    }

    // دیالوگ تایید بازگردانی نسخه محلی
    if (backupToRestore != null) {
        val target = backupToRestore!!
        AlertDialog(
            onDismissRequest = { backupToRestore = null },
            icon = {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = Color(0xFFD97706),
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = "آیا از بازگردانی این نسخه اطمینان دارید؟",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "با تایید این مرحله، اطلاعات فعلی کلاس با نسخه انتخاب شده جایگزین خواهند شد:",
                        fontSize = 12.5.sp,
                        color = TextPrimary
                    )

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFFFFBEB),
                        border = BorderStroke(1.dp, Color(0xFFFDE68A)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = target.title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color(0xFF92400E)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "تاریخ ثبت: ${target.dateShamsi} ساعت ${target.time}",
                                fontSize = 11.5.sp,
                                color = Color(0xFFB45309)
                            )
                            Text(
                                text = "تعداد دانش‌آموزان: ${DateUtils.toPersianDigits(target.studentsCount)} نفر",
                                fontSize = 11.5.sp,
                                color = Color(0xFFB45309)
                            )
                            Text(
                                text = "تعداد کل ارزیابی‌ها: ${DateUtils.toPersianDigits(target.evaluationsCount)} مورد",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFB45309)
                            )
                            Text(
                                text = "جلسات حضور و غیاب: ${DateUtils.toPersianDigits(target.attendanceDaysCount)} روز",
                                fontSize = 11.5.sp,
                                color = Color(0xFFB45309)
                            )
                        }
                    }

                    Text(
                        text = "💡 جهت اطمینان و جلوگیری از دست رفتن داده‌ها، قبل از انجام بازگردانی یک نسخه پشتیبان اضطراری از وضعیت فعلی کلاس به طور خودکار ثبت می‌شود.",
                        fontSize = 11.sp,
                        color = PrimaryGreenDark,
                        lineHeight = 16.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val file = target.file
                        backupToRestore = null
                        val success = viewModel.restoreFromLocalBackup(file)
                        if (success) {
                            refreshBackupsList()
                            Toast.makeText(
                                context,
                                "اطلاعات کلاس با موفقیت بازگردانی شد.",
                                Toast.LENGTH_LONG
                            ).show()
                        } else {
                            Toast.makeText(
                                context,
                                "خطا در بازگردانی اطلاعات!",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                ) {
                    Text("بله، بازگردانی شود", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { backupToRestore = null }) {
                    Text("انصراف")
                }
            }
        )
    }

    // دیالوگ تایید بازگردانی از فایل خارجی انتخابی (SAF)
    if (pendingRestoreUri != null && pendingRestoreSummary != null) {
        val uri = pendingRestoreUri!!
        val summary = pendingRestoreSummary!!

        AlertDialog(
            onDismissRequest = {
                pendingRestoreUri = null
                pendingRestoreSummary = null
            },
            icon = {
                Icon(
                    imageVector = Icons.Default.FileUpload,
                    contentDescription = null,
                    tint = SkyBlue,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = "بازگردانی فایل انتخابی",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "مشخصات فایل انتخاب شده جهت بازگردانی:",
                        fontSize = 12.5.sp,
                        color = TextPrimary
                    )

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = SkyBlue.copy(alpha = 0.08f),
                        border = BorderStroke(1.dp, SkyBlue.copy(alpha = 0.25f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "معلم: ${summary.teacherName.ifBlank { "ثبت‌نشده" }} ${if (summary.schoolName.isNotBlank()) "- ${summary.schoolName}" else ""}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = SkyBlue
                            )
                            if (summary.dateShamsi.isNotBlank()) {
                                Text(
                                    text = "تاریخ فایل: ${DateUtils.toPersianDigits(summary.dateShamsi)}",
                                    fontSize = 11.5.sp,
                                    color = TextSecondary
                                )
                            }
                            Text(
                                text = "تعداد دانش‌آموزان: ${DateUtils.toPersianDigits(summary.studentsCount)} نفر",
                                fontSize = 11.5.sp,
                                color = TextSecondary
                            )
                            Text(
                                text = "تعداد کل ارزیابی‌ها: ${DateUtils.toPersianDigits(summary.evaluationsCount)} مورد",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "جلسات حضور و غیاب: ${DateUtils.toPersianDigits(summary.attendanceDaysCount)} روز",
                                fontSize = 11.5.sp,
                                color = TextSecondary
                            )
                        }
                    }

                    Text(
                        text = "آیا مایلید این فایل در کلاس بارگذاری شود؟",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextPrimary
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val success = viewModel.importBackupFromUri(uri)
                        pendingRestoreUri = null
                        pendingRestoreSummary = null
                        if (success) {
                            refreshBackupsList()
                            Toast.makeText(
                                context,
                                "اطلاعات فایل با موفقیت بازگردانی شد.",
                                Toast.LENGTH_LONG
                            ).show()
                        } else {
                            Toast.makeText(
                                context,
                                "خطا در خواندن و اعمال فایل!",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                ) {
                    Text("تایید و بازگردانی", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        pendingRestoreUri = null
                        pendingRestoreSummary = null
                    }
                ) {
                    Text("انصراف")
                }
            }
        )
    }

    // دیالوگ حذف نسخه
    if (backupToDelete != null) {
        val target = backupToDelete!!
        AlertDialog(
            onDismissRequest = { backupToDelete = null },
            icon = {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = null,
                    tint = AbsentRed,
                    modifier = Modifier.size(28.dp)
                )
            },
            title = { Text("حذف نسخه پشتیبان", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    text = "آیا از حذف نسخه «${target.title}» از حافظه گوشی اطمینان دارید؟",
                    fontSize = 13.sp,
                    color = TextPrimary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val file = target.file
                        backupToDelete = null
                        val success = viewModel.deleteLocalBackup(file)
                        if (success) {
                            refreshBackupsList()
                            Toast.makeText(context, "نسخه حذف گردید.", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AbsentRed)
                ) {
                    Text("حذف")
                }
            },
            dismissButton = {
                TextButton(onClick = { backupToDelete = null }) {
                    Text("انصراف")
                }
            }
        )
    }
    // دیالوگ تغییر محل ذخیره‌سازی فایل‌های پشتیبان
    if (showChangePathDialog) {
        val suggestedLocations = remember { viewModel.getSuggestedStorageLocations() }
        var selectedPath by remember { mutableStateOf(storagePath) }
        var isCustomSelected by remember { mutableStateOf(!suggestedLocations.any { it.path == storagePath }) }
        var customPathInput by remember { mutableStateOf(if (isCustomSelected) storagePath else "") }
        var copyExistingBackups by remember { mutableStateOf(true) }

        AlertDialog(
            onDismissRequest = { showChangePathDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.FolderOpen,
                    contentDescription = null,
                    tint = PrimaryGreen,
                    modifier = Modifier.size(28.dp)
                )
            },
            title = {
                Text(
                    text = "تغییر محل ذخیره‌سازی پشتیبان‌ها",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "می‌توانید پوشه مورد نظر برای ذخیره‌سازی فایل‌های پشتیبان را از میان گزینه‌های زیر انتخاب کرده یا مسیر دلخواهی وارد کنید:",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    // مسیرهای پیشنهادی
                    suggestedLocations.forEach { loc ->
                        val isSelected = !isCustomSelected && selectedPath == loc.path
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable {
                                    isCustomSelected = false
                                    selectedPath = loc.path
                                },
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) PrimaryGreen.copy(alpha = 0.08f) else Color(0xFFF8FAFC)
                            ),
                            border = BorderStroke(
                                if (isSelected) 1.5.dp else 1.dp,
                                if (isSelected) PrimaryGreen else Color(0xFFE2E8F0)
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = {
                                        isCustomSelected = false
                                        selectedPath = loc.path
                                    },
                                    colors = RadioButtonDefaults.colors(selectedColor = PrimaryGreen)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = loc.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = if (isSelected) PrimaryGreenDark else TextPrimary
                                    )
                                    Text(
                                        text = loc.path,
                                        fontSize = 9.5.sp,
                                        color = TextSecondary,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }

                    // گزینه مسیر دلخواه دستی
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable {
                                isCustomSelected = true
                            },
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isCustomSelected) PrimaryGreen.copy(alpha = 0.08f) else Color(0xFFF8FAFC)
                        ),
                        border = BorderStroke(
                            if (isCustomSelected) 1.5.dp else 1.dp,
                            if (isCustomSelected) PrimaryGreen else Color(0xFFE2E8F0)
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(
                                    selected = isCustomSelected,
                                    onClick = { isCustomSelected = true },
                                    colors = RadioButtonDefaults.colors(selectedColor = PrimaryGreen)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "ورود مسیر دلخواه به صورت دستی",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = if (isCustomSelected) PrimaryGreenDark else TextPrimary
                                )
                            }
                            if (isCustomSelected) {
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = customPathInput,
                                    onValueChange = { customPathInput = it },
                                    placeholder = { Text("مثال: /storage/emulated/0/ClassBackups", fontSize = 11.sp) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // چک‌باکس انتقال فایل‌های قبلی
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { copyExistingBackups = !copyExistingBackups },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = copyExistingBackups,
                            onCheckedChange = { copyExistingBackups = it },
                            colors = CheckboxDefaults.colors(checkedColor = PrimaryGreen)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "انتقال فایل‌های پشتیبان قبلی به محل جدید",
                            fontSize = 11.5.sp,
                            color = TextPrimary
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val pathToApply = if (isCustomSelected) customPathInput.trim() else selectedPath.trim()
                        if (pathToApply.isBlank()) {
                            Toast.makeText(context, "لطفاً یک مسیر معتبر وارد کنید.", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        val success = viewModel.setCustomBackupPath(pathToApply, copyExistingBackups)
                        if (success) {
                            storagePath = viewModel.getBackupStoragePath()
                            isCustomStoragePath = viewModel.isUsingCustomBackupPath()
                            refreshBackupsList()
                            Toast.makeText(context, "محل ذخیره‌سازی با موفقیت تغییر کرد.", Toast.LENGTH_SHORT).show()
                            showChangePathDialog = false
                        } else {
                            Toast.makeText(context, "دسترسی نوشتن در این مسیر وجود ندارد!", Toast.LENGTH_LONG).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                ) {
                    Text("تایید و ذخیره", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showChangePathDialog = false }) {
                    Text("انصراف")
                }
            }
        )
    }

    // دیالوگ اعلام قفل بودن بازیابی در نسخه دمو
    if (showDemoRestoreDialog) {
        AlertDialog(
            onDismissRequest = { showDemoRestoreDialog = false },
            icon = {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFEE2E2)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "قفل نسخه دمو",
                        tint = Color(0xFFDC2626),
                        modifier = Modifier.size(28.dp)
                    )
                }
            },
            title = {
                Text(
                    text = "بازیابی پشتیبان قفل می‌باشد",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = DemoConfig.DEMO_RESTORE_LOCKED_MESSAGE,
                        fontSize = 13.5.sp,
                        lineHeight = 22.sp,
                        textAlign = TextAlign.Center,
                        color = TextPrimary
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFF8FAFC),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "با خرید و ثبت کلید فعال‌سازی نسخه پرو، امکان بازیابی فایل‌های پشتیبان و همچنین ثبت نامحدود دانش‌آموزان به صورت کامل بازگشایی خواهد شد.",
                            fontSize = 11.5.sp,
                            lineHeight = 18.sp,
                            textAlign = TextAlign.Center,
                            color = TextSecondary,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            },
            confirmButton = {
                if (onNavigateToPro != null) {
                    Button(
                        onClick = {
                            showDemoRestoreDialog = false
                            onNavigateToPro()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("btn_dialog_go_to_pro_from_restore")
                    ) {
                        Icon(Icons.Default.WorkspacePremium, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("فعال‌سازی نسخه پرو", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                    }
                } else {
                    Button(
                        onClick = { showDemoRestoreDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("متوجه شدم", fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showDemoRestoreDialog = false },
                    modifier = Modifier.testTag("btn_dialog_dismiss_restore_demo")
                ) {
                    Text("انصراف", color = TextSecondary, fontWeight = FontWeight.Bold)
                }
            },
            modifier = Modifier.testTag("dialog_demo_restore_locked")
        )
    }
}

@Composable
fun LocalBackupCard(
    backup: LocalBackupFile,
    isNewest: Boolean = false,
    isOldest: Boolean = false,
    isDemo: Boolean = false,
    onRestore: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("backup_item_${backup.file.name}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (backup.isAutoBackup) Color(0xFFF0FDF4) else Color.White
        ),
        border = BorderStroke(
            1.dp,
            if (backup.isAutoBackup) PrimaryGreen.copy(alpha = 0.35f) else BorderLight
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(
                                if (backup.isAutoBackup) PrimaryGreen.copy(alpha = 0.15f)
                                else SkyBlue.copy(alpha = 0.15f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (backup.isAutoBackup) Icons.Default.History else Icons.Default.SettingsBackupRestore,
                            contentDescription = null,
                            tint = if (backup.isAutoBackup) PrimaryGreenDark else SkyBlue,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = backup.title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = TextPrimary
                            )
                            if (isNewest) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = PrimaryGreen.copy(alpha = 0.18f)
                                ) {
                                    Text(
                                        text = "جدیدترین",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = PrimaryGreenDark,
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.5.dp)
                                    )
                                }
                            } else if (isOldest) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = Color(0xFFE2E8F0)
                                ) {
                                    Text(
                                        text = "قدیمی‌ترین",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF64748B),
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.5.dp)
                                    )
                                }
                            }
                            if (backup.isAutoBackup) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = PrimaryGreen.copy(alpha = 0.18f)
                                ) {
                                    Text(
                                        text = "خودکار",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = PrimaryGreenDark,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = "${backup.dateShamsi} - ساعت ${backup.time} (${backup.sizeFormatted})",
                            fontSize = 11.5.sp,
                            color = TextSecondary
                        )
                    }
                }

                Row {
                    // دکمه اشتراک‌گذاری
                    IconButton(onClick = onShare, modifier = Modifier.size(36.dp)) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "اشتراک‌گذاری",
                            tint = SkyBlue,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // دکمه حذف
                    IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "حذف نسخه",
                            tint = AbsentRed,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // چیپ‌های خلاصه اطلاعات درون فایل
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                BackupChip(
                    text = "${DateUtils.toPersianDigits(backup.studentsCount)} دانش‌آموز",
                    color = PrimaryGreen
                )
                BackupChip(
                    text = "${DateUtils.toPersianDigits(backup.evaluationsCount)} ارزیابی",
                    color = EvaluationOrange,
                    isBold = true
                )
                BackupChip(
                    text = "${DateUtils.toPersianDigits(backup.attendanceDaysCount)} جلسه غیبت",
                    color = MeetingPurple
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // دکمه بازگردانی این نسخه
            Button(
                onClick = onRestore,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(40.dp)
                    .testTag("btn_restore_backup_item"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isDemo) Color(0xFFF1F5F9) else PrimaryGreen
                ),
                border = if (isDemo) BorderStroke(1.dp, Color(0xFFCBD5E1)) else null,
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(
                    imageVector = if (isDemo) Icons.Default.Lock else Icons.Default.Restore,
                    contentDescription = null,
                    tint = if (isDemo) Color(0xFF64748B) else Color.White,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isDemo) "بازیابی این نسخه (قفل دمو)" else "بازیابی این نسخه در کلاس",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDemo) Color(0xFF475569) else Color.White
                )
            }
        }
    }
}

@Composable
fun BackupChip(text: String, color: Color, isBold: Boolean = false) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = color.copy(alpha = 0.10f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.25f))
    ) {
        Text(
            text = text,
            fontSize = 10.5.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Medium,
            color = color,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun StatMiniBadge(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 15.sp,
            color = Color.White
        )
        Text(
            text = label,
            fontSize = 10.sp,
            color = Color.White.copy(alpha = 0.8f)
        )
    }
}
